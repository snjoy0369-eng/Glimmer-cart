import { UserProfile, ShippingAddress } from '../types';

const USERS_STORAGE_KEY = 'glimmer_cart_users_v2';
const ACTIVE_USER_ID_KEY = 'glimmer_cart_active_user_id';

/**
 * Normalizes an Indian or international mobile number to standard 10 digits
 * by stripping spaces, symbols, and country code (+91 / 0).
 */
export function normalizeMobile(mobile: string): string {
  if (!mobile) return '';
  const digitsOnly = mobile.replace(/\D/g, '');
  if (digitsOnly.length > 10 && (digitsOnly.startsWith('91') || digitsOnly.startsWith('0'))) {
    return digitsOnly.slice(-10);
  }
  return digitsOnly.slice(-10);
}

/**
 * Normalizes email address
 */
export function normalizeEmail(email: string): string {
  if (!email) return '';
  return email.trim().toLowerCase();
}

/**
 * Retrieves all registered users from persistent storage
 */
export function getAllUsers(): UserProfile[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.warn('Failed to parse users from localStorage:', err);
    return [];
  }
}

/**
 * Finds a user by unique ID
 */
export function getUserById(id: string): UserProfile | null {
  const users = getAllUsers();
  return users.find(u => u.id === id) || null;
}

/**
 * Checks if a user already exists with the given mobile number or email.
 * This prevents creating duplicate profiles when returning users log in.
 */
export function findExistingUser(params: { mobile?: string; email?: string }): UserProfile | null {
  const users = getAllUsers();
  const searchMobile = normalizeMobile(params.mobile || '');
  const searchEmail = normalizeEmail(params.email || '');

  for (const u of users) {
    if (searchMobile && normalizeMobile(u.mobile) === searchMobile) {
      return u;
    }
    if (searchEmail && normalizeEmail(u.email) === searchEmail) {
      return u;
    }
  }

  return null;
}

/**
 * Saves or updates a user profile in the persistent multi-user database
 */
export function saveUser(user: UserProfile): void {
  const users = getAllUsers();
  const existingIdx = users.findIndex(u => u.id === user.id);

  if (existingIdx >= 0) {
    users[existingIdx] = user;
  } else {
    users.push(user);
  }

  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Failed to save user to localStorage:', err);
  }
}

/**
 * Gets the current active user ID from persistent session
 */
export function getActiveUserId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_USER_ID_KEY);
  } catch {
    return null;
  }
}

/**
 * Sets the active user ID and saves the session
 */
export function setActiveUserId(id: string | null): void {
  try {
    if (id) {
      localStorage.setItem(ACTIVE_USER_ID_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_USER_ID_KEY);
    }
  } catch (err) {
    console.error('Failed to update active user ID:', err);
  }
}

/**
 * Gets the active user profile, or null if logged out
 */
export function getActiveUser(): UserProfile | null {
  const activeId = getActiveUserId();
  if (!activeId) return null;
  return getUserById(activeId);
}

/**
 * Automatic Profile Creation or Load:
 * - When a user logs in with Full Name, Mobile, and optional Email:
 * - If an account with this mobile/email already exists, loads existing profile (and updates name/email if provided).
 * - If new, creates a brand-new profile with their entered details.
 * - Stores profile linked to their unique account ID.
 * - Sets this user as the active user.
 */
export function createOrLoadUserProfile(params: {
  fullName: string;
  mobile?: string;
  email?: string;
  avatarUrl?: string;
}): { user: UserProfile; isNew: boolean } {
  const normMobile = normalizeMobile(params.mobile || '');
  const normEmail = normalizeEmail(params.email || '');
  const trimmedName = params.fullName.trim();

  // 1. Look for existing account
  const existing = findExistingUser({
    mobile: normMobile,
    email: normEmail
  });

  if (existing) {
    // Returning user: update any newer info if provided
    let hasChanges = false;
    const updated: UserProfile = { ...existing };

    if (trimmedName && trimmedName !== existing.name) {
      updated.name = trimmedName;
      hasChanges = true;
    }
    if (normEmail && (!existing.email || existing.email !== normEmail)) {
      updated.email = normEmail;
      hasChanges = true;
    }
    if (normMobile && (!existing.mobile || normalizeMobile(existing.mobile) !== normMobile)) {
      updated.mobile = `+91 ${normMobile}`;
      hasChanges = true;
    }
    if (params.avatarUrl && params.avatarUrl !== existing.avatarUrl) {
      updated.avatarUrl = params.avatarUrl;
      hasChanges = true;
    }

    if (hasChanges) {
      saveUser(updated);
    }
    setActiveUserId(updated.id);
    return { user: updated, isNew: false };
  }

  // 2. New user: automatically create personal profile
  const newUserId = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const newUser: UserProfile = {
    id: newUserId,
    name: trimmedName || (normMobile ? `User ${normMobile.slice(-4)}` : 'Valued Customer'),
    mobile: normMobile ? `+91 ${normMobile}` : '',
    email: normEmail,
    avatarUrl: params.avatarUrl || '', // Clean default avatar when empty
    savedAddresses: [],
    createdAt: new Date().toISOString(),
    isAdmin: false
  };

  saveUser(newUser);
  setActiveUserId(newUser.id);
  return { user: newUser, isNew: true };
}

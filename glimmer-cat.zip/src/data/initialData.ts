import { Product, PromoBanner, Coupon, AppNotification, UserProfile } from '../types';

export const INITIAL_BANNERS: PromoBanner[] = [
  {
    id: 'banner-1',
    title: 'Sparkle Like Starlight ✨',
    subtitle: 'Cute Kan Fuli & Dainty Butterfly Earrings are back!',
    badge: 'NEW DROP',
    imageUrl: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=1200&q=80',
    buttonText: 'Shop New Arrivals',
    targetCategory: 'earrings',
    discountCode: 'GLIMMER15',
    accentColor: 'from-pink-100/90 to-purple-100/90'
  },
  {
    id: 'banner-2',
    title: 'The Cat Whiskers Edit 🐾',
    subtitle: 'Signature whimsical kitten charms & opal pendants',
    badge: 'LIMITED EDITION',
    imageUrl: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1200&q=80',
    buttonText: 'Explore Collection',
    targetCategory: 'charms',
    discountCode: 'CATLOVE20',
    accentColor: 'from-purple-100/90 to-pink-50/90'
  },
  {
    id: 'banner-3',
    title: 'Cute Gift Boxes & Hampers 🎁',
    subtitle: 'Perfect birthday surprises wrapped in velvet & ribbons',
    badge: 'GIFTING SPECIAL',
    imageUrl: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=1200&q=80',
    buttonText: 'Discover Gifts',
    targetCategory: 'gift-items',
    discountCode: 'FIRSTBUY',
    accentColor: 'from-pink-50/90 to-amber-50/90'
  }
];

/**
 * INITIAL_PRODUCTS is intentionally empty to remove the old demo/sample products.
 * The catalog is now clean and fully ready for real products added by the store owner
 * via the Admin Product Management suite.
 */
export const INITIAL_PRODUCTS: Product[] = [];

export const INITIAL_COUPONS: Coupon[] = [
  {
    code: 'GLIMMER15',
    discountType: 'percentage',
    value: 15,
    minOrderAmount: 499,
    description: '15% OFF on orders above ₹499'
  },
  {
    code: 'CATLOVE20',
    discountType: 'percentage',
    value: 20,
    minOrderAmount: 899,
    description: '20% OFF on orders above ₹899'
  },
  {
    code: 'FIRSTBUY',
    discountType: 'flat',
    value: 100,
    minOrderAmount: 599,
    description: 'Flat ₹100 OFF on your first purchase'
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    title: '✨ Welcome to Glimmer Cart!',
    message: 'Enjoy 15% off your dream accessories with code GLIMMER15 at checkout.',
    type: 'offer',
    date: 'Just now',
    read: false
  },
  {
    id: 'notif-2',
    title: '🌸 Real Product Catalog Ready',
    message: 'Add your own accessories with multi-photo upload in Store Manager.',
    type: 'arrival',
    date: 'Just now',
    read: false
  },
  {
    id: 'notif-3',
    title: '🎁 Free Gift Velvet Pouch',
    message: 'Get an embroidered Glimmer Cart satin jewelry pouch on every order above ₹799!',
    type: 'discount',
    date: '1 day ago',
    read: true
  }
];

export const DEMO_USER: UserProfile = {
  id: 'usr-8891',
  name: 'Aarohi Sen',
  email: 'aarohi.sen@glimmercart.com',
  mobile: '+91 98765 43210',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  savedAddresses: [
    {
      fullName: 'Aarohi Sen',
      mobileNumber: '+91 98765 43210',
      addressLine: 'Flat 402, Rosewood Heights, 12th Main, Indiranagar',
      city: 'Bengaluru',
      state: 'Karnataka',
      pinCode: '560038',
      addressType: 'Home'
    },
    {
      fullName: 'Aarohi Sen',
      mobileNumber: '+91 98765 43210',
      addressLine: 'Design Studio 3B, Tech Park Road, Whitefield',
      city: 'Bengaluru',
      state: 'Karnataka',
      pinCode: '560066',
      addressType: 'Work'
    }
  ],
  isAdmin: false
};

import { CategoryId } from '../types';

export interface CategoryInfo {
  id: CategoryId;
  name: string;
  shortDesc: string;
  image: string;
  highlightTag: string;
}

export const CATEGORIES_DATA: CategoryInfo[] = [
  {
    id: 'earrings',
    name: 'Earrings',
    shortDesc: 'Floral drops, butterfly wings & sparkle studs',
    image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Most Loved'
  },
  {
    id: 'kan-fuli',
    name: 'Kan Fuli',
    shortDesc: 'Fairy ear chain cuffs & cascading pearl chains',
    image: 'https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Viral Trend'
  },
  {
    id: 'necklaces',
    name: 'Necklaces',
    shortDesc: 'Dreamy opal cat pendants & crystal chokers',
    image: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Signature'
  },
  {
    id: 'bracelets',
    name: 'Bracelets',
    shortDesc: 'Daisy pearl chains & pastel twinkle charms',
    image: 'https://images.unsplash.com/photo-1611591475152-4c071138246a?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Handmade'
  },
  {
    id: 'rings',
    name: 'Rings',
    shortDesc: 'Bow ribbons & adjustable fairytale stackers',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Free Size'
  },
  {
    id: 'hair-accessories',
    name: 'Hair Accessories',
    shortDesc: 'Velvet cat ear clips & silk ribbon scrunchies',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Cute Touch'
  },
  {
    id: 'charms',
    name: 'Charms',
    shortDesc: 'Kitty bell bag charms & keychain sparkles',
    image: 'https://images.unsplash.com/photo-1588880331179-bc9b93a8cb5e?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Collectibles'
  },
  {
    id: 'gift-items',
    name: 'Gift Items',
    shortDesc: 'Plush velvet hampers & curated jewelry boxes',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Special Hamper'
  },
  {
    id: 'new-arrivals',
    name: 'New Arrivals',
    shortDesc: 'Freshly launched starlight collections',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=400&q=80',
    highlightTag: 'Just In'
  }
];

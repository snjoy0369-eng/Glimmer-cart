export type CategoryId = 
  | 'earrings' 
  | 'kan-fuli' 
  | 'necklaces' 
  | 'bracelets' 
  | 'rings' 
  | 'hair-accessories' 
  | 'charms' 
  | 'gift-items'
  | 'new-arrivals';

export interface ProductVariant {
  id: string;
  name: string; // e.g. "Rose Gold", "Silver", "Lavender Purple"
  colorHex?: string;
  inStock: boolean;
}

export interface ProductReview {
  id: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
}

export interface Product {
  id: string;
  name: string;
  tagline?: string;
  categoryId: CategoryId;
  categoryName: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  rating: number;
  reviewsCount: number;
  images: string[];
  description: string;
  material: string;
  dimensions?: string;
  stockCount: number;
  isNewArrival?: boolean;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isTrending?: boolean;
  isViral?: boolean;
  isOutOfStock?: boolean;
  isGiftPick?: boolean;
  isLimitedCollection?: boolean;
  tags: string[];
  variants?: ProductVariant[];
  reviews?: ProductReview[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: ProductVariant;
}

export type OrderStatus = 
  | 'Order Placed' 
  | 'Confirmed' 
  | 'Packed' 
  | 'Shipped' 
  | 'Out for Delivery' 
  | 'Delivered';

export interface ShippingAddress {
  fullName: string;
  mobileNumber: string;
  addressLine: string;
  city: string;
  state: string;
  pinCode: string;
  addressType?: 'Home' | 'Work' | 'Other';
  isDefault?: boolean;
}

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  deliveryCharge: number;
  discount: number;
  couponApplied?: string;
  total: number;
  shippingAddress: ShippingAddress;
  paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery';
  paymentStatus: 'Pending' | 'Paid';
  orderStatus: OrderStatus;
  estimatedDelivery: string;
  trackingNumber?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  mobile: string;
  avatarUrl?: string;
  savedAddresses: ShippingAddress[];
  isAdmin?: boolean;
  createdAt?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'discount' | 'arrival' | 'offer';
  date: string;
  read: boolean;
  actionUrl?: string;
}

export interface Coupon {
  code: string;
  discountType?: 'percentage' | 'flat';
  value?: number; // e.g. 15 for 15% or 100 for ₹100
  discountPercent?: number;
  minOrderAmount?: number;
  minSpend?: number;
  description: string;
}

export interface PromoBanner {
  id: string;
  title: string;
  subtitle: string;
  badge?: string;
  tag?: string;
  imageUrl: string;
  buttonText?: string;
  ctaText?: string;
  targetCategory?: CategoryId;
  linkCategoryId?: CategoryId;
  discountCode?: string;
  accentColor?: string;
}

import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Sparkles, ArrowRight } from 'lucide-react';

interface SplashScreenProps {
  onComplete?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const { isSplashVisible, dismissSplash } = useApp();
  const [step, setStep] = useState<number>(0);

  const handleDismiss = () => {
    dismissSplash();
    onComplete?.();
  };

  useEffect(() => {
    if (!isSplashVisible) return;

    // Step 0: Initial aura
    // Step 1: Cat gently appears
    const timer1 = setTimeout(() => setStep(1), 350);
    // Step 2: Sparkle burst + Logo name
    const timer2 = setTimeout(() => setStep(2), 950);
    // Step 3: Subtitle + auto enter
    const timer3 = setTimeout(() => setStep(3), 1600);
    // Auto dismiss after 2.8 seconds
    const timer4 = setTimeout(() => {
      handleDismiss();
    }, 2800);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [isSplashVisible]);

  if (!isSplashVisible) return null;

  return (
    <div 
      onClick={handleDismiss}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-between p-8 bg-gradient-to-b from-[#FFF9F9] via-[#FAF6FC] to-[#F5EEFB] text-stone-800 select-none cursor-pointer transition-opacity duration-700 overflow-hidden"
    >
      {/* Dreamy Ambient Orbs */}
      <div className="absolute top-1/4 -left-12 w-64 h-64 rounded-full bg-pink-200/40 blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/3 -right-12 w-72 h-72 rounded-full bg-purple-200/40 blur-3xl pointer-events-none animate-pulse" style={{ animationDuration: '4s' }} />

      {/* Floating Sparkle Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <span className="absolute top-[18%] left-[22%] text-pink-300 text-lg animate-bounce" style={{ animationDuration: '3s' }}>✨</span>
        <span className="absolute top-[35%] right-[20%] text-amber-300 text-sm animate-pulse" style={{ animationDuration: '2s' }}>✦</span>
        <span className="absolute bottom-[28%] left-[18%] text-purple-300 text-base animate-bounce" style={{ animationDuration: '4s' }}>✨</span>
        <span className="absolute bottom-[35%] right-[25%] text-pink-400 text-xs animate-pulse">✦</span>
      </div>

      {/* Skip button top right */}
      <div className="w-full flex justify-end z-10 pt-2">
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleDismiss();
          }}
          className="text-xs tracking-wider uppercase font-semibold text-stone-600 hover:text-stone-900 bg-white/70 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-pink-100 shadow-sm flex items-center gap-1 transition-all"
        >
          Skip <ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* Center Hero: Cat Logo + Gentle Animation Sequence */}
      <div className="flex flex-col items-center justify-center text-center my-auto z-10">
        {/* Cat Emblem */}
        <div 
          className={`relative transition-all duration-1000 transform ${
            step >= 1 
              ? 'opacity-100 scale-100 translate-y-0' 
              : 'opacity-0 scale-75 translate-y-6'
          }`}
        >
          {/* Pulsing Backlight Halo */}
          <div className="absolute inset-0 -m-6 rounded-full bg-gradient-to-tr from-pink-300/40 via-purple-300/40 to-amber-200/30 blur-2xl animate-spin" style={{ animationDuration: '14s' }} />

          {/* Large Animated Cat Container */}
          <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-white/90 shadow-[0_12px_40px_rgba(244,114,182,0.25)] border border-white/80 p-3 flex items-center justify-center backdrop-blur-sm">
            <svg 
              viewBox="0 0 100 100" 
              className="w-full h-full text-pink-700 drop-shadow-md"
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Decorative Circle Ring */}
              <circle cx="50" cy="50" r="46" stroke="#F472B6" strokeWidth="2" strokeDasharray="5 3" opacity="0.7" />

              {/* Cat Head */}
              <path
                d="M25 46 C 22 28, 38 31, 39 42 C 44 40, 56 40, 61 42 C 62 31, 78 28, 75 46 C 81 54, 78 68, 69 76 C 60 83, 40 83, 31 76 C 22 68, 19 54, 25 46 Z"
                fill="url(#splashCatGrad)"
                stroke="#9D174D"
                strokeWidth="2.2"
                strokeLinejoin="round"
              />

              {/* Ears */}
              <path d="M29 40 C 31 32, 36 34, 37 42" fill="#FCE7F3" />
              <path d="M71 40 C 69 32, 64 34, 63 42" fill="#FCE7F3" />

              {/* Sleepy Cute Closed Lashes */}
              <path d="M37 57 Q 42 61 45 57" stroke="#831843" strokeWidth="2.4" strokeLinecap="round" />
              <path d="M55 57 Q 58 61 63 57" stroke="#831843" strokeWidth="2.4" strokeLinecap="round" />

              {/* Heart Nose */}
              <path d="M50 63 L 47.8 60.5 A 1.5 1.5 0 0 1 50 58.5 A 1.5 1.5 0 0 1 52.2 60.5 Z" fill="#BE185D" />

              {/* Whiskers */}
              <path d="M22 58 L 32 60 M 21 64 L 31 63" stroke="#9D174D" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />
              <path d="M78 58 L 68 60 M 79 64 L 69 63" stroke="#9D174D" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />

              {/* Sparkle Tiara */}
              <polygon points="50,29 53,35 58,36 54,40 55,45 50,42 45,45 46,40 42,36 47,35" fill="url(#splashGoldGrad)" stroke="#B45309" strokeWidth="0.8" />
              <circle cx="50" cy="37" r="2" fill="#FFFFFF" />

              <defs>
                <linearGradient id="splashCatGrad" x1="20" y1="20" x2="80" y2="80" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#FFF1F2" />
                  <stop offset="0.5" stopColor="#FCE7F3" />
                  <stop offset="1" stopColor="#E9D5FF" />
                </linearGradient>
                <linearGradient id="splashGoldGrad" x1="42" y1="29" x2="58" y2="45" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#FDE68A" />
                  <stop offset="0.5" stopColor="#F59E0B" />
                  <stop offset="1" stopColor="#D97706" />
                </linearGradient>
              </defs>
            </svg>

            {/* Sparkle badge */}
            <div className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-gradient-to-tr from-pink-500 to-purple-500 text-white flex items-center justify-center shadow-md animate-bounce">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* Brand Name Animation */}
        <div 
          className={`mt-6 transition-all duration-700 transform ${
            step >= 2 
              ? 'opacity-100 translate-y-0' 
              : 'opacity-0 translate-y-4'
          }`}
        >
          <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-stone-900 flex items-center justify-center gap-1.5">
            <span>Glimmer Cart</span>
            <span className="text-pink-500 text-2xl font-light">✦</span>
          </h1>
        </div>

        {/* Subtitle Animation */}
        <div 
          className={`mt-2 transition-all duration-700 transform ${
            step >= 3 
              ? 'opacity-100 translate-y-0' 
              : 'opacity-0 translate-y-3'
          }`}
        >
          <p className="text-stone-500 text-xs sm:text-sm tracking-widest uppercase font-medium">
            Cute &amp; Stylish Accessories for Girls
          </p>
          <div className="mt-3 flex items-center justify-center gap-1 text-[11px] text-pink-600/80 font-medium">
            <span>Unique Earrings</span>
            <span>•</span>
            <span>Kan Fuli</span>
            <span>•</span>
            <span>Charms</span>
            <span>•</span>
            <span>Gifts</span>
          </div>
        </div>
      </div>

      {/* Footer loading bar / tap to enter */}
      <div className="w-full max-w-xs flex flex-col items-center gap-2 z-10 pb-4">
        <div className="w-full h-1 bg-pink-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-pink-400 via-purple-400 to-amber-300 rounded-full transition-all duration-[2600ms] ease-out" 
            style={{ width: step === 0 ? '5%' : step === 1 ? '35%' : step === 2 ? '75%' : '100%' }}
          />
        </div>
        <p className="text-[11px] text-stone-400 font-medium animate-pulse">
          Tap anywhere to enter boutique
        </p>
      </div>
    </div>
  );
};

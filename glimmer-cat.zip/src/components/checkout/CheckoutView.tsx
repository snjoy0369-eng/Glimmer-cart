import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ShippingAddress } from '../../types';
import { 
  X, 
  ArrowLeft, 
  Check, 
  ShieldCheck, 
  CreditCard, 
  Smartphone, 
  Landmark, 
  Truck, 
  Sparkles,
  Lock,
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const CheckoutView: React.FC = () => {
  const { 
    isCheckoutOpen, 
    closeCheckout, 
    cart, 
    cartSubtotal, 
    deliveryCharge, 
    discountAmount, 
    cartTotal,
    appliedCoupon,
    user,
    placeOrder,
    setCurrentTab
  } = useApp();

  // Selected or custom address
  const [selectedAddressIdx, setSelectedAddressIdx] = useState<number>(0);
  const [useCustomAddress, setUseCustomAddress] = useState(false);

  // Address fields
  const [fullName, setFullName] = useState(user?.savedAddresses[0]?.fullName || user?.name || '');
  const [mobileNumber, setMobileNumber] = useState(user?.savedAddresses[0]?.mobileNumber || user?.mobile || '');
  const [addressLine, setAddressLine] = useState(user?.savedAddresses[0]?.addressLine || '');
  const [city, setCity] = useState(user?.savedAddresses[0]?.city || '');
  const [state, setState] = useState(user?.savedAddresses[0]?.state || '');
  const [pinCode, setPinCode] = useState(user?.savedAddresses[0]?.pinCode || '');

  // Payment method
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery'>('UPI');
  const [upiId, setUpiId] = useState('');
  const [selectedUpiApp, setSelectedUpiApp] = useState<'gpay' | 'phonepe' | 'paytm' | 'custom'>('gpay');
  const [isProcessing, setIsProcessing] = useState(false);

  // Sync with active user profile so edited names or addresses reflect instantly
  useEffect(() => {
    if (user) {
      if (user.savedAddresses && user.savedAddresses.length > 0) {
        const addr = user.savedAddresses[0];
        setFullName(addr.fullName || user.name);
        setMobileNumber(addr.mobileNumber || user.mobile || '');
        setAddressLine(addr.addressLine || '');
        setCity(addr.city || '');
        setState(addr.state || '');
        setPinCode(addr.pinCode || '');
      } else {
        setFullName(user.name);
        setMobileNumber(user.mobile || '');
      }
    }
  }, [user, isCheckoutOpen]);

  if (!isCheckoutOpen) return null;

  const handleSelectSavedAddress = (idx: number) => {
    if (!user?.savedAddresses[idx]) return;
    setSelectedAddressIdx(idx);
    const addr = user.savedAddresses[idx];
    setFullName(addr.fullName);
    setMobileNumber(addr.mobileNumber);
    setAddressLine(addr.addressLine);
    setCity(addr.city);
    setState(addr.state);
    setPinCode(addr.pinCode);
    setUseCustomAddress(false);
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!fullName.trim() || !mobileNumber.trim() || !addressLine.trim() || !city.trim() || !state.trim() || !pinCode.trim()) {
      alert('Please fill all delivery address details.');
      return;
    }

    setIsProcessing(true);

    const shippingAddress: ShippingAddress = {
      fullName: fullName.trim(),
      mobileNumber: mobileNumber.trim(),
      addressLine: addressLine.trim(),
      city: city.trim(),
      state: state.trim(),
      pinCode: pinCode.trim(),
      addressType: 'Home'
    };

    // Simulate payment verification delay
    setTimeout(() => {
      const order = placeOrder(shippingAddress, paymentMethod);
      setIsProcessing(false);
      closeCheckout();

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#F472B6', '#C084FC', '#FBBF24', '#DDD6FE']
        });
      } catch (err) {
        // Fallback gracefully if canvas is blocked
      }

      setCurrentTab('orders');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-sm flex justify-center items-start sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white sm:rounded-3xl shadow-2xl overflow-hidden min-h-screen sm:min-h-0 my-auto border border-pink-100 flex flex-col">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-4 py-3.5 flex items-center justify-between border-b border-stone-100">
          <div className="flex items-center gap-2">
            <button
              onClick={closeCheckout}
              className="p-1.5 rounded-full text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h2 className="font-display text-lg font-bold text-stone-900">
              Checkout &amp; Delivery
            </h2>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
            <Lock className="w-3 h-3 text-emerald-600" />
            <span>256-Bit SSL Encrypted</span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handlePlaceOrder} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* 1. Delivery Address Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-pink-600" />
                <span>1. Delivery Address</span>
              </h3>

              {user && user.savedAddresses.length > 0 && (
                <button
                  type="button"
                  onClick={() => setUseCustomAddress(!useCustomAddress)}
                  className="text-xs text-pink-600 font-semibold hover:underline"
                >
                  {useCustomAddress ? 'Choose Saved Address' : '+ Add New Address'}
                </button>
              )}
            </div>

            {/* Saved Addresses Selector */}
            {!useCustomAddress && user && user.savedAddresses.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {user.savedAddresses.map((addr, idx) => (
                  <div
                    key={idx}
                    onClick={() => handleSelectSavedAddress(idx)}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                      selectedAddressIdx === idx && !useCustomAddress
                        ? 'border-pink-500 bg-pink-50/60 shadow-xs'
                        : 'border-stone-200 bg-white hover:border-pink-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-stone-900">{addr.fullName}</span>
                      <span className="text-[10px] bg-stone-100 px-1.5 py-0.5 rounded text-stone-600 font-medium">
                        {addr.addressType || 'Address'}
                      </span>
                    </div>
                    <p className="text-stone-600 line-clamp-2 leading-relaxed">
                      {addr.addressLine}, {addr.city}, {addr.state} - {addr.pinCode}
                    </p>
                    <p className="text-stone-500 font-mono text-[11px] mt-1">
                      📱 {addr.mobileNumber}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* Address Fields Form */}
            {(useCustomAddress || !user || user.savedAddresses.length === 0) && (
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Aarohi Sen"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white focus:outline-none focus:border-pink-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                      Mobile Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Delivery Address (House / Flat / Street) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Flat 402, Rosewood Heights, 12th Main Rd"
                    value={addressLine}
                    onChange={(e) => setAddressLine(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white focus:outline-none focus:border-pink-500"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2 sm:gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                      City *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Bengaluru"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white focus:outline-none focus:border-pink-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                      State *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Karnataka"
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white focus:outline-none focus:border-pink-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                      PIN Code *
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      placeholder="560038"
                      value={pinCode}
                      onChange={(e) => setPinCode(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white focus:outline-none focus:border-pink-500 font-mono"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. Payment Method Selector (Indian Payment Gateway Simulation) */}
          <div className="space-y-3 pt-3 border-t border-stone-100">
            <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-purple-600" />
              <span>2. Payment Option (Indian Gateway Ready)</span>
            </h3>

            <div className="space-y-2">
              {/* UPI Option */}
              <label 
                className={`flex flex-col p-3 rounded-2xl border cursor-pointer transition-all ${
                  paymentMethod === 'UPI' 
                    ? 'border-pink-500 bg-pink-50/50 shadow-xs' 
                    : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'UPI'}
                      onChange={() => setPaymentMethod('UPI')}
                      className="text-pink-600 focus:ring-pink-500"
                    />
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs font-bold text-stone-900">
                        UPI / QR (Google Pay, PhonePe, Paytm)
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                    FASTEST
                  </span>
                </div>

                {paymentMethod === 'UPI' && (
                  <div className="mt-3 pt-3 border-t border-pink-100 space-y-2 text-xs">
                    <p className="text-stone-500 text-[11px]">
                      Select preferred app or enter your UPI Virtual Payment Address (VPA):
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {[
                        { id: 'gpay', label: 'Google Pay' },
                        { id: 'phonepe', label: 'PhonePe' },
                        { id: 'paytm', label: 'Paytm' },
                        { id: 'custom', label: 'Other UPI ID' }
                      ].map(app => (
                        <button
                          type="button"
                          key={app.id}
                          onClick={() => setSelectedUpiApp(app.id as any)}
                          className={`px-3 py-1.5 rounded-xl border text-xs font-semibold ${
                            selectedUpiApp === app.id
                              ? 'bg-pink-500 text-white border-pink-500'
                              : 'bg-white border-stone-200 text-stone-700'
                          }`}
                        >
                          {app.label}
                        </button>
                      ))}
                    </div>
                    <input
                      type="text"
                      placeholder="e.g. mobile@upi or yourname@oksbi"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white font-mono"
                    />
                  </div>
                )}
              </label>

              {/* Cards Option */}
              <label 
                className={`flex flex-col p-3 rounded-2xl border cursor-pointer transition-all ${
                  paymentMethod === 'Card' 
                    ? 'border-pink-500 bg-pink-50/50 shadow-xs' 
                    : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'Card'}
                      onChange={() => setPaymentMethod('Card')}
                      className="text-pink-600 focus:ring-pink-500"
                    />
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-purple-600" />
                      <span className="text-xs font-bold text-stone-900">
                        Credit / Debit Cards (Visa, Mastercard, RuPay)
                      </span>
                    </div>
                  </div>
                </div>

                {paymentMethod === 'Card' && (
                  <div className="mt-3 pt-3 border-t border-pink-100 space-y-2 text-xs">
                    <input
                      type="text"
                      placeholder="Card Number (XXXX XXXX XXXX XXXX)"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white font-mono"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="MM / YY"
                        className="px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white text-center font-mono"
                      />
                      <input
                        type="password"
                        maxLength={4}
                        placeholder="CVV"
                        className="px-3 py-2 text-xs rounded-xl border border-stone-200 bg-white text-center font-mono"
                      />
                    </div>
                  </div>
                )}
              </label>

              {/* Net Banking */}
              <label 
                className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                  paymentMethod === 'NetBanking' 
                    ? 'border-pink-500 bg-pink-50/50 shadow-xs' 
                    : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'NetBanking'}
                    onChange={() => setPaymentMethod('NetBanking')}
                    className="text-pink-600 focus:ring-pink-500"
                  />
                  <div className="flex items-center gap-2">
                    <Landmark className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold text-stone-900">
                      Net Banking (All Indian Major Banks)
                    </span>
                  </div>
                </div>
              </label>

              {/* Cash on Delivery */}
              <label 
                className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                  paymentMethod === 'Cash on Delivery' 
                    ? 'border-pink-500 bg-pink-50/50 shadow-xs' 
                    : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'Cash on Delivery'}
                    onChange={() => setPaymentMethod('Cash on Delivery')}
                    className="text-pink-600 focus:ring-pink-500"
                  />
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-amber-600" />
                    <span className="text-xs font-bold text-stone-900">
                      Cash on Delivery (Pay upon arrival)
                    </span>
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* 3. Complete Order Summary */}
          <div className="space-y-3 pt-3 border-t border-stone-100">
            <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-pink-600" />
              <span>3. Order Summary ({cart.length} items)</span>
            </h3>

            <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
              {cart.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-stone-100">
                  <div className="flex items-center gap-2 min-w-0">
                    <img
                      src={item.product.images[0]}
                      alt=""
                      className="w-9 h-9 rounded-lg object-cover flex-shrink-0 border border-stone-100"
                    />
                    <div className="truncate">
                      <p className="font-medium text-stone-800 truncate">{item.product.name}</p>
                      <p className="text-[10px] text-stone-500">
                        Qty: {item.quantity} {item.selectedVariant ? `• ${item.selectedVariant.name}` : ''}
                      </p>
                    </div>
                  </div>
                  <span className="font-bold text-stone-900 ml-2">
                    ₹{item.product.price * item.quantity}
                  </span>
                </div>
              ))}
            </div>

            {/* Price lines */}
            <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-1.5 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Items Subtotal</span>
                <span className="font-medium text-stone-900">₹{cartSubtotal}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-pink-600 font-medium">
                  <span>Coupon Discount ({appliedCoupon?.code})</span>
                  <span>- ₹{discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600">
                <span>Shipping &amp; Packaging</span>
                <span className="text-emerald-700 font-medium">
                  {deliveryCharge === 0 ? 'FREE' : `₹${deliveryCharge}`}
                </span>
              </div>
              <div className="border-t border-stone-200 pt-2 flex justify-between font-bold text-sm text-stone-900">
                <span>Amount Payable</span>
                <span className="text-pink-600 font-display text-base">₹{cartTotal}</span>
              </div>
            </div>
          </div>

          {/* Place Order CTA Button */}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-pink-500 hover:opacity-95 text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all active:scale-98 disabled:opacity-75 cursor-pointer"
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Securing your order...</span>
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span>Place Order • ₹{cartTotal}</span>
              </span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

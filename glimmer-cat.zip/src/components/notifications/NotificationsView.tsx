import React from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, Sparkles, Tag, Package, Gift, CheckCheck, Trash2 } from 'lucide-react';

export const NotificationsView: React.FC = () => {
  const { 
    notifications, 
    markNotificationAsRead, 
    markAllNotificationsAsRead, 
    setCurrentTab,
    setSelectedCategory 
  } = useApp();

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'order':
        return <Package className="w-4 h-4 text-emerald-600" />;
      case 'discount':
        return <Tag className="w-4 h-4 text-rose-600" />;
      case 'arrival':
        return <Sparkles className="w-4 h-4 text-purple-600" />;
      default:
        return <Gift className="w-4 h-4 text-pink-600" />;
    }
  };

  const handleNotificationClick = (notif: any) => {
    markNotificationAsRead(notif.id);
    if (notif.type === 'order') {
      setCurrentTab('orders');
    } else if (notif.type === 'arrival') {
      setSelectedCategory('new-arrivals');
      setCurrentTab('categories');
    } else if (notif.type === 'discount' || notif.type === 'offer') {
      setCurrentTab('cart');
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-4 space-y-5 pb-24 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-stone-200 pb-3">
        <div>
          <h2 className="font-display text-2xl font-bold text-stone-900 flex items-center gap-2">
            <span>Notifications</span>
            <Bell className="w-5 h-5 text-pink-600" />
          </h2>
          <p className="text-xs text-stone-500">
            Exclusive drops, order shipments, and seasonal promotions
          </p>
        </div>

        {notifications.length > 0 && (
          <button
            onClick={markAllNotificationsAsRead}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-1 bg-pink-50 px-2.5 py-1 rounded-full"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>Mark all read</span>
          </button>
        )}
      </div>

      {/* Notifications List */}
      {notifications.length > 0 ? (
        <div className="space-y-3">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex gap-3.5 ${
                notif.read
                  ? 'bg-white border-stone-200/80 shadow-xs hover:border-pink-200'
                  : 'bg-pink-50/40 border-pink-200/90 shadow-xs hover:bg-pink-50/70'
              }`}
            >
              {/* Icon */}
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                notif.read ? 'bg-stone-100' : 'bg-pink-100 ring-2 ring-pink-200'
              }`}>
                {getNotificationIcon(notif.type)}
              </div>

              {/* Text info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1 mb-0.5">
                  <h3 className={`text-xs sm:text-sm font-semibold truncate ${
                    notif.read ? 'text-stone-800' : 'text-stone-900 font-bold'
                  }`}>
                    {notif.title}
                  </h3>
                  <span className="text-[10px] text-stone-400 whitespace-nowrap">
                    {notif.date}
                  </span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  {notif.message}
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-pink-600 bg-white border border-pink-100 px-2 py-0.5 rounded-md">
                    {notif.type.toUpperCase()}
                  </span>
                  <span className="text-[11px] text-stone-400 hover:text-pink-600 underline">
                    Tap to view
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-16 text-center space-y-3 bg-white rounded-3xl border border-pink-100 p-8">
          <div className="w-16 h-16 rounded-full bg-pink-50 text-pink-400 mx-auto flex items-center justify-center text-2xl">
            🔔
          </div>
          <h3 className="font-display text-base font-bold text-stone-900">
            All caught up!
          </h3>
          <p className="text-xs text-stone-500 max-w-xs mx-auto">
            You will be notified whenever new fairy collections drop or discounts go live.
          </p>
        </div>
      )}
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../products/ProductCard';
import { Search, X, SlidersHorizontal, ArrowUpDown, Sparkles, Filter } from 'lucide-react';
import { CategoryId } from '../../types';

export const SearchView: React.FC = () => {
  const { products, searchQuery, setSearchQuery } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('all'); // all, under-400, 400-700, above-700
  const [minRating, setMinRating] = useState<number>(0);
  const [minDiscount, setMinDiscount] = useState<number>(0);
  const [sortBy, setSortBy] = useState<'popularity' | 'price-asc' | 'price-desc' | 'newest' | 'rating'>('popularity');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  // Suggested quick keywords
  const popularKeywords = [
    'earrings',
    'cute earrings',
    'flower earrings',
    'butterfly earrings',
    'kan fuli',
    'necklaces',
    'bracelets',
    'rings',
    'gifts'
  ];

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      // 1. Text Query Search (name, category, description, tags, tagline)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = product.name.toLowerCase().includes(q);
        const matchesDesc = product.description.toLowerCase().includes(q);
        const matchesCategory = product.categoryName.toLowerCase().includes(q) || product.categoryId.toLowerCase().includes(q);
        const matchesTagline = product.tagline?.toLowerCase().includes(q) || false;
        const matchesTags = product.tags.some(t => t.toLowerCase().includes(q));

        if (!matchesName && !matchesDesc && !matchesCategory && !matchesTagline && !matchesTags) {
          return false;
        }
      }

      // 2. Category Filter
      if (selectedCategory !== 'all' && product.categoryId !== selectedCategory) {
        return false;
      }

      // 3. Price Filter
      if (selectedPriceRange === 'under-400' && product.price >= 400) return false;
      if (selectedPriceRange === '400-700' && (product.price < 400 || product.price > 700)) return false;
      if (selectedPriceRange === 'above-700' && product.price <= 700) return false;

      // 4. Rating Filter
      if (minRating > 0 && product.rating < minRating) return false;

      // 5. Discount Filter
      if (minDiscount > 0 && (!product.discountPercent || product.discountPercent < minDiscount)) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'newest') return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
      if (sortBy === 'rating') return b.rating - a.rating;
      // Default: popularity
      return b.reviewsCount - a.reviewsCount;
    });
  }, [products, searchQuery, selectedCategory, selectedPriceRange, minRating, minDiscount, sortBy]);

  const resetAllFilters = () => {
    setSelectedCategory('all');
    setSelectedPriceRange('all');
    setMinRating(0);
    setMinDiscount(0);
    setSortBy('popularity');
    setSearchQuery('');
  };

  const activeFiltersCount = 
    (selectedCategory !== 'all' ? 1 : 0) +
    (selectedPriceRange !== 'all' ? 1 : 0) +
    (minRating > 0 ? 1 : 0) +
    (minDiscount > 0 ? 1 : 0);

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-5 pb-24 animate-in fade-in duration-200">
      {/* Search Input Bar */}
      <div className="relative flex items-center">
        <div className="absolute left-4 text-stone-400">
          <Search className="w-5 h-5 text-pink-500" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search earrings, kan fuli, butterfly, necklaces..."
          className="w-full pl-12 pr-10 py-3.5 rounded-2xl bg-white border border-stone-200 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-100 text-sm shadow-xs transition-all"
          autoFocus
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3.5 p-1 text-stone-400 hover:text-stone-700 bg-stone-100 rounded-full"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Suggested Search Chips */}
      <div className="space-y-1.5">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
          <Sparkles className="w-3 h-3 text-pink-500" />
          <span>Popular Searches</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {popularKeywords.map((kw) => (
            <button
              key={kw}
              onClick={() => setSearchQuery(kw)}
              className={`text-xs px-3 py-1.5 rounded-full transition-all ${
                searchQuery.toLowerCase() === kw.toLowerCase()
                  ? 'bg-pink-500 text-white font-semibold shadow-xs'
                  : 'bg-white border border-stone-200 text-stone-700 hover:border-pink-300 hover:bg-pink-50/50'
              }`}
            >
              {kw}
            </button>
          ))}
        </div>
      </div>

      {/* Filters & Sorting Bar */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t border-stone-200/80">
        <div className="flex items-center gap-2">
          {/* Toggle Filters Button */}
          <button
            onClick={() => setShowFilterDrawer(!showFilterDrawer)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              showFilterDrawer || activeFiltersCount > 0
                ? 'bg-pink-50 border-pink-300 text-pink-700'
                : 'bg-white border-stone-200 text-stone-700 hover:border-stone-300'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
            {activeFiltersCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-pink-500 text-white text-[10px] flex items-center justify-center font-bold">
                {activeFiltersCount}
              </span>
            )}
          </button>

          {activeFiltersCount > 0 && (
            <button
              onClick={resetAllFilters}
              className="text-xs text-stone-400 hover:text-pink-600 underline"
            >
              Reset
            </button>
          )}
        </div>

        {/* Sort Dropdown */}
        <div className="flex items-center gap-1.5 text-xs text-stone-600">
          <ArrowUpDown className="w-3.5 h-3.5 text-stone-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-transparent font-semibold text-stone-800 focus:outline-none cursor-pointer border-none"
          >
            <option value="popularity">Sort: Popularity</option>
            <option value="newest">Sort: Newest Drops</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
          </select>
        </div>
      </div>

      {/* Filter Drawer / Panel */}
      {showFilterDrawer && (
        <div className="p-4 rounded-2xl bg-white border border-pink-100 shadow-sm space-y-4 animate-in fade-in slide-in-from-top-2 duration-200">
          {/* Categories */}
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-stone-700 block">Category</span>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`text-xs px-2.5 py-1 rounded-lg border ${
                  selectedCategory === 'all'
                    ? 'bg-pink-500 text-white border-pink-500 font-semibold'
                    : 'bg-stone-50 border-stone-200 text-stone-600'
                }`}
              >
                All Categories
              </button>
              {[
                { id: 'earrings', label: 'Earrings' },
                { id: 'kan-fuli', label: 'Kan Fuli' },
                { id: 'necklaces', label: 'Necklaces' },
                { id: 'bracelets', label: 'Bracelets' },
                { id: 'rings', label: 'Rings' },
                { id: 'hair-accessories', label: 'Hair Accessories' },
                { id: 'charms', label: 'Charms' },
                { id: 'gift-items', label: 'Gift Items' }
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`text-xs px-2.5 py-1 rounded-lg border ${
                    selectedCategory === cat.id
                      ? 'bg-pink-500 text-white border-pink-500 font-semibold'
                      : 'bg-stone-50 border-stone-200 text-stone-600'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-stone-700 block">Price Range</span>
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'all', label: 'All Prices' },
                { id: 'under-400', label: 'Under ₹400' },
                { id: '400-700', label: '₹400 - ₹700' },
                { id: 'above-700', label: '₹700 & Above' }
              ].map(p => (
                <button
                  key={p.id}
                  onClick={() => setSelectedPriceRange(p.id)}
                  className={`text-xs px-2.5 py-1 rounded-lg border ${
                    selectedPriceRange === p.id
                      ? 'bg-purple-600 text-white border-purple-600 font-semibold'
                      : 'bg-stone-50 border-stone-200 text-stone-600'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Rating & Discount */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <span className="text-xs font-semibold text-stone-700 block mb-1">Customer Rating</span>
              <div className="flex gap-1">
                {[0, 4.0, 4.8].map(rating => (
                  <button
                    key={rating}
                    onClick={() => setMinRating(rating)}
                    className={`text-xs px-2 py-1 rounded-lg border flex-1 text-center ${
                      minRating === rating
                        ? 'bg-amber-500 text-white border-amber-500 font-semibold'
                        : 'bg-stone-50 border-stone-200 text-stone-600'
                    }`}
                  >
                    {rating === 0 ? 'Any' : `${rating}★+`}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold text-stone-700 block mb-1">Discount</span>
              <div className="flex gap-1">
                {[0, 20, 35].map(disc => (
                  <button
                    key={disc}
                    onClick={() => setMinDiscount(disc)}
                    className={`text-xs px-2 py-1 rounded-lg border flex-1 text-center ${
                      minDiscount === disc
                        ? 'bg-rose-500 text-white border-rose-500 font-semibold'
                        : 'bg-stone-50 border-stone-200 text-stone-600'
                    }`}
                  >
                    {disc === 0 ? 'All' : `${disc}%+`}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-stone-500">
        <span>
          Showing <strong className="text-stone-900">{filteredProducts.length}</strong> items
          {searchQuery && <> for "<span className="text-pink-600 font-semibold">{searchQuery}</span>"</>}
        </span>
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="py-16 text-center space-y-3 bg-white rounded-3xl border border-pink-100 p-6">
          <div className="w-16 h-16 rounded-full bg-pink-50 text-pink-500 mx-auto flex items-center justify-center text-3xl">
            🐾
          </div>
          <h4 className="font-display text-lg font-bold text-stone-900">
            No matching sparkles found
          </h4>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            We couldn't find anything matching your filters. Try searching for “earrings”, “kan fuli”, or clearing some filters!
          </p>
          <button
            onClick={resetAllFilters}
            className="px-5 py-2 rounded-full bg-pink-500 text-white text-xs font-semibold shadow-xs hover:bg-pink-600 transition-colors"
          >
            Clear All Filters
          </button>
        </div>
      )}
    </div>
  );
};

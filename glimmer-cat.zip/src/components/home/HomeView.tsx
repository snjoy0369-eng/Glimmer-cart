import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../products/ProductCard';
import { CATEGORIES_DATA } from '../../data/categories';
import { 
  Search, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  Gift, 
  Crown, 
  Heart, 
  Star, 
  ShieldCheck, 
  Truck, 
  Package, 
  Flame,
  ArrowRight
} from 'lucide-react';
import { CategoryId } from '../../types';

export const HomeView: React.FC = () => {
  const { 
    products, 
    banners, 
    setCurrentTab, 
    setSelectedCategory, 
    setSearchQuery,
    applyCoupon,
    setIsAdminMode
  } = useApp();

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);

  // Auto scroll banners
  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setActiveBannerIdx((prev) => (prev + 1) % banners.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [banners.length]);

  const handleCategoryClick = (catId: CategoryId) => {
    setSelectedCategory(catId);
    setCurrentTab('categories');
  };

  // Filtered product collections with graceful fallbacks so owner's added products show immediately
  const featuredEarrings = products.filter(p => p.categoryId === 'earrings' || p.categoryId === 'kan-fuli').length > 0
    ? products.filter(p => p.categoryId === 'earrings' || p.categoryId === 'kan-fuli')
    : products;
  const trendingProducts = products.filter(p => p.isTrending).length > 0
    ? products.filter(p => p.isTrending)
    : products;
  const newArrivals = products.filter(p => p.isNewArrival).length > 0
    ? products.filter(p => p.isNewArrival)
    : products;
  const bestSellers = products.filter(p => p.isBestSeller).length > 0
    ? products.filter(p => p.isBestSeller)
    : products;
  const giftPicks = products.filter(p => p.isGiftPick || p.categoryId === 'gift-items').length > 0
    ? products.filter(p => p.isGiftPick || p.categoryId === 'gift-items')
    : products;
  const limitedCollection = products.filter(p => p.isLimitedCollection);
  const customerFavorites = products;

  return (
    <div className="space-y-8 pb-20 pt-2 animate-in fade-in duration-300">
      {/* 1. Mobile Search Bar */}
      <div className="px-4 max-w-7xl mx-auto">
        <div 
          onClick={() => setCurrentTab('search')}
          className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white border border-stone-200/80 shadow-xs hover:border-pink-300 transition-all cursor-pointer group"
        >
          <Search className="w-4 h-4 text-stone-400 group-hover:text-pink-500 transition-colors" />
          <div className="flex-1 text-xs text-stone-500 font-normal truncate">
            Search floral earrings, cat opal pendants, kan fuli...
          </div>
          <span className="text-[10px] uppercase font-bold tracking-wider text-pink-600 bg-pink-50 px-2 py-0.5 rounded-full">
            Explore
          </span>
        </div>
      </div>

      {/* 2. Promotional Banners Carousel */}
      <div className="px-4 max-w-7xl mx-auto">
        <div className="relative w-full rounded-3xl overflow-hidden shadow-[0_8px_30px_rgba(244,114,182,0.12)] border border-pink-100 bg-white">
          <div 
            className="flex transition-transform duration-500 ease-out"
            style={{ transform: `translateX(-${activeBannerIdx * 100}%)` }}
          >
            {banners.map((banner) => (
              <div 
                key={banner.id} 
                className="w-full flex-shrink-0 relative min-h-[220px] sm:min-h-[260px] md:min-h-[300px] flex items-center overflow-hidden"
              >
                {/* Background Banner Image */}
                <img
                  src={banner.imageUrl}
                  alt={banner.title}
                  className="absolute inset-0 w-full h-full object-cover object-center"
                />
                
                {/* Dreamy Gradient Scrim */}
                <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/80 to-transparent sm:w-2/3" />

                {/* Banner Content */}
                <div className="relative z-10 p-6 sm:p-10 max-w-md space-y-2.5">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-500 text-white text-[10px] sm:text-xs font-bold uppercase tracking-wider shadow-xs">
                    <Sparkles className="w-3 h-3" />
                    <span>{banner.badge}</span>
                  </div>

                  <h2 className="font-display text-xl sm:text-3xl font-bold text-stone-900 leading-tight">
                    {banner.title}
                  </h2>

                  <p className="text-xs sm:text-sm text-stone-600 line-clamp-2">
                    {banner.subtitle}
                  </p>

                  <div className="pt-2 flex items-center gap-3">
                    <button
                      onClick={() => {
                        if (banner.targetCategory) {
                          handleCategoryClick(banner.targetCategory);
                        } else {
                          setCurrentTab('categories');
                        }
                      }}
                      className="px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white font-bold text-xs sm:text-sm shadow-md flex items-center gap-1.5 transition-all transform active:scale-95"
                    >
                      <span>{banner.buttonText}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    {banner.discountCode && (
                      <button
                        onClick={() => applyCoupon(banner.discountCode!)}
                        className="text-[11px] font-mono font-bold bg-white/90 border border-pink-200 text-pink-700 px-2.5 py-1.5 rounded-full hover:bg-pink-50 shadow-xs"
                      >
                        Use {banner.discountCode}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Dots Indicator */}
          {banners.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
              {banners.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveBannerIdx(i)}
                  className={`h-1.5 rounded-full transition-all ${
                    activeBannerIdx === i 
                      ? 'w-6 bg-pink-600' 
                      : 'w-1.5 bg-stone-300 hover:bg-stone-400'
                  }`}
                />
              ))}
            </div>
          )}

          {/* Prev/Next Buttons (Desktop) */}
          {banners.length > 1 && (
            <>
              <button
                onClick={() => setActiveBannerIdx((prev) => (prev - 1 + banners.length) % banners.length)}
                className="hidden sm:flex absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 hover:bg-white text-stone-700 shadow-md items-center justify-center transition-all z-20"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setActiveBannerIdx((prev) => (prev + 1) % banners.length)}
                className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 hover:bg-white text-stone-700 shadow-md items-center justify-center transition-all z-20"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* 3. Shop by Category */}
      <section className="px-4 max-w-7xl mx-auto space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900 flex items-center gap-1.5">
              <span>Shop by Category</span>
              <span className="text-pink-500 text-sm">🐾</span>
            </h3>
            <p className="text-xs text-stone-500">
              Handcrafted accessories tailored for your aesthetic
            </p>
          </div>
          <button
            onClick={() => {
              setSelectedCategory(null);
              setCurrentTab('categories');
            }}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Categories Horizontal Scroll */}
        <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
          {CATEGORIES_DATA.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.id)}
              className="group flex flex-col items-center flex-shrink-0 w-20 sm:w-24 text-center focus:outline-none"
            >
              <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full p-1 bg-gradient-to-tr from-pink-300 via-purple-200 to-amber-200 shadow-xs group-hover:shadow-md transition-all group-hover:scale-105">
                <div className="w-full h-full rounded-full overflow-hidden bg-white border border-white">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                {/* Mini paw sticker on hover */}
                <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white shadow-xs border border-pink-100 flex items-center justify-center text-[10px]">
                  ✨
                </div>
              </div>
              <span className="mt-2 text-xs font-semibold text-stone-800 group-hover:text-pink-600 transition-colors line-clamp-1">
                {cat.name}
              </span>
              <span className="text-[9px] text-pink-600 font-medium line-clamp-1">
                {cat.highlightTag}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Boutique Setup Prompt if no products added yet */}
      {products.length === 0 && (
        <section className="px-4 max-w-7xl mx-auto">
          <div className="bg-gradient-to-r from-pink-50 via-purple-50 to-pink-50 border-2 border-dashed border-pink-200 rounded-3xl p-8 text-center space-y-4 shadow-xs">
            <div className="w-14 h-14 rounded-full bg-white text-pink-500 mx-auto flex items-center justify-center shadow-xs text-2xl">
              ✨
            </div>
            <div className="max-w-md mx-auto space-y-1.5">
              <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900">
                Welcome to Glimmer Cart!
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Your boutique is clean and ready. Easily add your own earrings, kan fuli, necklaces, and accessories using photos from your phone or computer.
              </p>
            </div>
            <button
              onClick={() => {
                setIsAdminMode(true);
                setCurrentTab('admin');
              }}
              className="px-6 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white text-xs sm:text-sm font-bold shadow-md inline-flex items-center gap-2 transition-all transform active:scale-95"
            >
              <span>+ Add Your First Product</span>
            </button>
          </div>
        </section>
      )}

      {/* 4. Featured Earrings & Viral Kan Fuli */}
      <section className="px-4 max-w-7xl mx-auto space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-pink-600 uppercase tracking-wider bg-pink-50 px-2 py-0.5 rounded-full">
                Signature Collection
              </span>
            </div>
            <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900 mt-0.5">
              Featured Earrings &amp; Kan Fuli
            </h3>
          </div>
          <button
            onClick={() => handleCategoryClick('kan-fuli')}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-0.5"
          >
            <span>See More</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {featuredEarrings.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 5. Trending Now */}
      <section className="px-4 max-w-7xl mx-auto space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900">
                Trending Now
              </h3>
              <p className="text-xs text-stone-500">Most viewed &amp; viral on Instagram</p>
            </div>
          </div>
          <button
            onClick={() => {
              setSearchQuery('trending');
              setCurrentTab('search');
            }}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {trendingProducts.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} badgeText="Trending" />
          ))}
        </div>
      </section>

      {/* Cat Sparkle Mid-Banner: Gift Hamper Spotlight */}
      <section className="px-4 max-w-7xl mx-auto">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-pink-500 via-purple-500 to-pink-600 text-white p-6 sm:p-8 shadow-xl">
          {/* Subtle cat watermark */}
          <div className="absolute -right-8 -bottom-8 opacity-15 pointer-events-none text-white text-9xl font-display">
            🐾
          </div>
          <div className="relative z-10 max-w-lg space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-widest bg-white/20 px-2.5 py-1 rounded-full">
              Handmade &amp; Hypoallergenic
            </span>
            <h3 className="font-display text-xl sm:text-2xl font-bold">
              The Glimmer Cart Fairy Box ✨
            </h3>
            <p className="text-xs sm:text-sm text-pink-100">
              Curated jewelry hampers featuring our viral Kan Fuli, Opal Pendants, and Velvet Cat Ear clips, wrapped in custom musical boxes.
            </p>
            <div className="pt-2">
              <button
                onClick={() => handleCategoryClick('gift-items')}
                className="px-5 py-2 rounded-full bg-white text-pink-700 font-bold text-xs shadow-md hover:bg-pink-50 transition-all flex items-center gap-1.5"
              >
                <span>Shop Gift Hampers</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. New Arrivals */}
      <section className="px-4 max-w-7xl mx-auto space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-600">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900">
                New Arrivals
              </h3>
              <p className="text-xs text-stone-500">Fresh drops added this week</p>
            </div>
          </div>
          <button
            onClick={() => handleCategoryClick('new-arrivals')}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {newArrivals.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 7. Best Sellers */}
      <section className="px-4 max-w-7xl mx-auto space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center text-pink-600">
              <Crown className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900">
                Best Sellers
              </h3>
              <p className="text-xs text-stone-500">Pieces everyone is falling in love with</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {bestSellers.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 8. Cute Gift Picks */}
      <section className="px-4 max-w-7xl mx-auto space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-600">
              <Gift className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900">
                Cute Gift Picks
              </h3>
              <p className="text-xs text-stone-500">Thoughtful surprises for besties &amp; loved ones</p>
            </div>
          </div>
          <button
            onClick={() => handleCategoryClick('gift-items')}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-0.5"
          >
            <span>Gift Guide</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {giftPicks.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 9. Limited Collection */}
      {limitedCollection.length > 0 && (
        <section className="px-4 max-w-7xl mx-auto space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-purple-600 uppercase tracking-wider bg-purple-50 px-2 py-0.5 rounded-full">
                Limited Vault
              </span>
              <h3 className="font-display text-lg sm:text-xl font-bold text-stone-900 mt-0.5">
                Limited Collection
              </h3>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
            {limitedCollection.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}

      {/* 10. Customer Favorites & Testimonials */}
      <section className="px-4 max-w-7xl mx-auto space-y-4">
        <div className="text-center space-y-1">
          <div className="inline-flex items-center gap-1 text-pink-600 text-xs font-bold uppercase tracking-wider">
            <Heart className="w-3 h-3 fill-pink-500" />
            <span>Loved by 10,000+ Girls</span>
          </div>
          <h3 className="font-display text-xl sm:text-2xl font-bold text-stone-900">
            Customer Favorites
          </h3>
          <p className="text-xs text-stone-500 max-w-md mx-auto">
            Real stories from our magical Glimmer Cart community
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-4 rounded-2xl bg-white border border-pink-100 shadow-xs space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-stone-700 italic">
              "The Celestial Kitty Kan Fuli is absolute magic! I get stopped everywhere asking where I bought it. Packaging felt so royal."
            </p>
            <div className="pt-1 flex items-center justify-between text-[11px] text-stone-500">
              <span className="font-bold text-stone-800">Meera K.</span>
              <span className="text-emerald-700 font-medium">✓ Verified Buyer</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-pink-100 shadow-xs space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-stone-700 italic">
              "Super fast delivery! The opal cat pendant has this dreamy rainbow flash in the sun and hasn't tarnished at all even in humid weather."
            </p>
            <div className="pt-1 flex items-center justify-between text-[11px] text-stone-500">
              <span className="font-bold text-stone-800">Tanvi P.</span>
              <span className="text-emerald-700 font-medium">✓ Verified Buyer</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-pink-100 shadow-xs space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-stone-700 italic">
              "Ordered the luxury gift hamper for my best friend's birthday and she literally cried happy tears. The velvet cat box is so cute!"
            </p>
            <div className="pt-1 flex items-center justify-between text-[11px] text-stone-500">
              <span className="font-bold text-stone-800">Sanya R.</span>
              <span className="text-emerald-700 font-medium">✓ Verified Buyer</span>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Trust Indicators */}
      <section className="px-4 max-w-7xl mx-auto pt-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-5 rounded-3xl bg-white border border-pink-100 shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-pink-50 flex items-center justify-center text-pink-600 flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">Anti-Tarnish</h4>
              <p className="text-[10px] text-stone-500">Nickel-free &amp; hypoallergenic</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-600 flex-shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">Free Delivery</h4>
              <p className="text-[10px] text-stone-500">On all orders above ₹499</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600 flex-shrink-0">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">Fairytale Packaging</h4>
              <p className="text-[10px] text-stone-500">With velvet keepsake pouch</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 flex-shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">7-Day Guarantee</h4>
              <p className="text-[10px] text-stone-500">Hassle-free return policy</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

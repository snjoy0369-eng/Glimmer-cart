import React from 'react';
import { useApp, AppTab } from '../../context/AppContext';
import { Home, LayoutGrid, Heart, ShoppingBag, User } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab, wishlist, cartCount } = useApp();

  const navItems: { id: AppTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'home',
      label: 'Home',
      icon: <Home className="w-5 h-5" />
    },
    {
      id: 'categories',
      label: 'Categories',
      icon: <LayoutGrid className="w-5 h-5" />
    },
    {
      id: 'wishlist',
      label: 'Wishlist',
      icon: <Heart className="w-5 h-5" />,
      badge: wishlist.length > 0 ? wishlist.length : undefined
    },
    {
      id: 'cart',
      label: 'Cart',
      icon: <ShoppingBag className="w-5 h-5" />,
      badge: cartCount > 0 ? cartCount : undefined
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: <User className="w-5 h-5" />
    }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-stone-200/70 shadow-[0_-4px_20px_rgba(0,0,0,0.03)] px-3 py-1.5 transition-all">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {navItems.map(item => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 min-w-[56px] ${
                isActive 
                  ? 'text-pink-600 scale-105' 
                  : 'text-stone-400 hover:text-stone-600'
              }`}
            >
              {/* Active subtle pill background */}
              {isActive && (
                <div className="absolute inset-0 bg-pink-50/90 rounded-2xl -z-10 animate-in fade-in zoom-in-95 duration-200" />
              )}

              {/* Icon Container with Badge */}
              <div className="relative flex items-center justify-center">
                {item.icon}
                {item.badge !== undefined && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 px-1 rounded-full bg-pink-500 text-white text-[9px] font-bold flex items-center justify-center shadow-xs">
                    {item.badge}
                  </span>
                )}
              </div>

              {/* Label */}
              <span className={`text-[10px] mt-1 font-medium tracking-tight ${
                isActive ? 'font-semibold text-pink-600' : 'text-stone-500'
              }`}>
                {item.label}
              </span>

              {/* Tiny cat-paw / sparkle active dot */}
              {isActive && (
                <div className="w-1 h-1 rounded-full bg-pink-500 mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

import React from 'react';
import { CatLogo } from './CatLogo';
import { useApp } from '../../context/AppContext';
import { Sparkles, Heart, ShieldCheck, Truck, RefreshCw, Mail } from 'lucide-react';
import { CATEGORIES } from '../../data/categories';
import { CategoryId } from '../../types';

export const Footer: React.FC = () => {
  const { setCurrentTab, setSelectedCategory } = useApp();

  const handleCategoryClick = (catId: CategoryId) => {
    setSelectedCategory(catId);
    setCurrentTab('categories');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTabClick = (tab: any) => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-stone-900 text-stone-300 pt-12 pb-24 sm:pb-12 border-t border-stone-800 relative z-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Value Prop Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-8 border-b border-stone-800 text-xs">
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-stone-800/60 border border-stone-700/50">
            <Truck className="w-5 h-5 text-pink-400 shrink-0" />
            <div>
              <p className="font-semibold text-white">Free Delivery</p>
              <p className="text-[11px] text-stone-400">On all orders over ₹499</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-stone-800/60 border border-stone-700/50">
            <ShieldCheck className="w-5 h-5 text-pink-400 shrink-0" />
            <div>
              <p className="font-semibold text-white">Anti-Tarnish</p>
              <p className="text-[11px] text-stone-400">Hypoallergenic &amp; nickel-free</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-stone-800/60 border border-stone-700/50">
            <RefreshCw className="w-5 h-5 text-pink-400 shrink-0" />
            <div>
              <p className="font-semibold text-white">7-Day Returns</p>
              <p className="text-[11px] text-stone-400">Hassle-free replacements</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-stone-800/60 border border-stone-700/50">
            <Sparkles className="w-5 h-5 text-pink-400 shrink-0" />
            <div>
              <p className="font-semibold text-white">Signature Box</p>
              <p className="text-[11px] text-stone-400">Velvet pouch &amp; gift ready</p>
            </div>
          </div>
        </div>

        {/* Main Footer Links & Info */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div className="space-y-4 md:col-span-1">
            <div className="p-2 -ml-2 inline-block rounded-2xl bg-white/5 border border-white/10">
              <CatLogo size="md" />
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              <strong>GLIMMER CART</strong> is your dreamy destination for cute, playful, and high-fashion jewelry. From viral Kan Fuli to fairy-box sets, every piece is handcrafted to sparkle.
            </p>
            <div className="flex items-center gap-2 text-xs text-pink-300 font-medium">
              <Heart className="w-3.5 h-3.5 fill-pink-400 text-pink-400" />
              <span>A portion of every sale supports animal rescue shelters.</span>
            </div>
          </div>

          {/* Categories Column */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-1.5">
              <span>Categories</span>
              <Sparkles className="w-3 h-3 text-pink-400" />
            </h4>
            <ul className="space-y-2 text-xs">
              {CATEGORIES.slice(0, 6).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => handleCategoryClick(cat.id)}
                    className="hover:text-pink-300 transition-colors flex items-center gap-1.5 cursor-pointer text-left"
                  >
                    <span>{cat.emoji}</span>
                    <span>{cat.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Glimmer Cart Care
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => handleTabClick('profile')}
                  className="hover:text-pink-300 transition-colors cursor-pointer"
                >
                  My Profile &amp; Account
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleTabClick('orders')}
                  className="hover:text-pink-300 transition-colors cursor-pointer"
                >
                  Track My Orders
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleTabClick('wishlist')}
                  className="hover:text-pink-300 transition-colors cursor-pointer"
                >
                  My Wishlist
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleTabClick('cart')}
                  className="hover:text-pink-300 transition-colors cursor-pointer"
                >
                  Shopping Cart
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleTabClick('profile')}
                  className="hover:text-pink-300 transition-colors cursor-pointer"
                >
                  About Glimmer Cart &amp; Policy
                </button>
              </li>
            </ul>
          </div>

          {/* Contact / Newsletter */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Get In Touch
            </h4>
            <p className="text-xs text-stone-400 leading-relaxed">
              Have a question about a piece or need custom jewelry gifting assistance?
            </p>
            <div className="flex items-center gap-2 text-xs text-stone-300">
              <Mail className="w-4 h-4 text-pink-400 shrink-0" />
              <a href="mailto:care@glimmercart.com" className="hover:text-pink-300 transition-colors">
                care@glimmercart.com
              </a>
            </div>
            <div className="pt-2">
              <span className="text-[11px] text-stone-500 block">
                Store Location: Mumbai &amp; Bengaluru, India
              </span>
              <span className="text-[11px] text-stone-500 block">
                Pan-India Express Shipping
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Copyright Strip */}
        <div className="pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© 2026 GLIMMER CART. All rights reserved. Handcrafted with love &amp; sparkle.</p>
          <div className="flex items-center gap-4 text-[11px]">
            <button onClick={() => handleTabClick('profile')} className="hover:text-stone-300 transition-colors cursor-pointer">
              Privacy Policy
            </button>
            <span>•</span>
            <button onClick={() => handleTabClick('profile')} className="hover:text-stone-300 transition-colors cursor-pointer">
              Terms &amp; Conditions
            </button>
            <span>•</span>
            <button onClick={() => handleTabClick('profile')} className="hover:text-stone-300 transition-colors cursor-pointer">
              Shipping &amp; Returns
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

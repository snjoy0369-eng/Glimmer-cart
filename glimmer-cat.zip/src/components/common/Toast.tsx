import React from 'react';
import { useApp } from '../../context/AppContext';
import { Sparkles, CheckCircle2, Info, AlertCircle, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 max-w-[90vw] sm:max-w-md pointer-events-none">
      {toasts.map(toast => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/95 backdrop-blur-md border border-pink-100/80 shadow-[0_8px_30px_rgb(0,0,0,0.08)] text-stone-800 text-sm font-medium transition-all duration-300 animate-in fade-in slide-in-from-top-3"
        >
          {toast.type === 'sparkle' ? (
            <div className="w-7 h-7 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 flex-shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
          ) : toast.type === 'error' ? (
            <div className="w-7 h-7 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 flex-shrink-0">
              <AlertCircle className="w-4 h-4" />
            </div>
          ) : toast.type === 'info' ? (
            <div className="w-7 h-7 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 flex-shrink-0">
              <Info className="w-4 h-4" />
            </div>
          ) : (
            <div className="w-7 h-7 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 flex-shrink-0">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          )}

          <p className="flex-1 text-xs sm:text-sm font-medium pr-1 text-stone-800">
            {toast.message}
          </p>

          <button
            onClick={() => removeToast(toast.id)}
            className="p-1 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};

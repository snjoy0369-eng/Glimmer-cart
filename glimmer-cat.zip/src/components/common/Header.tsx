import React from 'react';
import { useApp } from '../../context/AppContext';
import { CatLogo } from './CatLogo';
import { UserAvatar } from './UserAvatar';
import { Search, Heart, ShoppingBag, Bell, ShieldCheck } from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    currentTab, 
    setCurrentTab, 
    wishlist, 
    cartCount, 
    unreadNotificationsCount,
    isAdminMode,
    openAuthModal,
    user
  } = useApp();

  return (
    <header className="sticky top-0 z-40 w-full bg-[#FAF8F5]/90 backdrop-blur-md border-b border-pink-100/70 transition-all">
      {/* Top micro announcement bar */}
      <div className="bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 text-white text-[11px] font-medium py-1 px-3 text-center tracking-wide flex items-center justify-center gap-1.5 shadow-inner">
        <span>✨ Flat 15% OFF your first dreamy accessory with code</span>
        <span className="bg-white/20 px-1.5 py-0.5 rounded font-bold tracking-wider">GLIMMER15</span>
        <span className="hidden sm:inline">| Free Shipping above ₹499</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
        {/* Left: Brand Identity */}
        <button 
          onClick={() => setCurrentTab('home')}
          className="flex items-center text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-pink-300 rounded-lg"
        >
          <CatLogo size="md" withText={true} />
        </button>

        {/* Center/Quick Search Pill (Interactive) */}
        <div 
          onClick={() => setCurrentTab('search')}
          className="hidden md:flex flex-1 max-w-sm mx-4 items-center gap-2 px-3.5 py-2 rounded-full bg-white border border-stone-200/80 shadow-xs hover:border-pink-300 transition-all cursor-pointer text-stone-400 group"
        >
          <Search className="w-4 h-4 text-stone-400 group-hover:text-pink-500 transition-colors" />
          <span className="text-xs text-stone-500 font-normal">Search earrings, kan fuli, necklaces...</span>
          <span className="ml-auto text-[10px] bg-stone-100 text-stone-500 px-1.5 py-0.5 rounded font-mono">⌘K</span>
        </div>

        {/* Right Icons: Search (mobile), Notifications, Wishlist, Cart */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Admin badge if active */}
          {isAdminMode && (
            <button
              onClick={() => setCurrentTab('admin')}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-semibold border border-purple-200"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          )}

          {/* Mobile Search Button */}
          <button
            onClick={() => setCurrentTab('search')}
            className={`p-2 rounded-full transition-colors relative md:hidden ${
              currentTab === 'search' ? 'text-pink-600 bg-pink-50' : 'text-stone-700 hover:bg-stone-100'
            }`}
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Notifications */}
          <button
            onClick={() => setCurrentTab('notifications')}
            className={`p-2 rounded-full transition-colors relative ${
              currentTab === 'notifications' ? 'text-pink-600 bg-pink-50' : 'text-stone-700 hover:bg-stone-100'
            }`}
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-pink-500 ring-2 ring-white animate-pulse" />
            )}
          </button>

          {/* Wishlist */}
          <button
            onClick={() => setCurrentTab('wishlist')}
            className={`p-2 rounded-full transition-colors relative ${
              currentTab === 'wishlist' ? 'text-pink-600 bg-pink-50' : 'text-stone-700 hover:bg-stone-100'
            }`}
            aria-label="Wishlist"
          >
            <Heart className={`w-5 h-5 ${wishlist.length > 0 ? 'fill-pink-50 text-pink-500' : ''}`} />
            {wishlist.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[17px] h-[17px] px-1 rounded-full bg-pink-500 text-white text-[10px] font-bold flex items-center justify-center shadow-xs">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Cart */}
          <button
            onClick={() => setCurrentTab('cart')}
            className={`p-2 rounded-full transition-colors relative ${
              currentTab === 'cart' ? 'text-pink-600 bg-pink-50' : 'text-stone-700 hover:bg-stone-100'
            }`}
            aria-label="Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[17px] h-[17px] px-1 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 text-white text-[10px] font-bold flex items-center justify-center shadow-xs animate-scale">
                {cartCount}
              </span>
            )}
          </button>

          {/* User Avatar or Sign In (Desktop) */}
          <div className="hidden sm:block ml-1">
            {user ? (
              <button
                onClick={() => setCurrentTab('profile')}
                className="flex items-center gap-2 p-1 pl-1.5 pr-3 rounded-full border border-pink-200/80 bg-white hover:bg-pink-50/70 transition-colors shadow-xs"
              >
                <UserAvatar user={user} size="xs" />
                <span className="text-xs font-semibold text-stone-800 max-w-[100px] truncate">
                  {user.name.split(' ')[0]}
                </span>
              </button>
            ) : (
              <button
                onClick={() => openAuthModal('login')}
                className="text-xs font-semibold px-3 py-1.5 rounded-full bg-pink-500 hover:bg-pink-600 text-white shadow-xs transition-all"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

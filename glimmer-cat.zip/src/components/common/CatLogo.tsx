import React from 'react';

interface CatLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  withText?: boolean;
  withSparkle?: boolean;
  className?: string;
}

export const CatLogo: React.FC<CatLogoProps> = ({
  size = 'md',
  withText = true,
  withSparkle = true,
  className = ''
}) => {
  const sizeMap = {
    sm: { icon: 'w-7 h-7', text: 'text-base', sub: 'text-[9px]' },
    md: { icon: 'w-9 h-9', text: 'text-xl', sub: 'text-[10px]' },
    lg: { icon: 'w-14 h-14', text: 'text-2xl', sub: 'text-xs' },
    xl: { icon: 'w-20 h-20', text: 'text-3xl', sub: 'text-sm' }
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Cat Emblem with Sparkle Aura */}
      <div className={`relative ${currentSize.icon} flex-shrink-0 flex items-center justify-center`}>
        {/* Soft Radial Glow */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-pink-200/60 via-purple-200/50 to-amber-100/50 blur-[2px] transform transition-transform duration-300 hover:scale-110" />
        
        {/* Custom SVG Cat + Tiara Jewel Silhouette */}
        <svg 
          viewBox="0 0 100 100" 
          className="relative w-full h-full text-pink-700 drop-shadow-sm transition-transform duration-300 hover:rotate-3"
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Subtle Outer Ring */}
          <circle cx="50" cy="50" r="46" stroke="url(#ringGrad)" strokeWidth="2.5" strokeDasharray="4 2" opacity="0.65" />
          
          {/* Cat Head Outline with Curved Whiskers */}
          <path
            d="M25 46 C 22 28, 38 31, 39 42 C 44 40, 56 40, 61 42 C 62 31, 78 28, 75 46 C 81 54, 78 68, 69 76 C 60 83, 40 83, 31 76 C 22 68, 19 54, 25 46 Z"
            fill="url(#catGrad)"
            stroke="#9D174D"
            strokeWidth="2"
            strokeLinejoin="round"
          />

          {/* Inner Ear Highlights */}
          <path d="M29 40 C 31 32, 36 34, 37 42" fill="#FCE7F3" opacity="0.9" />
          <path d="M71 40 C 69 32, 64 34, 63 42" fill="#FCE7F3" opacity="0.9" />

          {/* Peaceful Dreamy Closed Lashes / Eyes */}
          <path d="M37 57 Q 42 61 45 57" stroke="#831843" strokeWidth="2.2" strokeLinecap="round" />
          <path d="M55 57 Q 58 61 63 57" stroke="#831843" strokeWidth="2.2" strokeLinecap="round" />

          {/* Tiny Heart Nose */}
          <path d="M50 63 L 47.8 60.5 A 1.5 1.5 0 0 1 50 58.5 A 1.5 1.5 0 0 1 52.2 60.5 Z" fill="#BE185D" />

          {/* Whiskers */}
          <path d="M23 58 L 33 60 M 22 64 L 32 63" stroke="#9D174D" strokeWidth="1.5" strokeLinecap="round" opacity="0.75" />
          <path d="M77 58 L 67 60 M 78 64 L 68 63" stroke="#9D174D" strokeWidth="1.5" strokeLinecap="round" opacity="0.75" />

          {/* Little Sparkle Gem Tiara between ears */}
          <polygon points="50,30 53,35 58,36 54,40 55,45 50,42 45,45 46,40 42,36 47,35" fill="url(#goldGrad)" stroke="#B45309" strokeWidth="0.8" />
          <circle cx="50" cy="38" r="1.8" fill="#FFFFFF" />

          {/* Gradients */}
          <defs>
            <linearGradient id="catGrad" x1="20" y1="20" x2="80" y2="80" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFF1F2" />
              <stop offset="0.6" stopColor="#FDE2E4" />
              <stop offset="1" stopColor="#E9D5FF" />
            </linearGradient>
            <linearGradient id="ringGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#F472B6" />
              <stop offset="0.5" stopColor="#C084FC" />
              <stop offset="1" stopColor="#FBBF24" />
            </linearGradient>
            <linearGradient id="goldGrad" x1="42" y1="30" x2="58" y2="45" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FDE68A" />
              <stop offset="0.5" stopColor="#F59E0B" />
              <stop offset="1" stopColor="#D97706" />
            </linearGradient>
          </defs>
        </svg>

        {/* Tiny Floating Sparkle Star */}
        {withSparkle && (
          <div className="absolute -top-1 -right-1 text-amber-400 animate-pulse text-[11px] leading-none pointer-events-none">
            ✨
          </div>
        )}
      </div>

      {/* Brand Typography */}
      {withText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1">
            <span className={`font-display font-bold tracking-tight text-stone-900 ${currentSize.text}`}>
              Glimmer Cart
            </span>
            <span className="text-pink-500 text-xs animate-bounce" style={{ animationDuration: '3s' }}>
              ✦
            </span>
          </div>
          <span className={`text-stone-500 tracking-wider uppercase font-medium ${currentSize.sub}`}>
            Dreamy Accessories
          </span>
        </div>
      )}
    </div>
  );
};

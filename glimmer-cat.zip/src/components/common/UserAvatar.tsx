import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { UserProfile } from '../../types';

interface UserAvatarProps {
  user?: Partial<UserProfile> | null;
  name?: string;
  avatarUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showSparkleBadge?: boolean;
}

export const UserAvatar: React.FC<UserAvatarProps> = ({
  user,
  name: explicitName,
  avatarUrl: explicitAvatarUrl,
  size = 'md',
  className = '',
  showSparkleBadge = false,
}) => {
  const [imageError, setImageError] = useState(false);

  const name = explicitName || user?.name || 'Customer';
  const avatarUrl = explicitAvatarUrl ?? user?.avatarUrl;

  // Extract initial
  const initial = (name.trim().charAt(0) || 'G').toUpperCase();

  // Size classes
  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-12 h-12 text-sm',
    lg: 'w-16 h-16 sm:w-20 sm:h-20 text-xl sm:text-2xl',
    xl: 'w-24 h-24 text-3xl'
  }[size];

  const hasPhoto = Boolean(avatarUrl && avatarUrl.trim().length > 0 && !imageError);

  return (
    <div className={`relative inline-block select-none ${className}`}>
      <div
        className={`${sizeClasses} rounded-full overflow-hidden flex items-center justify-center font-bold font-display shadow-xs ring-2 ring-white transition-all`}
      >
        {hasPhoto ? (
          <img
            src={avatarUrl}
            alt={name}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover rounded-full"
            referrerPolicy="no-referrer"
          />
        ) : (
          /* Clean Default Glimmer Cart Avatar */
          <div className="w-full h-full bg-gradient-to-tr from-pink-500 via-rose-400 to-purple-500 text-white flex items-center justify-center relative">
            <span className="drop-shadow-xs tracking-tight">{initial}</span>
            {/* Soft decorative shimmer overlay */}
            <div className="absolute inset-0 bg-white/10 rounded-full pointer-events-none" />
          </div>
        )}
      </div>

      {showSparkleBadge && (
        <span
          className="absolute -bottom-1 -right-1 rounded-full bg-pink-500 text-white flex items-center justify-center shadow-xs border-2 border-white text-[10px] w-5 h-5 sm:w-6 sm:h-6"
          title="Glimmer Cart Member"
        >
          ✨
        </span>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CATEGORIES_DATA } from '../../data/categories';
import { ProductCard } from '../products/ProductCard';
import { CategoryId } from '../../types';
import { Sparkles, ArrowLeft } from 'lucide-react';

export const CategoriesView: React.FC = () => {
  const { products, selectedCategory, setSelectedCategory } = useApp();
  const [activeCategory, setActiveCategory] = useState<CategoryId | 'all'>(() => {
    return selectedCategory || 'all';
  });

  const handleCategorySelect = (catId: CategoryId | 'all') => {
    setActiveCategory(catId);
    setSelectedCategory(catId === 'all' ? null : catId);
  };

  const displayedProducts = activeCategory === 'all'
    ? products
    : activeCategory === 'new-arrivals'
    ? products.filter(p => p.isNewArrival)
    : products.filter(p => p.categoryId === activeCategory);

  const currentCategoryInfo = CATEGORIES_DATA.find(c => c.id === activeCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-6 pb-24 animate-in fade-in duration-200">
      {/* Categories Title */}
      <div className="space-y-1">
        <div className="flex items-center gap-1 text-pink-600 text-xs font-bold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Boutique Department</span>
        </div>
        <h2 className="font-display text-2xl font-bold text-stone-900">
          Shop by Category
        </h2>
        <p className="text-xs text-stone-500">
          Explore our curated accessories made with love and magic
        </p>
      </div>

      {/* Category Pills Slider */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => handleCategorySelect('all')}
          className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-semibold transition-all shadow-xs ${
            activeCategory === 'all'
              ? 'bg-pink-600 text-white shadow-md'
              : 'bg-white text-stone-700 border border-stone-200 hover:border-pink-300'
          }`}
        >
          All Items ({products.length})
        </button>
        {CATEGORIES_DATA.map((cat) => {
          const count = cat.id === 'new-arrivals'
            ? products.filter(p => p.isNewArrival).length
            : products.filter(p => p.categoryId === cat.id).length;

          const isSelected = activeCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => handleCategorySelect(cat.id)}
              className={`flex-shrink-0 flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all shadow-xs ${
                isSelected
                  ? 'bg-pink-600 text-white shadow-md'
                  : 'bg-white text-stone-700 border border-stone-200 hover:border-pink-300'
              }`}
            >
              <img
                src={cat.image}
                alt=""
                className="w-5 h-5 rounded-full object-cover"
              />
              <span>{cat.name}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                isSelected ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Highlight Category Banner if specific category selected */}
      {currentCategoryInfo && (
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-pink-100 via-purple-100 to-pink-50 p-5 sm:p-6 border border-pink-200 flex items-center justify-between shadow-xs">
          <div className="space-y-1.5 max-w-sm z-10">
            <span className="text-[10px] font-bold uppercase tracking-wider text-pink-700 bg-white/80 px-2 py-0.5 rounded-md">
              {currentCategoryInfo.highlightTag}
            </span>
            <h3 className="font-display text-xl font-bold text-stone-900">
              {currentCategoryInfo.name}
            </h3>
            <p className="text-xs text-stone-600">
              {currentCategoryInfo.shortDesc}
            </p>
          </div>
          <div className="w-20 h-20 sm:w-28 sm:h-28 rounded-2xl overflow-hidden shadow-md flex-shrink-0 border-2 border-white">
            <img
              src={currentCategoryInfo.image}
              alt={currentCategoryInfo.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      )}

      {/* Category Visual Grid of items */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs text-stone-500">
          <span>
            Displaying <strong className="text-stone-900">{displayedProducts.length}</strong> items
          </span>
          {activeCategory !== 'all' && (
            <button
              onClick={() => handleCategorySelect('all')}
              className="text-pink-600 font-semibold hover:underline flex items-center gap-1"
            >
              <ArrowLeft className="w-3 h-3" /> Show all categories
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {displayedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
};

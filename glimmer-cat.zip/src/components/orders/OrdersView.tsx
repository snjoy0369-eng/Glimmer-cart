import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Order, OrderStatus } from '../../types';
import { 
  Package, 
  Truck, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  ChevronRight, 
  MapPin, 
  ArrowRight,
  ShoppingBag,
  ExternalLink
} from 'lucide-react';

const STATUS_STEPS: OrderStatus[] = [
  'Order Placed',
  'Confirmed',
  'Packed',
  'Shipped',
  'Out for Delivery',
  'Delivered'
];

export const OrdersView: React.FC = () => {
  const { orders, setCurrentTab, setSelectedProduct, addToCart, addToast } = useApp();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const getStatusIndex = (status: OrderStatus) => {
    return STATUS_STEPS.indexOf(status);
  };

  const handleReorder = (order: Order) => {
    order.items.forEach(item => {
      addToCart(item.product, item.quantity, item.selectedVariant);
    });
    addToast('Items added back to your cart! 🛍️', 'sparkle');
    setCurrentTab('cart');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-4 space-y-6 pb-24 animate-in fade-in duration-200">
      {/* Title */}
      <div className="border-b border-stone-200 pb-3 flex items-center justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold text-stone-900 flex items-center gap-2">
            <span>My Orders</span>
            <Package className="w-5 h-5 text-pink-600" />
          </h2>
          <p className="text-xs text-stone-500">
            Track your sparkly deliveries and view past receipts
          </p>
        </div>

        <button
          onClick={() => setCurrentTab('home')}
          className="text-xs text-pink-600 font-semibold hover:underline"
        >
          Continue Shopping
        </button>
      </div>

      {/* Orders List */}
      {orders.length > 0 ? (
        <div className="space-y-5">
          {orders.map((order) => {
            const currentStepIdx = getStatusIndex(order.orderStatus);

            return (
              <div
                key={order.id}
                className="p-4 sm:p-6 rounded-3xl bg-white border border-pink-100 shadow-sm space-y-5 transition-all hover:shadow-md"
              >
                {/* Order Top Bar: ID, Date, Amount, Status Badge */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-100">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs sm:text-sm text-stone-900">
                        {order.id}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-pink-50 text-pink-700 border border-pink-200">
                        {order.orderStatus}
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-400">
                      Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-sm sm:text-base font-bold text-stone-900">
                      ₹{order.total}
                    </span>
                    <p className="text-[10px] text-emerald-700 font-medium">
                      {order.paymentMethod} • {order.paymentStatus}
                    </p>
                  </div>
                </div>

                {/* Progress Stepper for Status */}
                <div className="py-2">
                  <div className="text-[11px] font-semibold text-stone-500 mb-3 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-pink-600">
                      <Truck className="w-3.5 h-3.5" />
                      {order.estimatedDelivery}
                    </span>
                    {order.trackingNumber && (
                      <span className="font-mono text-stone-400 text-[10px]">
                        AWB: {order.trackingNumber}
                      </span>
                    )}
                  </div>

                  {/* Visual Stepper */}
                  <div className="relative flex items-center justify-between overflow-x-auto pb-2 scrollbar-none">
                    {/* Connecting Line */}
                    <div className="absolute left-4 right-4 top-3.5 h-0.5 bg-stone-200 -z-0">
                      <div 
                        className="h-full bg-gradient-to-r from-pink-500 to-purple-500 transition-all duration-500" 
                        style={{ 
                          width: `${(Math.max(0, currentStepIdx) / (STATUS_STEPS.length - 1)) * 100}%` 
                        }}
                      />
                    </div>

                    {STATUS_STEPS.map((step, idx) => {
                      const isCompleted = idx <= currentStepIdx;
                      const isCurrent = idx === currentStepIdx;

                      return (
                        <div key={step} className="flex flex-col items-center flex-1 z-10 min-w-[54px] text-center">
                          <div 
                            className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                              isCurrent
                                ? 'bg-pink-600 text-white ring-4 ring-pink-100 shadow-md scale-110'
                                : isCompleted
                                ? 'bg-pink-500 text-white'
                                : 'bg-stone-200 text-stone-400'
                            }`}
                          >
                            {isCompleted ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : (
                              <span className="text-[10px] font-bold">{idx + 1}</span>
                            )}
                          </div>
                          <span className={`text-[10px] mt-1.5 font-medium leading-tight line-clamp-1 ${
                            isCurrent ? 'text-pink-600 font-bold' : isCompleted ? 'text-stone-800' : 'text-stone-400'
                          }`}>
                            {step}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Ordered Items Preview */}
                <div className="space-y-2 pt-2 border-t border-stone-100">
                  <span className="text-xs font-semibold text-stone-500 block">
                    Ordered Items ({order.items.reduce((a, b) => a + b.quantity, 0)} items):
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {order.items.map((item, idx) => (
                      <div
                        key={idx}
                        onClick={() => setSelectedProduct(item.product)}
                        className="flex items-center gap-2.5 p-2 rounded-xl bg-stone-50/70 border border-stone-200/60 cursor-pointer hover:bg-stone-100/80 transition-colors"
                      >
                        <img
                          src={item.product.images[0]}
                          alt=""
                          className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold text-stone-800 truncate">
                            {item.product.name}
                          </p>
                          <p className="text-[10px] text-stone-500">
                            Qty: {item.quantity} • ₹{item.product.price}
                            {item.selectedVariant ? ` • ${item.selectedVariant.name}` : ''}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Shipping destination & actions */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-stone-100 text-xs">
                  <div className="flex items-center gap-1.5 text-stone-500 text-[11px]">
                    <MapPin className="w-3.5 h-3.5 text-pink-500 flex-shrink-0" />
                    <span className="truncate max-w-xs">
                      Delivering to: {order.shippingAddress.fullName}, {order.shippingAddress.city} - {order.shippingAddress.pinCode}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleReorder(order)}
                      className="px-3 py-1.5 rounded-xl border border-pink-200 text-pink-700 bg-pink-50/50 hover:bg-pink-100 text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Reorder</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="py-16 text-center space-y-4 bg-white rounded-3xl border border-pink-100 p-8">
          <div className="w-20 h-20 rounded-full bg-pink-50 text-pink-400 mx-auto flex items-center justify-center text-4xl">
            📦
          </div>
          <div className="space-y-1">
            <h3 className="font-display text-lg font-bold text-stone-900">
              No orders placed yet
            </h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              Once you checkout your favorite jewelry, you can track packages in real-time right here!
            </p>
          </div>
          <button
            onClick={() => setCurrentTab('home')}
            className="px-6 py-2.5 rounded-full bg-pink-500 text-white text-xs font-bold shadow-md hover:bg-pink-600 transition-transform active:scale-95 inline-flex items-center gap-2"
          >
            <span>Browse Accessories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

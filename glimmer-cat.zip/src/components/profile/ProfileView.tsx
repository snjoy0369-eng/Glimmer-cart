import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Package, 
  Heart, 
  MapPin, 
  Bell, 
  Settings, 
  HelpCircle, 
  Info, 
  FileText, 
  ShieldCheck, 
  LogOut, 
  ChevronRight, 
  Lock, 
  Plus, 
  Trash2, 
  Sparkles, 
  X,
  MessageCircle,
  Send,
  User,
  Pencil,
  Camera,
  Smartphone,
  Mail,
  Upload,
  Check
} from 'lucide-react';
import { ShippingAddress, UserProfile } from '../../types';
import { UserAvatar } from '../common/UserAvatar';

// Curated avatar presets if user wants a cute ready-to-use aesthetic photo
const AVATAR_PRESETS = [
  {
    name: 'Sparkle Cat',
    url: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=300&q=80'
  },
  {
    name: 'Rose Blossom',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
  },
  {
    name: 'Fairy Pearl',
    url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80'
  },
  {
    name: 'Golden Glow',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80'
  }
];

export const ProfileView: React.FC = () => {
  const { 
    user, 
    isLoggedIn, 
    openAuthModal, 
    logout, 
    setCurrentTab, 
    wishlist, 
    orders, 
    unreadNotificationsCount,
    addSavedAddress,
    deleteSavedAddress,
    verifyAdminPasscode,
    isAdminMode,
    updateUserProfile,
    addToast
  } = useApp();

  // Subview modal states
  const [activeSubModal, setActiveSubModal] = useState<
    'addresses' | 'support' | 'about' | 'privacy' | 'terms' | 'adminAuth' | 'settings' | 'editProfile' | null
  >(null);

  // Edit Profile form state
  const [editName, setEditName] = useState('');
  const [editMobile, setEditMobile] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync edit form when modal opens
  useEffect(() => {
    if (user && activeSubModal === 'editProfile') {
      setEditName(user.name || '');
      setEditMobile(user.mobile || '');
      setEditEmail(user.email || '');
      setEditAvatarUrl(user.avatarUrl || '');
    }
  }, [user, activeSubModal]);

  // New address form state
  const [newAddrName, setNewAddrName] = useState('');
  const [newAddrMobile, setNewAddrMobile] = useState('');
  const [newAddrLine, setNewAddrLine] = useState('');
  const [newAddrCity, setNewAddrCity] = useState('');
  const [newAddrState, setNewAddrState] = useState('');
  const [newAddrPin, setNewAddrPin] = useState('');
  const [newAddrType, setNewAddrType] = useState<'Home' | 'Work' | 'Other'>('Home');

  // Admin passcode
  const [adminPasscode, setAdminPasscode] = useState('');

  // Support live chat state
  const [supportChatMessages, setSupportChatMessages] = useState<{ sender: 'user' | 'bot'; text: string }[]>([
    { sender: 'bot', text: 'Hello gorgeous! 🐾 I am your Glimmer Cart concierge. How can I help you sparkle today?' }
  ]);
  const [supportInput, setSupportInput] = useState('');

  // Handle image upload from computer/phone gallery
  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (max 5MB raw)
    if (file.size > 5 * 1024 * 1024) {
      alert('Photo is too large. Please select a photo under 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const img = new Image();
      img.onload = () => {
        // Compress & scale to ~320x320 for optimal performance
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 320;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > MAX_SIZE) {
            height = Math.round((height * MAX_SIZE) / width);
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width = Math.round((width * MAX_SIZE) / height);
            height = MAX_SIZE;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        const compressed = canvas.toDataURL('image/jpeg', 0.85);
        setEditAvatarUrl(compressed);
        addToast('Profile photo ready to save! 📸', 'success');
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) {
      alert('Please enter your name');
      return;
    }

    updateUserProfile({
      name: editName.trim(),
      mobile: editMobile.trim(),
      email: editEmail.trim(),
      avatarUrl: editAvatarUrl
    });

    setActiveSubModal(null);
  };

  const handleAddNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddrName || !newAddrMobile || !newAddrLine || !newAddrCity || !newAddrPin) return;

    const newAddress: ShippingAddress = {
      fullName: newAddrName,
      mobileNumber: newAddrMobile,
      addressLine: newAddrLine,
      city: newAddrCity,
      state: newAddrState || 'Delhi',
      pinCode: newAddrPin,
      addressType: newAddrType,
      isDefault: (user?.savedAddresses.length || 0) === 0
    };

    addSavedAddress(newAddress);
    setNewAddrName('');
    setNewAddrMobile('');
    setNewAddrLine('');
    setNewAddrCity('');
    setNewAddrState('');
    setNewAddrPin('');
  };

  const handleAdminVerify = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = verifyAdminPasscode(adminPasscode);
    if (ok) {
      setActiveSubModal(null);
      setCurrentTab('admin');
      setAdminPasscode('');
    }
  };

  const handleSendSupportMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportInput.trim()) return;
    const userMsg = supportInput.trim();
    setSupportChatMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    setSupportInput('');

    // Simulated warm concierge reply
    setTimeout(() => {
      let reply = "Thank you for reaching out! We dispatch orders within 24 hours. Our jewels are made with anti-tarnish hypoallergenic metals with 7 days return guarantee! ✨";
      if (userMsg.toLowerCase().includes('track') || userMsg.toLowerCase().includes('order')) {
        reply = "You can view live package updates under 'My Orders' in your profile tab!";
      } else if (userMsg.toLowerCase().includes('return') || userMsg.toLowerCase().includes('refund')) {
        reply = "We offer a 7-day hassle-free return and exchange policy. Just share your Order ID with us!";
      } else if (userMsg.toLowerCase().includes('cat') || userMsg.toLowerCase().includes('glimmer')) {
        reply = "Meow! 🐾 A percentage of every Glimmer Cart sale supports local community animal rescue shelters.";
      }
      setSupportChatMessages(prev => [...prev, { sender: 'bot', text: reply }]);
    }, 600);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-4 space-y-6 pb-28 animate-in fade-in duration-200">
      {/* Profile Header Card */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-tr from-pink-50 via-purple-50 to-white border border-pink-100 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-36 h-36 rounded-full bg-pink-200/30 blur-2xl pointer-events-none" />

        {isLoggedIn && user ? (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
            <div className="flex items-center gap-4 min-w-0">
              {/* Profile Photo (or Clean Default Glimmer Cart Avatar) */}
              <div className="relative shrink-0">
                <UserAvatar user={user} size="lg" showSparkleBadge />
              </div>

              {/* User Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h2 className="font-display text-lg sm:text-xl font-bold text-stone-900 truncate">
                    {user.name}
                  </h2>
                  <span className="text-[10px] font-bold text-pink-700 bg-pink-100/90 px-2 py-0.5 rounded-full shrink-0">
                    VIP 🐾
                  </span>
                </div>

                {/* Mobile Number */}
                <div className="flex items-center gap-1.5 text-xs text-stone-600 mt-1 font-mono">
                  <Smartphone className="w-3.5 h-3.5 text-pink-500 shrink-0" />
                  <span>{user.mobile || 'No mobile added'}</span>
                </div>

                {/* Email (if available) */}
                {user.email ? (
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 mt-0.5 truncate">
                    <Mail className="w-3.5 h-3.5 text-purple-500 shrink-0" />
                    <span className="truncate">{user.email}</span>
                  </div>
                ) : (
                  <button
                    onClick={() => setActiveSubModal('editProfile')}
                    className="text-[11px] text-pink-600 hover:underline mt-0.5 flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add email address</span>
                  </button>
                )}
              </div>
            </div>

            {/* Edit Profile Button */}
            <div className="flex sm:flex-col justify-end items-end shrink-0">
              <button
                onClick={() => setActiveSubModal('editProfile')}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white border border-pink-200 text-stone-700 hover:bg-pink-50 text-xs font-semibold shadow-xs transition-colors"
              >
                <Pencil className="w-3.5 h-3.5 text-pink-600" />
                <span>Edit Profile</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center py-4 space-y-3 relative z-10">
            <div className="w-14 h-14 rounded-full bg-pink-100 text-pink-600 mx-auto flex items-center justify-center">
              <User className="w-7 h-7" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-stone-900">
                Welcome to Glimmer Cart
              </h3>
              <p className="text-xs text-stone-500">
                Sign in to track orders, manage addresses and save wishlists!
              </p>
            </div>
            <button
              onClick={() => openAuthModal('login')}
              className="px-6 py-2 rounded-full bg-pink-500 hover:bg-pink-600 text-white text-xs font-bold shadow-md transition-colors inline-block"
            >
              Sign In / Register
            </button>
          </div>
        )}
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-3 gap-2.5">
        <button
          onClick={() => setCurrentTab('orders')}
          className="p-3 rounded-2xl bg-white border border-stone-200/80 shadow-xs hover:border-pink-300 transition-all text-center"
        >
          <span className="text-lg font-bold font-display text-stone-800 block">
            {orders.length}
          </span>
          <span className="text-[11px] font-medium text-stone-500 flex items-center justify-center gap-1 mt-0.5">
            <Package className="w-3 h-3 text-pink-500" />
            <span>My Orders</span>
          </span>
        </button>

        <button
          onClick={() => setCurrentTab('wishlist')}
          className="p-3 rounded-2xl bg-white border border-stone-200/80 shadow-xs hover:border-pink-300 transition-all text-center"
        >
          <span className="text-lg font-bold font-display text-pink-600 block">
            {wishlist.length}
          </span>
          <span className="text-[11px] font-medium text-stone-500 flex items-center justify-center gap-1 mt-0.5">
            <Heart className="w-3 h-3 text-pink-500 fill-pink-500" />
            <span>Wishlist</span>
          </span>
        </button>

        <button
          onClick={() => setActiveSubModal('addresses')}
          className="p-3 rounded-2xl bg-white border border-stone-200/80 shadow-xs hover:border-pink-300 transition-all text-center"
        >
          <span className="text-lg font-bold font-display text-stone-800 block">
            {user?.savedAddresses.length || 0}
          </span>
          <span className="text-[11px] font-medium text-stone-500 flex items-center justify-center gap-1 mt-0.5">
            <MapPin className="w-3 h-3 text-amber-500" />
            <span>Addresses</span>
          </span>
        </button>
      </div>

      {/* Profile Menu List */}
      <div className="bg-white rounded-3xl border border-stone-200/80 shadow-xs divide-y divide-stone-100 overflow-hidden">
        {/* 1. My Orders */}
        <button
          onClick={() => setCurrentTab('orders')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">My Orders</span>
              <span className="text-[10px] text-stone-400">Track shipments &amp; order history</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 2. Wishlist */}
        <button
          onClick={() => setCurrentTab('wishlist')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <Heart className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">Wishlist</span>
              <span className="text-[10px] text-stone-400">{wishlist.length} saved accessories</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 3. Saved Addresses */}
        <button
          onClick={() => setActiveSubModal('addresses')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">Saved Addresses</span>
              <span className="text-[10px] text-stone-400">Manage delivery locations</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 4. Notifications */}
        <button
          onClick={() => setCurrentTab('notifications')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">Notifications</span>
              <span className="text-[10px] text-stone-400">
                {unreadNotificationsCount > 0 ? `${unreadNotificationsCount} unread announcements` : 'New arrivals & discounts'}
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 5. Account Settings */}
        <button
          onClick={() => setActiveSubModal('settings')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-600 flex items-center justify-center">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">Account Settings</span>
              <span className="text-[10px] text-stone-400">Currency, notifications &amp; privacy</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 6. Help & Support */}
        <button
          onClick={() => setActiveSubModal('support')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">Help &amp; Support</span>
              <span className="text-[10px] text-stone-400">FAQ &amp; 24/7 Glimmer Concierge</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 7. About Glimmer Cart */}
        <button
          onClick={() => setActiveSubModal('about')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">About Glimmer Cart</span>
              <span className="text-[10px] text-stone-400">Our story, materials &amp; mission</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 8. Privacy Policy */}
        <button
          onClick={() => setActiveSubModal('privacy')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">Privacy Policy</span>
              <span className="text-[10px] text-stone-400">Data protection &amp; security guarantee</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>

        {/* 9. Terms & Conditions */}
        <button
          onClick={() => setActiveSubModal('terms')}
          className="w-full flex items-center justify-between p-4 hover:bg-stone-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-semibold text-stone-800 block">Terms &amp; Conditions</span>
              <span className="text-[10px] text-stone-400">Orders, shipping &amp; 7-day return rules</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-stone-400" />
        </button>
      </div>

      {/* Admin Panel Quick Access */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-200/70 text-purple-700 flex items-center justify-center">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-purple-900 block">
              Store Owner Portal
            </span>
            <span className="text-[10px] text-purple-700">
              Add your own products, upload gallery photos &amp; manage orders
            </span>
          </div>
        </div>

        {isAdminMode ? (
          <button
            onClick={() => setCurrentTab('admin')}
            className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-xs transition-colors"
          >
            Open Admin
          </button>
        ) : (
          <button
            onClick={() => setActiveSubModal('adminAuth')}
            className="px-3 py-1.5 rounded-xl bg-white border border-purple-300 text-purple-800 hover:bg-purple-100 text-xs font-bold shadow-xs transition-colors"
          >
            Admin Login
          </button>
        )}
      </div>

      {/* Logout button */}
      {isLoggedIn && (
        <button
          onClick={logout}
          className="w-full py-3 rounded-2xl bg-white border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-xs"
        >
          <LogOut className="w-4 h-4" />
          <span>Log Out</span>
        </button>
      )}

      {/* ===================== SUB-MODAL: EDIT PROFILE ===================== */}
      {activeSubModal === 'editProfile' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 space-y-5 max-h-[92vh] overflow-y-auto border border-pink-100 shadow-2xl animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-display text-base font-bold text-stone-900 flex items-center gap-2">
                <Pencil className="w-4 h-4 text-pink-600" />
                <span>Edit Profile</span>
              </h3>
              <button 
                onClick={() => setActiveSubModal(null)} 
                className="p-1.5 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              {/* Photo Editing Section */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-800 block">
                  Profile Photo
                </label>

                <div className="flex items-center gap-4 p-3 bg-stone-50 rounded-2xl border border-stone-100">
                  {/* Current Photo Preview */}
                  <div className="relative">
                    <UserAvatar 
                      user={{
                        id: user?.id || 'preview',
                        name: editName || user?.name || 'User',
                        mobile: editMobile,
                        avatarUrl: editAvatarUrl,
                        savedAddresses: [],
                        isAdmin: false
                      }} 
                      size="lg"
                    />
                  </div>

                  <div className="space-y-1.5 flex-1">
                    <input
                      type="file"
                      ref={fileInputRef}
                      accept="image/*"
                      onChange={handleAvatarFileUpload}
                      className="hidden"
                    />

                    <div className="flex flex-wrap gap-1.5">
                      {/* Upload Photo Button */}
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-2.5 py-1.5 rounded-lg bg-pink-500 hover:bg-pink-600 text-white text-[11px] font-semibold flex items-center gap-1 shadow-xs transition-colors"
                      >
                        <Upload className="w-3 h-3" />
                        <span>Upload Photo</span>
                      </button>

                      {/* Revert to Clean Default Avatar */}
                      {editAvatarUrl && (
                        <button
                          type="button"
                          onClick={() => setEditAvatarUrl('')}
                          className="px-2.5 py-1.5 rounded-lg bg-white border border-stone-200 hover:bg-stone-100 text-stone-600 text-[11px] font-semibold transition-colors"
                        >
                          Use Default Avatar
                        </button>
                      )}
                    </div>
                    <p className="text-[10px] text-stone-400">
                      Upload from phone/computer or use clean Glimmer Cart avatar.
                    </p>
                  </div>
                </div>

                {/* Cute Avatar Presets */}
                <div>
                  <span className="text-[11px] text-stone-500 font-medium block mb-1.5">
                    Or pick a sparkly preset avatar:
                  </span>
                  <div className="grid grid-cols-4 gap-2">
                    {AVATAR_PRESETS.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setEditAvatarUrl(preset.url)}
                        className={`p-1 rounded-xl border text-center transition-all ${
                          editAvatarUrl === preset.url
                            ? 'border-pink-500 ring-2 ring-pink-200 bg-pink-50'
                            : 'border-stone-200 hover:border-pink-300 bg-white'
                        }`}
                      >
                        <img 
                          src={preset.url} 
                          alt={preset.name} 
                          className="w-10 h-10 rounded-full mx-auto object-cover"
                        />
                        <span className="text-[9px] font-semibold text-stone-700 block mt-1 truncate">
                          {preset.name}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* 1. Full Name */}
              <div>
                <label className="text-xs font-bold text-stone-800 block mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-pink-500 focus-within:bg-white transition-all px-3 py-2">
                  <User className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rahul"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full text-xs bg-transparent focus:outline-none font-semibold text-stone-800"
                  />
                </div>
                <p className="text-[10px] text-stone-400 mt-1">
                  Changes your name across Header, orders, and receipts automatically.
                </p>
              </div>

              {/* 2. Mobile Number */}
              <div>
                <label className="text-xs font-bold text-stone-800 block mb-1">
                  Mobile Number
                </label>
                <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-pink-500 focus-within:bg-white transition-all px-3 py-2">
                  <Smartphone className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                  <input
                    type="tel"
                    placeholder="98765 43210"
                    value={editMobile}
                    onChange={(e) => setEditMobile(e.target.value)}
                    className="w-full text-xs bg-transparent focus:outline-none font-mono text-stone-800"
                  />
                </div>
              </div>

              {/* 3. Email Address */}
              <div>
                <label className="text-xs font-bold text-stone-800 block mb-1">
                  Email Address
                </label>
                <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-pink-500 focus-within:bg-white transition-all px-3 py-2">
                  <Mail className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                  <input
                    type="email"
                    placeholder="rahul@example.com"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full text-xs bg-transparent focus:outline-none text-stone-800"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveSubModal(null)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-200 text-stone-600 hover:bg-stone-50 text-xs font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save Profile</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SUB-MODAL 1: SAVED ADDRESSES */}
      {activeSubModal === 'addresses' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-5 space-y-4 max-h-[90vh] overflow-y-auto border border-pink-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-display text-base font-bold text-stone-900 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-pink-600" />
                <span>Saved Delivery Addresses</span>
              </h3>
              <button onClick={() => setActiveSubModal(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List */}
            <div className="space-y-2">
              {user?.savedAddresses && user.savedAddresses.length > 0 ? (
                user.savedAddresses.map((addr, idx) => (
                  <div key={idx} className="p-3 rounded-xl border border-stone-200 text-xs flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2 font-bold text-stone-800">
                        <span>{addr.fullName}</span>
                        <span className="text-[10px] bg-stone-100 px-1.5 py-0.2 rounded">{addr.addressType}</span>
                      </div>
                      <p className="text-stone-600 mt-1">{addr.addressLine}, {addr.city} - {addr.pinCode}</p>
                      <p className="text-stone-400 text-[11px] font-mono mt-0.5">📱 {addr.mobileNumber}</p>
                    </div>
                    <button onClick={() => deleteSavedAddress(idx)} className="text-stone-400 hover:text-rose-600 p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-stone-400 text-xs">
                  No saved addresses yet. Add your delivery location below!
                </div>
              )}
            </div>

            {/* Add New Address */}
            <form onSubmit={handleAddNewAddress} className="pt-2 border-t border-stone-100 space-y-2 text-xs">
              <span className="font-bold text-stone-800 block">Add New Address</span>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Full Name"
                  required
                  value={newAddrName}
                  onChange={(e) => setNewAddrName(e.target.value)}
                  className="p-2 border rounded-xl"
                />
                <input
                  type="tel"
                  placeholder="Mobile"
                  required
                  value={newAddrMobile}
                  onChange={(e) => setNewAddrMobile(e.target.value)}
                  className="p-2 border rounded-xl font-mono"
                />
              </div>
              <input
                type="text"
                placeholder="House / Flat / Street Name"
                required
                value={newAddrLine}
                onChange={(e) => setNewAddrLine(e.target.value)}
                className="w-full p-2 border rounded-xl"
              />
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="City"
                  required
                  value={newAddrCity}
                  onChange={(e) => setNewAddrCity(e.target.value)}
                  className="p-2 border rounded-xl"
                />
                <input
                  type="text"
                  placeholder="State"
                  value={newAddrState}
                  onChange={(e) => setNewAddrState(e.target.value)}
                  className="p-2 border rounded-xl"
                />
                <input
                  type="text"
                  placeholder="PIN"
                  required
                  value={newAddrPin}
                  onChange={(e) => setNewAddrPin(e.target.value)}
                  className="p-2 border rounded-xl font-mono"
                />
              </div>

              <div className="flex gap-2 pt-1">
                {(['Home', 'Work', 'Other'] as const).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setNewAddrType(type)}
                    className={`flex-1 py-1.5 rounded-lg border text-[11px] font-semibold ${
                      newAddrType === type ? 'border-pink-500 bg-pink-50 text-pink-700' : 'border-stone-200 text-stone-600'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-pink-500 hover:bg-pink-600 text-white rounded-xl font-bold shadow-xs transition-colors mt-2"
              >
                Save Address
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SUB-MODAL 2: 24/7 SUPPORT CHAT */}
      {activeSubModal === 'support' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-5 space-y-4 max-h-[90vh] flex flex-col border border-pink-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold text-xs">
                  🐾
                </div>
                <div>
                  <h3 className="font-display text-sm font-bold text-stone-900">Glimmer Concierge</h3>
                  <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Online • 24/7 Priority Support
                  </span>
                </div>
              </div>
              <button onClick={() => setActiveSubModal(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat message thread */}
            <div className="flex-1 overflow-y-auto space-y-2.5 p-2 bg-stone-50 rounded-2xl min-h-[220px] max-h-[300px] text-xs">
              {supportChatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-2.5 rounded-2xl ${
                      msg.sender === 'user'
                        ? 'bg-pink-500 text-white rounded-br-xs'
                        : 'bg-white text-stone-800 border border-stone-200 rounded-bl-xs shadow-xs'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Chat input form */}
            <form onSubmit={handleSendSupportMessage} className="flex gap-2">
              <input
                type="text"
                placeholder="Ask about orders, delivery, returns..."
                value={supportInput}
                onChange={(e) => setSupportInput(e.target.value)}
                className="flex-1 px-3 py-2 text-xs border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500"
              />
              <button
                type="submit"
                className="p-2 bg-pink-500 hover:bg-pink-600 text-white rounded-xl transition-colors shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SUB-MODAL 3: ABOUT US */}
      {activeSubModal === 'about' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-pink-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-display text-base font-bold text-stone-900">About Glimmer Cart</h3>
              <button onClick={() => setActiveSubModal(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-xs text-stone-600 space-y-3 leading-relaxed">
              <p>
                <strong>Glimmer Cart</strong> is an artisanal jewelry and luxury lifestyle house inspired by celestial wonders and playful feline charm.
              </p>
              <p>
                Each creation is sculpted with premium anti-tarnish stainless steel, hypoallergenic 18k rose gold and 925 sterling silver plating, embellished with AAA+ cubic zirconia and natural freshwater pearls.
              </p>
              <div className="p-3 bg-pink-50 rounded-2xl border border-pink-100 space-y-1 text-pink-900">
                <span className="font-bold block">✨ Our 100% Purity Promise</span>
                <p className="text-[11px]">Water-resistant, nickel-free, lead-free and crafted for everyday wear without skin irritation.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 4: PRIVACY */}
      {activeSubModal === 'privacy' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-pink-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-display text-base font-bold text-stone-900">Privacy &amp; Security</h3>
              <button onClick={() => setActiveSubModal(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-xs text-stone-600 space-y-3 leading-relaxed">
              <p>
                Your privacy is paramount. Glimmer Cart uses 256-bit bank-grade SSL encryption for all transaction processing.
              </p>
              <p>
                We never sell or distribute your personal contact details or saved shipping addresses to third-party telemarketers.
              </p>
              <ul className="list-disc pl-4 space-y-1 text-[11px]">
                <li>Zero payment credential retention on local servers</li>
                <li>Encrypted UPI and tokenized card gateways</li>
                <li>Option to clear your stored local profile data at any time</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 5: TERMS */}
      {activeSubModal === 'terms' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-pink-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-display text-base font-bold text-stone-900">Terms of Service</h3>
              <button onClick={() => setActiveSubModal(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-xs text-stone-600 space-y-3 leading-relaxed">
              <p>
                <strong>Delivery Timeline:</strong> Orders dispatched within 24 hours. Express metro delivery in 2-3 business days; pan-India in 4-6 business days.
              </p>
              <p>
                <strong>7-Day Returns:</strong> If you are not delighted with your jewelry piece, enjoy a full refund or exchange within 7 days in its original velvet pouch.
              </p>
              <p>
                <strong>Warranty:</strong> 6-month anti-tarnish replacement warranty included with all premium collections.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 6: SETTINGS */}
      {activeSubModal === 'settings' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 space-y-4 border border-pink-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-display text-base font-bold text-stone-900">Preferences &amp; Settings</h3>
              <button onClick={() => setActiveSubModal(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between p-3 bg-stone-50 rounded-xl">
                <div>
                  <span className="font-semibold text-stone-800 block">Currency</span>
                  <span className="text-stone-400 text-[11px]">Indian Rupee (₹ INR)</span>
                </div>
                <span className="text-xs font-bold text-pink-600 bg-white px-2 py-1 rounded border border-stone-200">
                  ₹ INR
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-stone-50 rounded-xl">
                <div>
                  <span className="font-semibold text-stone-800 block">Order Status SMS &amp; WhatsApp</span>
                  <span className="text-stone-400 text-[11px]">Receive live tracking updates</span>
                </div>
                <input type="checkbox" defaultChecked className="accent-pink-500 w-4 h-4" />
              </div>

              <div className="flex items-center justify-between p-3 bg-stone-50 rounded-xl">
                <div>
                  <span className="font-semibold text-stone-800 block">New Arrival Drops</span>
                  <span className="text-stone-400 text-[11px]">Exclusive secret discount alerts</span>
                </div>
                <input type="checkbox" defaultChecked className="accent-pink-500 w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL 7: ADMIN PASSCODE */}
      {activeSubModal === 'adminAuth' && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 border border-purple-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-display text-base font-bold text-stone-900 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-purple-600" />
                <span>Store Owner Verification</span>
              </h3>
              <button onClick={() => setActiveSubModal(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-stone-500">
              Enter your master passcode to access the Store Owner dashboard.
            </p>
            <form onSubmit={handleAdminVerify} className="space-y-3">
              <input
                type="password"
                placeholder="Enter passcode (Demo: glimmer888)"
                value={adminPasscode}
                onChange={(e) => setAdminPasscode(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-stone-200 rounded-xl focus:outline-none focus:border-purple-500 font-mono"
                autoFocus
              />
              <div className="flex items-center justify-between text-[11px] text-stone-400">
                <span>Demo passcode: <strong className="text-purple-600 font-mono">glimmer888</strong></span>
                <button
                  type="button"
                  onClick={() => setAdminPasscode('glimmer888')}
                  className="text-purple-600 hover:underline font-semibold"
                >
                  Auto-fill
                </button>
              </div>
              <button
                type="submit"
                className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold shadow-md transition-colors"
              >
                Verify &amp; Enter Portal
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

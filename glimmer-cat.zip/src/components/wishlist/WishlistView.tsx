import React from 'react';
import { useApp } from '../../context/AppContext';
import { Heart, Trash2, ShoppingBag, Sparkles, ArrowRight } from 'lucide-react';

export const WishlistView: React.FC = () => {
  const { 
    wishlist, 
    products, 
    toggleWishlist, 
    addToCart, 
    setCurrentTab, 
    setSelectedProduct 
  } = useApp();

  const wishlistProducts = products.filter(p => wishlist.includes(p.id));

  return (
    <div className="max-w-4xl mx-auto px-4 py-4 space-y-6 pb-24 animate-in fade-in duration-200">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-stone-200 pb-3">
        <div className="space-y-0.5">
          <h2 className="font-display text-2xl font-bold text-stone-900 flex items-center gap-2">
            <span>My Wishlist</span>
            <Heart className="w-5 h-5 fill-pink-500 text-pink-500" />
          </h2>
          <p className="text-xs text-stone-500">
            {wishlistProducts.length} saved {wishlistProducts.length === 1 ? 'item' : 'items'} for your sparkle collection
          </p>
        </div>

        {wishlistProducts.length > 0 && (
          <button
            onClick={() => {
              wishlistProducts.forEach(p => addToCart(p, 1, p.variants?.[0]));
            }}
            className="text-xs font-semibold text-pink-600 bg-pink-50 hover:bg-pink-100 px-3 py-1.5 rounded-full transition-colors flex items-center gap-1.5"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Move All to Cart</span>
          </button>
        )}
      </div>

      {/* Wishlist Items List */}
      {wishlistProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {wishlistProducts.map((product) => (
            <div
              key={product.id}
              onClick={() => setSelectedProduct(product)}
              className="flex gap-3.5 p-3 rounded-2xl bg-white border border-pink-100 shadow-xs hover:shadow-md transition-all cursor-pointer group"
            >
              {/* Image */}
              <div className="relative w-24 h-24 rounded-xl overflow-hidden bg-stone-50 flex-shrink-0">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {product.discountPercent && (
                  <span className="absolute top-1 left-1 bg-rose-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                    {product.discountPercent}% OFF
                  </span>
                )}
              </div>

              {/* Details & Actions */}
              <div className="flex flex-col flex-1 justify-between min-w-0">
                <div>
                  <span className="text-[10px] font-bold text-pink-600 uppercase tracking-wider">
                    {product.categoryName}
                  </span>
                  <h3 className="text-xs sm:text-sm font-semibold text-stone-900 line-clamp-1 group-hover:text-pink-600 transition-colors">
                    {product.name}
                  </h3>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-sm font-bold text-stone-900">
                      ₹{product.price}
                    </span>
                    {product.originalPrice && (
                      <span className="text-xs text-stone-400 line-through">
                        ₹{product.originalPrice}
                      </span>
                    )}
                  </div>
                </div>

                {/* Buttons: Remove & Add to Cart */}
                <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(product.id);
                    }}
                    className="p-2 rounded-xl text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    aria-label="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(product, 1, product.variants?.[0]);
                    }}
                    className="flex-1 py-1.5 px-3 rounded-xl bg-pink-500 hover:bg-pink-600 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs active:scale-98"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Add to Cart</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="py-16 text-center space-y-4 bg-white rounded-3xl border border-pink-100 p-8">
          <div className="relative w-20 h-20 rounded-full bg-pink-50 text-pink-400 mx-auto flex items-center justify-center">
            <Heart className="w-10 h-10 stroke-1 fill-pink-100 text-pink-400" />
            <span className="absolute -top-1 -right-1 text-base">🐾</span>
          </div>
          <div className="space-y-1">
            <h3 className="font-display text-lg font-bold text-stone-900">
              Your wishlist is empty
            </h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              Save your favorite earrings, kan fuli, necklaces and charms by tapping the heart icon while browsing!
            </p>
          </div>
          <button
            onClick={() => setCurrentTab('home')}
            className="px-6 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white text-xs font-bold shadow-md flex items-center gap-2 mx-auto transition-transform active:scale-95"
          >
            <span>Explore Dreamy Pieces</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, Order, OrderStatus, CategoryId, PromoBanner, Coupon } from '../../types';
import { ProductManagement } from './ProductManagement';
import { 
  Package, 
  ShoppingBag, 
  Image as ImageIcon, 
  Tag, 
  Plus, 
  Edit3, 
  Trash2, 
  Check, 
  TrendingUp, 
  DollarSign, 
  Sparkles, 
  ArrowLeft,
  X,
  Eye,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { 
    products, 
    orders, 
    banners, 
    coupons, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    updateOrderStatus,
    addBanner,
    deleteBanner,
    addCoupon,
    deleteCoupon,
    setIsAdminMode,
    setCurrentTab,
    addToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'banners' | 'coupons'>('products');

  // New Banner Form state
  const [bannerTitle, setBannerTitle] = useState('');
  const [bannerSubtitle, setBannerSubtitle] = useState('');
  const [bannerTag, setBannerTag] = useState('');
  const [bannerImage, setBannerImage] = useState('');
  const [bannerCta, setBannerCta] = useState('Shop Now');
  const [bannerLinkCategory, setBannerLinkCategory] = useState<CategoryId>('earrings');

  // New Coupon Form state
  const [couponCode, setCouponCode] = useState('');
  const [couponDiscount, setCouponDiscount] = useState(15);
  const [couponDesc, setCouponDesc] = useState('');
  const [couponMinSpend, setCouponMinSpend] = useState(500);

  // Totals calculations
  const totalSales = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrders = orders.length;

  const handleCreateBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bannerTitle || !bannerImage) return;

    const newBanner: PromoBanner = {
      id: `banner-${Date.now()}`,
      title: bannerTitle,
      subtitle: bannerSubtitle || 'Exclusive Glimmer Collection',
      tag: bannerTag || 'NEW SPARKLE',
      ctaText: bannerCta || 'Shop Now',
      imageUrl: bannerImage,
      linkCategoryId: bannerLinkCategory
    };

    addBanner(newBanner);
    setBannerTitle('');
    setBannerSubtitle('');
    setBannerTag('');
    setBannerImage('');
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode) return;

    const newC: Coupon = {
      code: couponCode.toUpperCase().trim(),
      discountType: 'percentage',
      value: Number(couponDiscount),
      discountPercent: Number(couponDiscount),
      description: couponDesc || `${couponDiscount}% OFF on sparkly favorites`,
      minSpend: Number(couponMinSpend),
      minOrderAmount: Number(couponMinSpend)
    };

    addCoupon(newC);
    setCouponCode('');
    setCouponDesc('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-6 pb-28 animate-in fade-in duration-200">
      {/* Admin Top Navigation & Exit Button */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-3xl bg-stone-900 text-white shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-md">
            🐾
          </div>
          <div>
            <h1 className="font-display text-base sm:text-lg font-bold">
              Glimmer Cart Store Manager
            </h1>
            <p className="text-[11px] text-pink-300">
              Live Boutique Operations &amp; Inventory Suite
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsAdminMode(false);
              setCurrentTab('home');
              addToast('Switched back to storefront view', 'info');
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Return to Store</span>
          </button>
        </div>
      </div>

      {/* Overview Analytics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-stone-500 text-xs">
            <span>Total Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="font-display text-xl sm:text-2xl font-bold text-stone-900 block">
            ₹{totalSales}
          </span>
          <span className="text-[10px] text-emerald-600 font-medium">● Indian Gateway Verified</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-stone-500 text-xs">
            <span>Total Orders</span>
            <ShoppingBag className="w-4 h-4 text-pink-600" />
          </div>
          <span className="font-display text-xl sm:text-2xl font-bold text-stone-900 block">
            {totalOrders}
          </span>
          <span className="text-[10px] text-stone-400">Lifetime orders placed</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-stone-500 text-xs">
            <span>Active Catalog</span>
            <Package className="w-4 h-4 text-purple-600" />
          </div>
          <span className="font-display text-xl sm:text-2xl font-bold text-stone-900 block">
            {products.length}
          </span>
          <span className="text-[10px] text-purple-600 font-medium">Boutique items live</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-stone-500 text-xs">
            <span>Active Coupons</span>
            <Tag className="w-4 h-4 text-amber-600" />
          </div>
          <span className="font-display text-xl sm:text-2xl font-bold text-stone-900 block">
            {coupons.length}
          </span>
          <span className="text-[10px] text-amber-600 font-medium">Promotions running</span>
        </div>
      </div>

      {/* Admin Module Tabs */}
      <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-stone-100 border border-stone-200 overflow-x-auto scrollbar-none">
        {[
          { id: 'products', label: 'Products Catalog', icon: Package, count: products.length },
          { id: 'orders', label: 'Customer Orders', icon: ShoppingBag, count: orders.length },
          { id: 'banners', label: 'Home Banners', icon: ImageIcon, count: banners.length },
          { id: 'coupons', label: 'Coupons & Offers', icon: Tag, count: coupons.length }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 min-w-[120px] flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                isActive
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5 text-pink-600" />
              <span>{tab.label}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-200/70 text-stone-700">
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: PRODUCTS MANAGEMENT */}
      {activeTab === 'products' && (
        <ProductManagement />
      )}

      {/* TAB 2: ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div>
            <h2 className="font-display text-lg font-bold text-stone-900">
              Customer Orders &amp; Fulfillment
            </h2>
            <p className="text-xs text-stone-500">
              Update shipment statuses from "Order Placed" through to "Delivered"
            </p>
          </div>

          <div className="space-y-3">
            {orders.map(ord => (
              <div
                key={ord.id}
                className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-xs space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 pb-2">
                  <div>
                    <span className="font-mono font-bold text-xs text-stone-900">
                      {ord.id}
                    </span>
                    <p className="text-[11px] text-stone-400">
                      Customer: {ord.shippingAddress.fullName} • 📱 {ord.shippingAddress.mobileNumber}
                    </p>
                    <p className="text-[10px] text-stone-500">
                      {ord.shippingAddress.addressLine}, {ord.shippingAddress.city} - {ord.shippingAddress.pinCode}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-xs font-bold text-stone-900">₹{ord.total}</span>
                      <p className="text-[10px] text-emerald-600">{ord.paymentMethod} (Paid)</p>
                    </div>

                    {/* Status Dropdown */}
                    <div className="flex items-center gap-1 bg-pink-50 border border-pink-200 rounded-xl px-2 py-1">
                      <span className="text-[10px] font-bold text-pink-700">Status:</span>
                      <select
                        value={ord.orderStatus}
                        onChange={(e) => updateOrderStatus(ord.id, e.target.value as OrderStatus)}
                        className="bg-transparent text-xs font-bold text-stone-800 focus:outline-none cursor-pointer border-none"
                      >
                        {[
                          'Order Placed',
                          'Confirmed',
                          'Packed',
                          'Shipped',
                          'Out for Delivery',
                          'Delivered'
                        ].map(st => (
                          <option key={st} value={st}>{st}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Items summary */}
                <div className="flex flex-wrap gap-2 text-xs">
                  {ord.items.map((it, i) => (
                    <span key={i} className="px-2 py-1 rounded-lg bg-stone-100 text-stone-700 text-[11px]">
                      {it.quantity}x {it.product.name}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: BANNERS MANAGEMENT */}
      {activeTab === 'banners' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Create Banner Form */}
          <div className="md:col-span-5 p-5 rounded-3xl bg-white border border-stone-200/80 shadow-xs space-y-4">
            <h3 className="font-display text-base font-bold text-stone-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-pink-600" />
              <span>Add New Hero Banner</span>
            </h3>

            <form onSubmit={handleCreateBanner} className="space-y-3 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                  Tag / Pill Text
                </label>
                <input
                  type="text"
                  placeholder="e.g. VIRAL COLLECTION"
                  value={bannerTag}
                  onChange={(e) => setBannerTag(e.target.value)}
                  className="w-full p-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                  Main Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dreamy Earring Fiesta"
                  value={bannerTitle}
                  onChange={(e) => setBannerTitle(e.target.value)}
                  className="w-full p-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                  Subtitle
                </label>
                <input
                  type="text"
                  placeholder="e.g. Up to 40% OFF with code GLIMMER15"
                  value={bannerSubtitle}
                  onChange={(e) => setBannerSubtitle(e.target.value)}
                  className="w-full p-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                  Banner Image URL *
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://images.unsplash.com/..."
                  value={bannerImage}
                  onChange={(e) => setBannerImage(e.target.value)}
                  className="w-full p-2 border rounded-xl font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                  Link to Category
                </label>
                <select
                  value={bannerLinkCategory}
                  onChange={(e) => setBannerLinkCategory(e.target.value as any)}
                  className="w-full p-2 border rounded-xl bg-white"
                >
                  <option value="earrings">Earrings</option>
                  <option value="kan-fuli">Kan Fuli</option>
                  <option value="necklaces">Necklaces</option>
                  <option value="bracelets">Bracelets</option>
                  <option value="rings">Rings</option>
                  <option value="hair-accessories">Hair Accessories</option>
                  <option value="charms">Charms</option>
                  <option value="gift-items">Gift Items</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-pink-500 hover:bg-pink-600 text-white rounded-xl font-bold shadow-xs transition-colors"
              >
                Publish Banner
              </button>
            </form>
          </div>

          {/* Active Banners List */}
          <div className="md:col-span-7 space-y-3">
            <h3 className="font-display text-base font-bold text-stone-900">
              Active Store Banners ({banners.length})
            </h3>
            {banners.map(b => (
              <div
                key={b.id}
                className="relative rounded-2xl overflow-hidden border border-stone-200/80 shadow-xs flex items-center justify-between p-3 bg-white"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={b.imageUrl}
                    alt=""
                    className="w-16 h-16 rounded-xl object-cover border border-stone-100 flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <span className="text-[9px] font-bold text-pink-600 uppercase bg-pink-50 px-1.5 py-0.2 rounded">
                      {b.tag}
                    </span>
                    <h4 className="font-bold text-stone-900 text-xs truncate mt-0.5">{b.title}</h4>
                    <p className="text-[10px] text-stone-500 truncate">{b.subtitle}</p>
                  </div>
                </div>

                <button
                  onClick={() => deleteBanner(b.id)}
                  className="p-2 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors ml-2"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: COUPONS MANAGEMENT */}
      {activeTab === 'coupons' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Create Coupon Form */}
          <div className="md:col-span-5 p-5 rounded-3xl bg-white border border-stone-200/80 shadow-xs space-y-4">
            <h3 className="font-display text-base font-bold text-stone-900 flex items-center gap-2">
              <Tag className="w-4 h-4 text-pink-600" />
              <span>Create New Promo Coupon</span>
            </h3>

            <form onSubmit={handleCreateCoupon} className="space-y-3 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                  Coupon Code *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. FESTIVE25"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  className="w-full p-2 border rounded-xl font-mono uppercase"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Discount (%) *
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    max={90}
                    value={couponDiscount}
                    onChange={(e) => setCouponDiscount(Number(e.target.value))}
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Min Spend (₹)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={couponMinSpend}
                    onChange={(e) => setCouponMinSpend(Number(e.target.value))}
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                  Description
                </label>
                <input
                  type="text"
                  placeholder="e.g. Flat 25% OFF on dream orders above ₹500"
                  value={couponDesc}
                  onChange={(e) => setCouponDesc(e.target.value)}
                  className="w-full p-2 border rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-pink-500 hover:bg-pink-600 text-white rounded-xl font-bold shadow-xs transition-colors"
              >
                Add Coupon Code
              </button>
            </form>
          </div>

          {/* Active Coupons List */}
          <div className="md:col-span-7 space-y-3">
            <h3 className="font-display text-base font-bold text-stone-900">
              Active Promo Coupons ({coupons.length})
            </h3>

            {coupons.map(c => (
              <div
                key={c.code}
                className="p-3.5 rounded-2xl bg-white border border-stone-200/80 shadow-xs flex items-center justify-between"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-pink-700 bg-pink-50 border border-pink-200 px-2 py-0.5 rounded-md">
                      {c.code}
                    </span>
                    <span className="text-xs font-bold text-emerald-700">
                      {c.discountPercent}% OFF
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">{c.description}</p>
                  {c.minSpend && (
                    <span className="text-[10px] text-stone-400">Min spend: ₹{c.minSpend}</span>
                  )}
                </div>

                <button
                  onClick={() => deleteCoupon(c.code)}
                  className="p-2 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Coupons Tab End */}
    </div>
  );
};

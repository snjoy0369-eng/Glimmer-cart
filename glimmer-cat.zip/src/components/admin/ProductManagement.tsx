import React, { useState, useRef } from 'react';
import { Product, CategoryId, ProductVariant } from '../../types';
import { useApp } from '../../context/AppContext';
import { processAndCompressImage } from '../../services/db';
import { 
  Plus, 
  Upload, 
  Trash2, 
  Edit3, 
  Eye, 
  Check, 
  X, 
  Sparkles, 
  Image as ImageIcon, 
  Search, 
  CheckCircle2, 
  AlertCircle,
  ArrowUpDown,
  Tag,
  Package,
  Layers,
  Star,
  Flame,
  Camera,
  ExternalLink
} from 'lucide-react';

export const ProductManagement: React.FC = () => {
  const { 
    products, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    toggleProductStock,
    setSelectedProduct,
    setCurrentTab,
    addToast 
  } = useApp();

  // Search & Filters in Product Management
  const [filterSearch, setFilterSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'inStock' | 'outOfStock'>('all');

  // Modal State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isDeletingId, setIsDeletingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isProcessingPhotos, setIsProcessingPhotos] = useState(false);

  // Form Fields
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<CategoryId>('earrings');
  const [formTagline, setFormTagline] = useState('');
  const [formPrice, setFormPrice] = useState<number | ''>('');
  const [formOriginalPrice, setFormOriginalPrice] = useState<number | ''>('');
  const [formStock, setFormStock] = useState<number>(20);
  const [formIsOutOfStock, setFormIsOutOfStock] = useState<boolean>(false);
  const [formDescription, setFormDescription] = useState('');
  const [formMaterial, setFormMaterial] = useState('');
  const [formDimensions, setFormDimensions] = useState('');
  
  // Photos array (Base64 data URLs from phone/PC gallery or image links)
  const [formPhotos, setFormPhotos] = useState<string[]>([]);
  const [urlInput, setUrlInput] = useState('');
  const [showUrlInput, setShowUrlInput] = useState(false);

  // Variants & Highlights
  const [formVariants, setFormVariants] = useState<string[]>([]);
  const [newVariantInput, setNewVariantInput] = useState('');
  const [formIsBestSeller, setFormIsBestSeller] = useState(false);
  const [formIsTrending, setFormIsTrending] = useState(false);
  const [formIsViral, setFormIsViral] = useState(false);
  const [formIsNewArrival, setFormIsNewArrival] = useState(true);
  const [formIsGiftPick, setFormIsGiftPick] = useState(false);

  // File input ref for phone/computer upload
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Calculate discount dynamically
  const calculatedDiscount = React.useMemo(() => {
    const price = typeof formPrice === 'number' ? formPrice : 0;
    const orig = typeof formOriginalPrice === 'number' ? formOriginalPrice : 0;
    if (orig > price && price > 0) {
      return Math.round(((orig - price) / orig) * 100);
    }
    return 0;
  }, [formPrice, formOriginalPrice]);

  // Open Form for Adding New Product
  const handleOpenAddForm = () => {
    setEditingProduct(null);
    setFormName('');
    setFormCategory('earrings');
    setFormTagline('');
    setFormPrice('');
    setFormOriginalPrice('');
    setFormStock(20);
    setFormIsOutOfStock(false);
    setFormDescription('');
    setFormMaterial('Hypoallergenic Anti-Tarnish Alloy & Fresh Pearls');
    setFormDimensions('');
    setFormPhotos([]);
    setFormVariants(['Standard / Free Size']);
    setFormIsBestSeller(false);
    setFormIsTrending(false);
    setFormIsViral(false);
    setFormIsNewArrival(true);
    setFormIsGiftPick(false);
    setShowUrlInput(false);
    setUrlInput('');
    setIsFormOpen(true);
  };

  // Open Form for Editing Existing Product
  const handleOpenEditForm = (prod: Product) => {
    setEditingProduct(prod);
    setFormName(prod.name);
    setFormCategory(prod.categoryId);
    setFormTagline(prod.tagline || '');
    setFormPrice(prod.price);
    setFormOriginalPrice(prod.originalPrice || '');
    setFormStock(prod.stockCount);
    setFormIsOutOfStock(!!prod.isOutOfStock);
    setFormDescription(prod.description);
    setFormMaterial(prod.material);
    setFormDimensions(prod.dimensions || '');
    setFormPhotos(prod.images || []);
    setFormVariants(prod.variants?.map(v => v.name) || []);
    setFormIsBestSeller(!!prod.isBestSeller);
    setFormIsTrending(!!prod.isTrending);
    setFormIsViral(!!prod.isViral);
    setFormIsNewArrival(!!prod.isNewArrival);
    setFormIsGiftPick(!!prod.isGiftPick);
    setShowUrlInput(false);
    setUrlInput('');
    setIsFormOpen(true);
  };

  // Handle Photo File Upload (From Phone Gallery or Computer)
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsProcessingPhotos(true);
    const newPhotos: string[] = [];

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.type.startsWith('image/')) {
          const compressed = await processAndCompressImage(file, 1280, 0.85);
          newPhotos.push(compressed);
        }
      }

      setFormPhotos(prev => [...prev, ...newPhotos]);
      addToast(`${newPhotos.length} photo(s) uploaded and optimized ✨`, 'sparkle');
    } catch (err) {
      console.error('Photo processing error:', err);
      addToast('Failed to process one or more photos. Please try again.', 'error');
    } finally {
      setIsProcessingPhotos(false);
      // Reset input value so same files can be re-selected if needed
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Remove a photo from form list
  const handleRemovePhoto = (indexToRemove: number) => {
    setFormPhotos(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  // Set a photo as Primary Cover (move to index 0)
  const handleSetPrimaryPhoto = (indexToMove: number) => {
    setFormPhotos(prev => {
      const copy = [...prev];
      const [item] = copy.splice(indexToMove, 1);
      return [item, ...copy];
    });
    addToast('Set as main cover photo ⭐', 'info');
  };

  // Add photo via direct URL
  const handleAddPhotoFromUrl = () => {
    if (!urlInput.trim()) return;
    setFormPhotos(prev => [...prev, urlInput.trim()]);
    setUrlInput('');
    setShowUrlInput(false);
    addToast('Photo URL added', 'success');
  };

  // Add variant tag
  const handleAddVariant = () => {
    if (!newVariantInput.trim()) return;
    if (!formVariants.includes(newVariantInput.trim())) {
      setFormVariants(prev => [...prev, newVariantInput.trim()]);
    }
    setNewVariantInput('');
  };

  // Remove variant tag
  const handleRemoveVariant = (name: string) => {
    setFormVariants(prev => prev.filter(v => v !== name));
  };

  // Category name mapping
  const getCategoryName = (catId: CategoryId): string => {
    switch (catId) {
      case 'earrings': return 'Earrings';
      case 'kan-fuli': return 'Kan Fuli';
      case 'necklaces': return 'Necklaces';
      case 'bracelets': return 'Bracelets';
      case 'rings': return 'Rings';
      case 'hair-accessories': return 'Hair Accessories';
      case 'charms': return 'Charms';
      case 'gift-items': return 'Gift Items';
      default: return 'Accessories';
    }
  };

  // Save Product (Create or Update)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formName.trim()) {
      addToast('Please enter a product name', 'error');
      return;
    }

    const price = typeof formPrice === 'number' ? formPrice : parseFloat(formPrice as any);
    if (!price || isNaN(price) || price <= 0) {
      addToast('Please enter a valid selling price', 'error');
      return;
    }

    if (formPhotos.length === 0) {
      addToast('Please upload at least 1 photo for your product', 'error');
      return;
    }

    setIsSaving(true);

    try {
      const origPrice = formOriginalPrice ? Number(formOriginalPrice) : undefined;
      const discount = (origPrice && origPrice > price) 
        ? Math.round(((origPrice - price) / origPrice) * 100) 
        : undefined;

      const variants: ProductVariant[] = formVariants.map((v, i) => ({
        id: `var-${i + 1}`,
        name: v,
        inStock: !formIsOutOfStock
      }));

      const productPayload: Omit<Product, 'id'> = {
        name: formName.trim(),
        tagline: formTagline.trim() || undefined,
        categoryId: formCategory,
        categoryName: getCategoryName(formCategory),
        price: price,
        originalPrice: origPrice,
        discountPercent: discount,
        rating: editingProduct?.rating || 5.0,
        reviewsCount: editingProduct?.reviewsCount || 1,
        images: formPhotos,
        description: formDescription.trim() || `${formName.trim()} handcrafted with premium finish and signature Glimmer Cart aesthetics.`,
        material: formMaterial.trim() || 'Hypoallergenic Anti-Tarnish Alloy & Fresh Pearls',
        dimensions: formDimensions.trim() || undefined,
        stockCount: formIsOutOfStock ? 0 : Number(formStock) || 10,
        isOutOfStock: formIsOutOfStock || formStock <= 0,
        isBestSeller: formIsBestSeller,
        isTrending: formIsTrending,
        isViral: formIsViral || formCategory === 'kan-fuli',
        isNewArrival: formIsNewArrival,
        isGiftPick: formIsGiftPick,
        tags: [
          formCategory,
          formName.toLowerCase(),
          getCategoryName(formCategory).toLowerCase(),
          'jewelry',
          'accessories',
          'cute'
        ],
        variants: variants.length > 0 ? variants : undefined
      };

      if (editingProduct) {
        await updateProduct(editingProduct.id, productPayload);
      } else {
        await addProduct(productPayload);
      }

      setIsFormOpen(false);
      setEditingProduct(null);
    } catch (err) {
      console.error('Error saving product:', err);
      addToast('Error saving product. Please check your data.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Filtered Products
  const filteredProducts = products.filter(p => {
    // Search match
    if (filterSearch.trim()) {
      const q = filterSearch.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchCat = p.categoryName.toLowerCase().includes(q);
      const matchDesc = p.description.toLowerCase().includes(q);
      if (!matchName && !matchCat && !matchDesc) return false;
    }

    // Category match
    if (filterCategory !== 'all' && p.categoryId !== filterCategory) {
      return false;
    }

    // Status match
    if (filterStatus === 'inStock' && (p.isOutOfStock || p.stockCount <= 0)) {
      return false;
    }
    if (filterStatus === 'outOfStock' && !p.isOutOfStock && p.stockCount > 0) {
      return false;
    }

    return true;
  });

  const totalInStock = products.filter(p => !p.isOutOfStock && p.stockCount > 0).length;
  const totalOutOfStock = products.filter(p => p.isOutOfStock || p.stockCount <= 0).length;

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-pink-500 via-purple-600 to-pink-600 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Store Products Catalog</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-display tracking-tight">
            Manage &amp; Sell Your Products
          </h2>
          <p className="text-xs sm:text-sm text-pink-100 max-w-xl">
            Add real jewelry items, upload photos directly from your phone or computer, manage prices, discounts, and inventory stock.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setCurrentTab('home')}
            className="px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md transition-all border border-white/20"
          >
            <Eye className="w-4 h-4" />
            <span>View Live Store</span>
          </button>

          <button
            onClick={handleOpenAddForm}
            className="px-5 py-2.5 rounded-2xl bg-white text-purple-900 hover:bg-pink-50 text-xs sm:text-sm font-bold flex items-center gap-2 shadow-lg transition-all transform active:scale-95"
          >
            <Plus className="w-4 h-4 text-pink-600" />
            <span>Add New Product</span>
          </button>
        </div>
      </div>

      {/* Metrics Summary Strip */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-stone-500 block uppercase tracking-wider">Total Products</span>
            <span className="text-xl sm:text-2xl font-bold text-stone-900 font-display">{products.length}</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Package className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-stone-500 block uppercase tracking-wider">Available (In Stock)</span>
            <span className="text-xl sm:text-2xl font-bold text-emerald-600 font-display">{totalInStock}</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-stone-500 block uppercase tracking-wider">Out of Stock</span>
            <span className="text-xl sm:text-2xl font-bold text-rose-600 font-display">{totalOutOfStock}</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Search input */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search products by title, category, material..."
            value={filterSearch}
            onChange={(e) => setFilterSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500 focus:ring-1 focus:ring-pink-400 bg-stone-50/50"
          />
          {filterSearch && (
            <button
              onClick={() => setFilterSearch('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Category & Status dropdowns */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="text-xs border border-stone-200 rounded-xl py-2 px-3 bg-white text-stone-700 focus:outline-none focus:border-pink-500"
          >
            <option value="all">All Categories</option>
            <option value="earrings">Earrings</option>
            <option value="kan-fuli">Kan Fuli</option>
            <option value="necklaces">Necklaces</option>
            <option value="bracelets">Bracelets</option>
            <option value="rings">Rings</option>
            <option value="hair-accessories">Hair Accessories</option>
            <option value="charms">Charms</option>
            <option value="gift-items">Gift Items</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="text-xs border border-stone-200 rounded-xl py-2 px-3 bg-white text-stone-700 focus:outline-none focus:border-pink-500"
          >
            <option value="all">All Stock Status</option>
            <option value="inStock">Available In Stock</option>
            <option value="outOfStock">Out of Stock</option>
          </select>
        </div>
      </div>

      {/* Products List Section */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-pink-200 space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-full bg-pink-50 text-pink-500 mx-auto flex items-center justify-center">
            <ImageIcon className="w-8 h-8" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="font-display text-lg font-bold text-stone-900">
              {products.length === 0 ? 'No Products in Your Store Yet' : 'No Products Match Filters'}
            </h3>
            <p className="text-xs text-stone-500 leading-relaxed">
              {products.length === 0
                ? 'Your store is clean and ready for your real jewelry items. Click below to add your first product with your own photos from your phone or computer!'
                : 'Try adjusting your search query or category filters to see matching products.'}
            </p>
          </div>
          {products.length === 0 ? (
            <button
              onClick={handleOpenAddForm}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 text-white text-xs font-bold inline-flex items-center gap-2 shadow-md hover:from-pink-600 hover:to-purple-700 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Your First Product</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setFilterSearch('');
                setFilterCategory('all');
                setFilterStatus('all');
              }}
              className="px-4 py-2 rounded-xl bg-stone-100 text-stone-700 text-xs font-semibold hover:bg-stone-200 transition-colors"
            >
              Clear Filters
            </button>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-stone-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3.5 px-4">Product Details</th>
                  <th className="py-3.5 px-3">Category</th>
                  <th className="py-3.5 px-3">Price &amp; Discount</th>
                  <th className="py-3.5 px-3">Stock Units</th>
                  <th className="py-3.5 px-3">Availability</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredProducts.map((p) => {
                  const isAvailable = !p.isOutOfStock && p.stockCount > 0;
                  const coverImage = p.images && p.images.length > 0 ? p.images[0] : '';

                  return (
                    <tr key={p.id} className="hover:bg-pink-50/30 transition-colors group">
                      {/* Product Name & Photo */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-stone-100 flex-shrink-0 border border-stone-200">
                            {coverImage ? (
                              <img
                                src={coverImage}
                                alt={p.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-stone-400">
                                <ImageIcon className="w-5 h-5" />
                              </div>
                            )}
                            {p.images && p.images.length > 1 && (
                              <span className="absolute bottom-0.5 right-0.5 bg-black/70 text-white text-[9px] px-1 rounded font-mono">
                                📷 {p.images.length}
                              </span>
                            )}
                          </div>

                          <div className="space-y-0.5 max-w-xs">
                            <span className="font-bold text-stone-900 block group-hover:text-pink-600 transition-colors line-clamp-1">
                              {p.name}
                            </span>
                            {p.tagline && (
                              <span className="text-[11px] text-stone-500 block line-clamp-1">
                                {p.tagline}
                              </span>
                            )}
                            <div className="flex flex-wrap items-center gap-1 pt-0.5">
                              {p.isBestSeller && (
                                <span className="text-[9px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded">
                                  ⭐ Best Seller
                                </span>
                              )}
                              {p.isTrending && (
                                <span className="text-[9px] font-bold bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded">
                                  🔥 Trending
                                </span>
                              )}
                              {p.categoryId === 'kan-fuli' && (
                                <span className="text-[9px] font-bold bg-purple-100 text-purple-800 px-1.5 py-0.2 rounded">
                                  ✨ Kan Fuli
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3.5 px-3">
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-stone-100 text-stone-700">
                          {p.categoryName}
                        </span>
                      </td>

                      {/* Price & Discount */}
                      <td className="py-3.5 px-3">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-stone-900 text-sm">
                              ₹{p.price}
                            </span>
                            {p.originalPrice && p.originalPrice > p.price && (
                              <span className="text-[11px] text-stone-400 line-through">
                                ₹{p.originalPrice}
                              </span>
                            )}
                          </div>
                          {p.discountPercent ? (
                            <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">
                              {p.discountPercent}% OFF
                            </span>
                          ) : null}
                        </div>
                      </td>

                      {/* Stock count */}
                      <td className="py-3.5 px-3">
                        <span className={`font-mono font-semibold ${p.stockCount <= 5 ? 'text-amber-600' : 'text-stone-700'}`}>
                          {p.stockCount} units
                        </span>
                      </td>

                      {/* Availability status toggle */}
                      <td className="py-3.5 px-3">
                        <button
                          onClick={() => toggleProductStock(p.id)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold transition-all shadow-xs ${
                            isAvailable
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                              : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                          }`}
                          title="Click to toggle availability status"
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              isAvailable ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
                            }`}
                          />
                          <span>{isAvailable ? 'Available' : 'Out of Stock'}</span>
                        </button>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Preview in Store */}
                          <button
                            onClick={() => setSelectedProduct(p)}
                            title="Preview on Store"
                            className="p-2 rounded-xl text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Edit Product */}
                          <button
                            onClick={() => handleOpenEditForm(p)}
                            title="Edit Product Details & Photos"
                            className="p-2 rounded-xl text-purple-600 hover:bg-purple-50 transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {/* Delete Product */}
                          <button
                            onClick={() => setIsDeletingId(p.id)}
                            title="Delete Product"
                            className="p-2 rounded-xl text-rose-500 hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {isDeletingId && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 border border-rose-100 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 mx-auto flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-display text-base font-bold text-stone-900">
                Delete Product?
              </h3>
              <p className="text-xs text-stone-500">
                Are you sure you want to delete this product? It will be removed from your catalog and live store.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setIsDeletingId(null)}
                className="w-1/2 py-2.5 rounded-xl bg-stone-100 text-stone-700 text-xs font-bold hover:bg-stone-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  if (isDeletingId) {
                    await deleteProduct(isDeletingId);
                    setIsDeletingId(null);
                  }
                }}
                className="w-1/2 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition-colors shadow-xs"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD / EDIT PRODUCT FULL MODAL */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-pink-100 my-8 overflow-hidden flex flex-col max-h-[92vh]">
            {/* Modal Header */}
            <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-6 py-4 flex items-center justify-between border-b border-stone-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 text-white flex items-center justify-center shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-base font-bold text-stone-900">
                    {editingProduct ? 'Edit Product' : 'Add New Product to Store'}
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    Fill in the details below. Photos and changes save directly to your database.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsFormOpen(false)}
                className="text-stone-400 hover:text-stone-800 p-2 rounded-full hover:bg-stone-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Form Body */}
            <form onSubmit={handleSaveProduct} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
              
              {/* SECTION 1: BASIC INFORMATION */}
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-3">
                <div className="flex items-center gap-1.5 text-stone-800 font-bold text-sm">
                  <Tag className="w-4 h-4 text-pink-600" />
                  <span>1. Basic Product Information</span>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-stone-700 block mb-1">
                    Product Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Celestial Moonstone Ear Cuff &amp; Kan Fuli"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500 focus:ring-1 focus:ring-pink-400"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Product Category *
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as CategoryId)}
                      className="w-full p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500"
                    >
                      <option value="earrings">Earrings</option>
                      <option value="kan-fuli">Kan Fuli</option>
                      <option value="necklaces">Necklaces</option>
                      <option value="bracelets">Bracelets</option>
                      <option value="rings">Rings</option>
                      <option value="hair-accessories">Hair Accessories</option>
                      <option value="charms">Charms</option>
                      <option value="gift-items">Gift Items</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Short Tagline / Highlight
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Dainty floral cascade with iridescent pearl drops"
                      value={formTagline}
                      onChange={(e) => setFormTagline(e.target.value)}
                      className="w-full p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 2: PRICING & DISCOUNT */}
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-stone-800 font-bold text-sm">
                    <span className="text-pink-600 font-bold font-mono">₹</span>
                    <span>2. Price &amp; Discount</span>
                  </div>

                  {calculatedDiscount > 0 && (
                    <span className="bg-rose-100 text-rose-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                      🎉 Customer saves {calculatedDiscount}% OFF
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Selling Price (₹) *
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 font-bold">₹</span>
                      <input
                        type="number"
                        required
                        min={1}
                        placeholder="e.g. 499"
                        value={formPrice}
                        onChange={(e) => setFormPrice(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full pl-7 pr-3 py-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500 font-mono font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Original / MRP Price (₹) (Optional, to show discount)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 font-bold">₹</span>
                      <input
                        type="number"
                        min={1}
                        placeholder="e.g. 799"
                        value={formOriginalPrice}
                        onChange={(e) => setFormOriginalPrice(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full pl-7 pr-3 py-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500 font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 3: STOCK & STATUS */}
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-3">
                <div className="flex items-center gap-1.5 text-stone-800 font-bold text-sm">
                  <Package className="w-4 h-4 text-pink-600" />
                  <span>3. Stock &amp; Availability</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Available Stock Count
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={formStock}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setFormStock(val);
                        if (val <= 0) setFormIsOutOfStock(true);
                      }}
                      className="w-full p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Product Status
                    </label>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setFormIsOutOfStock(false)}
                        className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition-all ${
                          !formIsOutOfStock
                            ? 'bg-emerald-500 text-white border-emerald-600 shadow-xs'
                            : 'bg-white text-stone-600 border-stone-200'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>In Stock (Available)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setFormIsOutOfStock(true)}
                        className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition-all ${
                          formIsOutOfStock
                            ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                            : 'bg-white text-stone-600 border-stone-200'
                        }`}
                      >
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>Out of Stock</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 4: PRODUCT PHOTOS (UPLOAD FROM PHONE OR COMPUTER) */}
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-stone-800 font-bold text-sm">
                    <Camera className="w-4 h-4 text-pink-600" />
                    <span>4. Product Photos (Upload from Gallery) *</span>
                  </div>

                  <span className="text-[11px] font-medium text-stone-500">
                    {formPhotos.length} photo(s) selected
                  </span>
                </div>

                <p className="text-[11px] text-stone-500 leading-relaxed">
                  Upload multiple real photos directly from your phone camera roll or computer files. The first photo will be used as the main cover photo.
                </p>

                {/* Big Upload Dropzone Button */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handlePhotoUpload}
                  multiple
                  accept="image/*"
                  className="hidden"
                />

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isProcessingPhotos}
                    className="w-full py-4 px-4 rounded-2xl border-2 border-dashed border-pink-300 hover:border-pink-500 bg-pink-50/50 hover:bg-pink-100/50 text-pink-700 flex flex-col items-center justify-center gap-1.5 transition-all group"
                  >
                    <Upload className="w-6 h-6 text-pink-600 group-hover:scale-110 transition-transform" />
                    <span className="font-bold text-xs">
                      {isProcessingPhotos ? 'Optimizing Photos...' : '📁 Choose Photos from Phone / Computer'}
                    </span>
                    <span className="text-[10px] text-stone-500">
                      Tap to open camera or gallery (JPG, PNG, WebP)
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="w-full py-4 px-4 rounded-2xl border border-stone-200 bg-white hover:bg-stone-100/60 text-stone-700 flex flex-col items-center justify-center gap-1.5 transition-all"
                  >
                    <ExternalLink className="w-5 h-5 text-stone-500" />
                    <span className="font-bold text-xs">Or Paste Image URL</span>
                    <span className="text-[10px] text-stone-400">If you already have web links</span>
                  </button>
                </div>

                {/* URL Input sub-bar if toggled */}
                {showUrlInput && (
                  <div className="flex items-center gap-2 p-2 bg-white rounded-xl border border-stone-200">
                    <input
                      type="url"
                      placeholder="https://images.unsplash.com/... or https://..."
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      className="flex-1 p-1.5 text-xs focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleAddPhotoFromUrl}
                      className="px-3 py-1.5 bg-pink-500 hover:bg-pink-600 text-white rounded-lg font-bold text-xs"
                    >
                      Add URL
                    </button>
                  </div>
                )}

                {/* Uploaded Photos Grid */}
                {formPhotos.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <span className="text-[11px] font-bold text-stone-600 block">
                      Uploaded Photos Preview:
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                      {formPhotos.map((photo, idx) => (
                        <div
                          key={idx}
                          className="relative aspect-square rounded-xl overflow-hidden bg-stone-100 border-2 border-stone-200 group shadow-xs"
                        >
                          <img
                            src={photo}
                            alt={`Product Photo ${idx + 1}`}
                            className="w-full h-full object-cover"
                          />

                          {/* Primary Cover Badge */}
                          {idx === 0 ? (
                            <span className="absolute top-1.5 left-1.5 bg-pink-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs">
                              ⭐ Cover
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleSetPrimaryPhoto(idx)}
                              className="absolute top-1.5 left-1.5 bg-black/60 hover:bg-pink-600 text-white text-[9px] font-semibold px-1.5 py-0.5 rounded backdrop-blur-xs transition-colors"
                              title="Make this photo the main cover photo"
                            >
                              Set Cover
                            </button>
                          )}

                          {/* Delete Photo Button */}
                          <button
                            type="button"
                            onClick={() => handleRemovePhoto(idx)}
                            className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center opacity-80 hover:opacity-100 transition-opacity shadow-xs"
                            title="Remove photo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* SECTION 5: DESCRIPTION & MATERIAL */}
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-3">
                <div className="flex items-center gap-1.5 text-stone-800 font-bold text-sm">
                  <Layers className="w-4 h-4 text-pink-600" />
                  <span>5. Description &amp; Material Details</span>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-stone-700 block mb-1">
                    Product Description
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Describe the product aesthetic, occasions to wear, packaging, and styling tips..."
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    className="w-full p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Material / Craftsmanship
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 18K Gold Plated Alloy, Anti-tarnish, CZ Crystals"
                      value={formMaterial}
                      onChange={(e) => setFormMaterial(e.target.value)}
                      className="w-full p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Dimensions / Sizing (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Length 6.5 cm, Weight 7g"
                      value={formDimensions}
                      onChange={(e) => setFormDimensions(e.target.value)}
                      className="w-full p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 6: VARIANTS (OPTIONAL) */}
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-3">
                <div className="flex items-center gap-1.5 text-stone-800 font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-pink-600" />
                  <span>6. Sizes or Color Variants (Optional)</span>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Add variant name (e.g. Rose Gold, Silver, Free Size, Pink)..."
                    value={newVariantInput}
                    onChange={(e) => setNewVariantInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddVariant();
                      }
                    }}
                    className="flex-1 p-2 bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-pink-500 text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddVariant}
                    className="px-3.5 py-2 bg-stone-900 text-white rounded-xl font-bold text-xs hover:bg-stone-800"
                  >
                    + Add
                  </button>
                </div>

                {formVariants.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {formVariants.map((v, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-white border border-pink-200 text-pink-700 rounded-full text-xs font-semibold shadow-2xs"
                      >
                        <span>{v}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveVariant(v)}
                          className="text-stone-400 hover:text-rose-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* SECTION 7: STOREFRONT BADGES */}
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-2.5">
                <div className="flex items-center gap-1.5 text-stone-800 font-bold text-sm">
                  <Star className="w-4 h-4 text-amber-500" />
                  <span>7. Storefront Highlights</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-stone-200 cursor-pointer hover:border-pink-300">
                    <input
                      type="checkbox"
                      checked={formIsNewArrival}
                      onChange={(e) => setFormIsNewArrival(e.target.checked)}
                      className="accent-pink-600 rounded"
                    />
                    <span className="font-semibold text-stone-800 text-[11px]">🆕 New Arrival</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-stone-200 cursor-pointer hover:border-pink-300">
                    <input
                      type="checkbox"
                      checked={formIsBestSeller}
                      onChange={(e) => setFormIsBestSeller(e.target.checked)}
                      className="accent-pink-600 rounded"
                    />
                    <span className="font-semibold text-stone-800 text-[11px]">⭐ Best Seller</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-stone-200 cursor-pointer hover:border-pink-300">
                    <input
                      type="checkbox"
                      checked={formIsTrending}
                      onChange={(e) => setFormIsTrending(e.target.checked)}
                      className="accent-pink-600 rounded"
                    />
                    <span className="font-semibold text-stone-800 text-[11px]">🔥 Trending</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-stone-200 cursor-pointer hover:border-pink-300">
                    <input
                      type="checkbox"
                      checked={formIsGiftPick}
                      onChange={(e) => setFormIsGiftPick(e.target.checked)}
                      className="accent-pink-600 rounded"
                    />
                    <span className="font-semibold text-stone-800 text-[11px]">🎁 Gift Pick</span>
                  </label>
                </div>
              </div>

              {/* Bottom Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-stone-100 text-stone-700 font-bold hover:bg-stone-200 transition-colors"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSaving || isProcessingPhotos}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-pink-500 via-purple-600 to-pink-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  {isSaving ? (
                    <span>Saving to Database...</span>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{editingProduct ? 'Update Product' : 'Publish Product to Store ✨'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

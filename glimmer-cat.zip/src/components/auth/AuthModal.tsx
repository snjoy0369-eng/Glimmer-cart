import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Smartphone, Mail, Sparkles, Check, ArrowRight, ShieldCheck, User as UserIcon } from 'lucide-react';
import { CatLogo } from '../common/CatLogo';
import { findExistingUser } from '../../services/userService';

export const AuthModal: React.FC = () => {
  const { 
    isAuthModalOpen, 
    closeAuthModal, 
    authModalMode, 
    loginWithMobileOtp, 
    loginWithGoogle, 
    loginWithEmail 
  } = useApp();

  // Mode: 'mobile-otp' | 'email'
  const [activeMethod, setActiveMethod] = useState<'mobile-otp' | 'email'>('mobile-otp');

  // Mobile OTP state
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [optionalEmail, setOptionalEmail] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('4242');
  const [existingUserFound, setExistingUserFound] = useState<string | null>(null);

  // Email form state
  const [emailName, setEmailName] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [emailMobile, setEmailMobile] = useState('');
  const [emailPassword, setEmailPassword] = useState('');

  // Auto-detect returning user by mobile number
  useEffect(() => {
    const cleanMobile = mobileNumber.replace(/\D/g, '');
    if (cleanMobile.length === 10) {
      const found = findExistingUser({ mobile: cleanMobile });
      if (found) {
        setExistingUserFound(found.name);
        if (!fullName.trim()) {
          setFullName(found.name);
        }
        if (!optionalEmail && found.email) {
          setOptionalEmail(found.email);
        }
      } else {
        setExistingUserFound(null);
      }
    } else {
      setExistingUserFound(null);
    }
  }, [mobileNumber]);

  // Auto-detect returning user by email
  useEffect(() => {
    if (emailAddress.includes('@') && emailAddress.includes('.')) {
      const found = findExistingUser({ email: emailAddress.trim().toLowerCase() });
      if (found) {
        if (!emailName.trim()) {
          setEmailName(found.name);
        }
        if (!emailMobile && found.mobile) {
          setEmailMobile(found.mobile.replace(/\D/g, '').slice(-10));
        }
      }
    }
  }, [emailAddress]);

  if (!isAuthModalOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      alert('Please enter your full name');
      return;
    }
    const cleanMobile = mobileNumber.replace(/\D/g, '');
    if (cleanMobile.length < 10) {
      alert('Please enter a valid 10-digit mobile number');
      return;
    }

    setOtpSent(true);
    setOtpCode('4242'); // Preset for smooth testing
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode) return;

    // Automatic Profile Creation / Loading & redirect to Home
    loginWithMobileOtp({
      fullName: fullName.trim(),
      mobile: mobileNumber.replace(/\D/g, ''),
      email: optionalEmail.trim()
    });

    // Reset local modal state
    setOtpSent(false);
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailName.trim()) {
      alert('Please enter your full name');
      return;
    }
    if (!emailAddress.trim()) {
      alert('Please enter your email address');
      return;
    }

    // Automatic Profile Creation / Loading & redirect to Home
    loginWithEmail({
      fullName: emailName.trim(),
      email: emailAddress.trim(),
      mobile: emailMobile.replace(/\D/g, '')
    });
  };

  const handleGoogleSignIn = () => {
    // If name is already provided in either field, use it
    const nameToUse = fullName.trim() || emailName.trim() || 'Glimmer Shopper';
    const emailToUse = optionalEmail.trim() || emailAddress.trim() || 'shopper@gmail.com';

    loginWithGoogle({
      fullName: nameToUse,
      email: emailToUse
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl p-6 sm:p-7 space-y-4 border border-pink-100 shadow-2xl overflow-hidden max-h-[95vh] overflow-y-auto">
        {/* Decorative corner glow */}
        <div className="absolute top-0 right-0 -mr-10 -mt-10 w-36 h-36 bg-pink-200/40 rounded-full blur-2xl pointer-events-none" />

        {/* Close button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="text-center space-y-1.5">
          <div className="flex justify-center">
            <CatLogo size="md" />
          </div>
          <h2 className="font-display text-xl font-bold text-stone-900">
            Welcome to Glimmer Cart
          </h2>
          <p className="text-xs text-stone-500 max-w-xs mx-auto">
            Enter your details below. Your personal profile will be created automatically!
          </p>
        </div>

        {/* Method Toggle Buttons */}
        <div className="flex rounded-xl bg-stone-100 p-1 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setActiveMethod('mobile-otp');
              setOtpSent(false);
            }}
            className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeMethod === 'mobile-otp'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-pink-600" />
            <span>Mobile OTP</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMethod('email')}
            className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeMethod === 'email'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Mail className="w-3.5 h-3.5 text-purple-600" />
            <span>Email Login</span>
          </button>
        </div>

        {/* METHOD 1: MOBILE NUMBER + OTP */}
        {activeMethod === 'mobile-otp' && (
          <div className="space-y-3">
            {!otpSent ? (
              <form onSubmit={handleSendOtp} className="space-y-3">
                {/* 1. Full Name */}
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Full Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-pink-500 focus-within:bg-white transition-all px-3 py-2">
                    <UserIcon className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Rahul"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full text-xs bg-transparent focus:outline-none font-medium text-stone-800"
                      autoFocus
                    />
                  </div>
                </div>

                {/* 2. Mobile Number */}
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Mobile Number <span className="text-rose-500">*</span>
                  </label>
                  <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-pink-500 focus-within:bg-white transition-all">
                    <span className="px-3 text-xs font-semibold text-stone-500 border-r border-stone-200 bg-stone-100/70 py-2.5">
                      +91
                    </span>
                    <input
                      type="tel"
                      maxLength={10}
                      required
                      placeholder="98765 43210"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-2 text-xs bg-transparent focus:outline-none font-mono"
                    />
                  </div>
                  {existingUserFound && (
                    <p className="text-[11px] text-pink-600 font-medium mt-1 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 shrink-0" />
                      <span>Existing account found for {existingUserFound}! Loading your profile.</span>
                    </p>
                  )}
                </div>

                {/* 3. Email (Optional) */}
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Email Address <span className="text-stone-400 font-normal">(Optional)</span>
                  </label>
                  <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-pink-500 focus-within:bg-white transition-all px-3 py-2">
                    <Mail className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                    <input
                      type="email"
                      placeholder="name@example.com (optional)"
                      value={optionalEmail}
                      onChange={(e) => setOptionalEmail(e.target.value)}
                      className="w-full text-xs bg-transparent focus:outline-none text-stone-800"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5 active:scale-98"
                >
                  <span>Continue with OTP</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3.5 animate-in fade-in duration-200">
                {/* Confirmation Box */}
                <div className="p-3 bg-pink-50/70 border border-pink-100 rounded-2xl text-xs space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-stone-800">{fullName}</span>
                    <button
                      type="button"
                      onClick={() => setOtpSent(false)}
                      className="text-[10px] text-pink-600 hover:underline font-semibold"
                    >
                      Edit details
                    </button>
                  </div>
                  <p className="text-stone-500 text-[11px] font-mono">📱 +91 {mobileNumber}</p>
                  {optionalEmail && (
                    <p className="text-stone-500 text-[11px]">✉️ {optionalEmail}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-stone-700 block">
                    Enter 4-digit Verification Code
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    required
                    placeholder="4242"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full text-center py-2.5 text-xl tracking-widest font-mono font-bold border border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 bg-pink-50/20"
                    autoFocus
                  />
                  <div className="flex items-center justify-between text-[11px] text-stone-500 px-1 pt-1">
                    <span>
                      Demo code: <strong className="text-pink-600 font-mono">4242</strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => setOtpCode('4242')}
                      className="text-pink-600 hover:underline text-[10px] font-semibold"
                    >
                      Auto-fill OTP
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-pink-500 hover:bg-pink-600 text-white text-xs font-bold shadow-md transition-colors flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Verify &amp; Enter Store</span>
                </button>
              </form>
            )}
          </div>
        )}

        {/* METHOD 2: EMAIL + PASSWORD */}
        {activeMethod === 'email' && (
          <form onSubmit={handleEmailSubmit} className="space-y-3">
            {/* Full Name */}
            <div>
              <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                Full Name <span className="text-rose-500">*</span>
              </label>
              <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-purple-500 focus-within:bg-white transition-all px-3 py-2">
                <UserIcon className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul"
                  value={emailName}
                  onChange={(e) => setEmailName(e.target.value)}
                  className="w-full text-xs bg-transparent focus:outline-none font-medium text-stone-800"
                  autoFocus
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                Email Address <span className="text-rose-500">*</span>
              </label>
              <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-purple-500 focus-within:bg-white transition-all px-3 py-2">
                <Mail className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                <input
                  type="email"
                  required
                  placeholder="rahul@example.com"
                  value={emailAddress}
                  onChange={(e) => setEmailAddress(e.target.value)}
                  className="w-full text-xs bg-transparent focus:outline-none text-stone-800"
                />
              </div>
            </div>

            {/* Mobile (Optional) */}
            <div>
              <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                Mobile Number <span className="text-stone-400 font-normal">(Optional)</span>
              </label>
              <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50 focus-within:border-purple-500 focus-within:bg-white transition-all px-3 py-2">
                <Smartphone className="w-4 h-4 text-stone-400 mr-2 shrink-0" />
                <input
                  type="tel"
                  maxLength={10}
                  placeholder="98765 43210"
                  value={emailMobile}
                  onChange={(e) => setEmailMobile(e.target.value.replace(/\D/g, ''))}
                  className="w-full text-xs bg-transparent focus:outline-none font-mono text-stone-800"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                Password
              </label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={emailPassword}
                onChange={(e) => setEmailPassword(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-stone-200 rounded-xl focus:outline-none focus:border-purple-500 bg-stone-50"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md transition-colors"
            >
              Enter Store &amp; Create Profile
            </button>
          </form>
        )}

        <div className="flex items-center gap-2 text-[11px] text-stone-400 pt-1">
          <div className="flex-1 h-px bg-stone-200" />
          <span>or quick continue</span>
          <div className="flex-1 h-px bg-stone-200" />
        </div>

        {/* Google Quick Sign-In */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          className="w-full py-2.5 px-4 rounded-xl border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 text-xs font-bold flex items-center justify-center gap-2.5 shadow-xs transition-colors"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        {/* Guest browsing */}
        <div className="pt-1 text-center">
          <button
            type="button"
            onClick={closeAuthModal}
            className="text-[11px] text-stone-400 hover:text-stone-600 transition-colors"
          >
            Skip for now &amp; browse as guest 🐾
          </button>
        </div>
      </div>
    </div>
  );
};

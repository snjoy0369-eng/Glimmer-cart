import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  Tag, 
  ArrowRight, 
  Sparkles, 
  Check, 
  Truck, 
  ShieldCheck 
} from 'lucide-react';

export const CartView: React.FC = () => {
  const { 
    cart, 
    updateCartQuantity, 
    removeFromCart, 
    clearCart,
    cartSubtotal, 
    deliveryCharge, 
    discountAmount, 
    cartTotal,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    coupons,
    openCheckout,
    setCurrentTab 
  } = useApp();

  const [couponInput, setCouponInput] = useState('');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    applyCoupon(couponInput.trim());
    setCouponInput('');
  };

  // Free delivery calculation (Free over ₹499)
  const freeShippingThreshold = 499;
  const amountNeededForFreeShipping = Math.max(0, freeShippingThreshold - cartSubtotal);
  const freeShippingProgress = Math.min(100, Math.round((cartSubtotal / freeShippingThreshold) * 100));

  if (cart.length === 0) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4 pb-24 animate-in fade-in duration-200">
        <div className="w-24 h-24 rounded-3xl bg-pink-50 text-pink-400 mx-auto flex items-center justify-center text-4xl shadow-inner border border-pink-100">
          🛍️
        </div>
        <div className="space-y-1">
          <h2 className="font-display text-xl font-bold text-stone-900">
            Your shopping bag is empty
          </h2>
          <p className="text-xs text-stone-500 max-w-xs mx-auto">
            Your dream accessories are waiting! Discover our viral Kan Fuli, floral studs, and cute charms.
          </p>
        </div>
        <button
          onClick={() => setCurrentTab('home')}
          className="px-6 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white text-xs font-bold shadow-md inline-flex items-center gap-2 transition-transform active:scale-95"
        >
          <span>Start Shopping</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-4 space-y-6 pb-28 animate-in fade-in duration-200">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-stone-200 pb-3">
        <div>
          <h2 className="font-display text-2xl font-bold text-stone-900 flex items-center gap-2">
            <span>Shopping Cart</span>
            <span className="text-xs bg-pink-100 text-pink-700 px-2 py-0.5 rounded-full font-sans font-bold">
              {cart.length} {cart.length === 1 ? 'item' : 'items'}
            </span>
          </h2>
          <p className="text-xs text-stone-500">
            Review your sparkles before checkout
          </p>
        </div>

        <button
          onClick={clearCart}
          className="text-xs text-stone-400 hover:text-rose-600 transition-colors"
        >
          Clear Cart
        </button>
      </div>

      {/* Free Shipping Progress Alert */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-pink-50/90 to-purple-50/90 border border-pink-100 space-y-1.5">
        <div className="flex items-center justify-between text-xs font-semibold">
          <span className="flex items-center gap-1.5 text-stone-800">
            <Truck className="w-4 h-4 text-pink-600" />
            {amountNeededForFreeShipping === 0 ? (
              <span className="text-emerald-700 font-bold">🎉 You unlocked FREE Delivery!</span>
            ) : (
              <span>Add <strong className="text-pink-600">₹{amountNeededForFreeShipping}</strong> more for Free Shipping</span>
            )}
          </span>
          <span className="text-stone-500">{freeShippingProgress}%</span>
        </div>
        <div className="w-full h-1.5 bg-stone-200/80 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full transition-all duration-500" 
            style={{ width: `${freeShippingProgress}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Cart Items List */}
        <div className="lg:col-span-7 space-y-3">
          {cart.map((item) => (
            <div
              key={`${item.product.id}-${item.selectedVariant?.id || 'default'}`}
              className="flex gap-3.5 p-3.5 rounded-2xl bg-white border border-stone-200/80 shadow-xs"
            >
              {/* Product Image */}
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-stone-50 flex-shrink-0 border border-stone-100">
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Item Info */}
              <div className="flex flex-col flex-1 justify-between min-w-0">
                <div>
                  <div className="flex items-start justify-between gap-1">
                    <h3 className="text-xs sm:text-sm font-semibold text-stone-900 line-clamp-1">
                      {item.product.name}
                    </h3>
                    <button
                      onClick={() => removeFromCart(item.product.id, item.selectedVariant?.id)}
                      className="text-stone-400 hover:text-rose-600 p-1"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {item.selectedVariant && (
                    <div className="flex items-center gap-1.5 mt-0.5">
                      {item.selectedVariant.colorHex && (
                        <span 
                          className="w-2.5 h-2.5 rounded-full border border-stone-300 inline-block"
                          style={{ backgroundColor: item.selectedVariant.colorHex }}
                        />
                      )}
                      <span className="text-[11px] text-stone-500 font-medium">
                        {item.selectedVariant.name}
                      </span>
                    </div>
                  )}

                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-sm font-bold text-stone-900">
                      ₹{item.product.price}
                    </span>
                    {item.product.originalPrice && (
                      <span className="text-xs text-stone-400 line-through">
                        ₹{item.product.originalPrice}
                      </span>
                    )}
                  </div>
                </div>

                {/* Quantity Stepper & Subtotal */}
                <div className="flex items-center justify-between pt-2 border-t border-stone-100 mt-2">
                  <div className="flex items-center border border-stone-200 rounded-lg overflow-hidden bg-stone-50">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, -1, item.selectedVariant?.id)}
                      className="w-7 h-7 flex items-center justify-center text-stone-600 hover:bg-stone-200"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-8 text-center text-xs font-bold text-stone-800">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, 1, item.selectedVariant?.id)}
                      className="w-7 h-7 flex items-center justify-center text-stone-600 hover:bg-stone-200"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <span className="text-xs font-bold text-stone-900">
                    Subtotal: ₹{item.product.price * item.quantity}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary & Coupon Section */}
        <div className="lg:col-span-5 space-y-4">
          {/* Apply Coupon Box */}
          <div className="p-4 rounded-2xl bg-white border border-pink-100 shadow-xs space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-stone-800 uppercase tracking-wider">
              <Tag className="w-4 h-4 text-pink-600" />
              <span>Apply Discount Coupon</span>
            </div>

            {appliedCoupon ? (
              <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs">
                <div className="space-y-0.5">
                  <span className="font-bold text-emerald-800 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    Coupon '{appliedCoupon.code}' applied
                  </span>
                  <p className="text-[11px] text-emerald-600">{appliedCoupon.description}</p>
                </div>
                <button
                  onClick={removeCoupon}
                  className="text-xs font-semibold text-rose-600 hover:underline ml-2"
                >
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter code (e.g. GLIMMER15)"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                  className="flex-1 px-3 py-2 text-xs rounded-xl border border-stone-200 focus:outline-none focus:border-pink-500 uppercase font-mono"
                />
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold rounded-xl bg-stone-900 hover:bg-stone-800 text-white transition-colors"
                >
                  Apply
                </button>
              </form>
            )}

            {/* Quick Coupon Suggestions */}
            {!appliedCoupon && coupons.length > 0 && (
              <div className="space-y-1.5 pt-1 border-t border-stone-100">
                <span className="text-[11px] font-medium text-stone-400 block">Available Offers:</span>
                <div className="space-y-1.5">
                  {coupons.map(c => (
                    <div 
                      key={c.code}
                      onClick={() => applyCoupon(c.code)}
                      className="p-2 rounded-xl bg-pink-50/50 hover:bg-pink-50 border border-pink-100 flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div>
                        <span className="text-xs font-bold font-mono text-pink-700 bg-white px-1.5 py-0.5 rounded border border-pink-200">
                          {c.code}
                        </span>
                        <p className="text-[10px] text-stone-600 mt-0.5">{c.description}</p>
                      </div>
                      <span className="text-xs font-bold text-pink-600 hover:underline">
                        Apply
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Price Breakdown Card */}
          <div className="p-5 rounded-2xl bg-white border border-stone-200/80 shadow-xs space-y-3">
            <h3 className="font-semibold text-stone-900 text-sm border-b border-stone-100 pb-2">
              Price Details
            </h3>

            <div className="space-y-2 text-xs text-stone-600">
              <div className="flex justify-between">
                <span>Product Subtotal</span>
                <span className="font-semibold text-stone-800">₹{cartSubtotal}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-pink-600 font-medium">
                  <span>Coupon Discount</span>
                  <span>- ₹{discountAmount}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Delivery Charges</span>
                {deliveryCharge === 0 ? (
                  <span className="text-emerald-600 font-semibold">FREE</span>
                ) : (
                  <span className="font-semibold text-stone-800">₹{deliveryCharge}</span>
                )}
              </div>

              <div className="border-t border-dashed border-stone-200 pt-2 flex justify-between text-sm font-bold text-stone-900">
                <span>Total Amount</span>
                <span className="text-base text-pink-600">₹{cartTotal}</span>
              </div>

              {discountAmount > 0 && (
                <p className="text-[11px] text-emerald-700 font-medium text-center bg-emerald-50 py-1 rounded-lg">
                  You saved ₹{discountAmount} on this order ✨
                </p>
              )}
            </div>

            {/* Checkout CTA */}
            <button
              onClick={openCheckout}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-pink-500 hover:opacity-95 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-transform active:scale-98"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] text-stone-400 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>100% Safe &amp; Secure Payments</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Product, ProductVariant } from '../../types';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  Heart, 
  Star, 
  ShoppingBag, 
  Zap, 
  Truck, 
  ShieldCheck, 
  Sparkles, 
  RotateCcw, 
  Check, 
  Share2, 
  ChevronLeft, 
  ChevronRight,
  Send
} from 'lucide-react';

export const ProductDetailModal: React.FC = () => {
  const { 
    selectedProduct, 
    setSelectedProduct, 
    toggleWishlist, 
    isInWishlist, 
    addToCart, 
    openCheckout,
    addToast 
  } = useApp();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(() => {
    return selectedProduct?.variants?.[0];
  });
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'desc' | 'specs' | 'reviews'>('desc');
  const [pincode, setPincode] = useState('');
  const [pincodeStatus, setPincodeStatus] = useState<string | null>(null);

  // Review form state
  const [newReviewAuthor, setNewReviewAuthor] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewText, setNewReviewText] = useState('');
  const [localReviews, setLocalReviews] = useState(selectedProduct?.reviews || []);

  if (!selectedProduct) return null;

  const isFavorited = isInWishlist(selectedProduct.id);

  const handlePincodeCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (pincode.trim().length === 6) {
      setPincodeStatus(`Fast Delivery to ${pincode}: Expected in 2-3 business days. Free shipping applies! 🚚`);
    } else {
      setPincodeStatus('Please enter a valid 6-digit PIN code.');
    }
  };

  const handleAddToCart = () => {
    addToCart(selectedProduct, quantity, selectedVariant);
  };

  const handleBuyNow = () => {
    addToCart(selectedProduct, quantity, selectedVariant);
    setSelectedProduct(null);
    openCheckout();
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: selectedProduct.name,
        text: `Check out ${selectedProduct.name} at Glimmer Cart!`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      addToast('Product link copied to clipboard ✨', 'success');
    }
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewAuthor.trim() || !newReviewText.trim()) return;
    const review = {
      id: 'rev-' + Date.now(),
      userName: newReviewAuthor.trim(),
      rating: newReviewRating,
      date: 'Just now',
      comment: newReviewText.trim(),
      verified: true
    };
    setLocalReviews([review, ...localReviews]);
    setNewReviewAuthor('');
    setNewReviewText('');
    addToast('Thank you! Your verified review has been posted ✨', 'sparkle');
  };

  const nextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % selectedProduct.images.length);
  };

  const prevImage = () => {
    setActiveImageIndex((prev) => (prev - 1 + selectedProduct.images.length) % selectedProduct.images.length);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-sm flex justify-center items-start sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white sm:rounded-3xl shadow-2xl overflow-hidden min-h-screen sm:min-h-0 my-auto border border-pink-100 flex flex-col">
        {/* Top Sticky Header */}
        <div className="sticky top-0 z-20 bg-white/90 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-stone-100">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-pink-600 bg-pink-50 px-2.5 py-1 rounded-full">
              {selectedProduct.categoryName}
            </span>
            {selectedProduct.stockCount > 0 ? (
              <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                In Stock ({selectedProduct.stockCount} left)
              </span>
            ) : (
              <span className="text-[11px] font-medium text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
                Out of Stock
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handleShare}
              aria-label="Share product"
              className="p-2 rounded-full text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => toggleWishlist(selectedProduct.id)}
              aria-label="Save to Wishlist"
              className="p-2 rounded-full text-stone-500 hover:text-pink-500 hover:bg-pink-50 transition-colors"
            >
              <Heart className={`w-5 h-5 ${isFavorited ? 'fill-pink-500 text-pink-500' : ''}`} />
            </button>
            <button
              onClick={() => setSelectedProduct(null)}
              aria-label="Close modal"
              className="p-2 rounded-full text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Gallery with Main Image + Thumbnails */}
          <div className="flex flex-col gap-3">
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-stone-100 shadow-inner group">
              <img
                src={selectedProduct.images[activeImageIndex] || selectedProduct.images[0]}
                alt={selectedProduct.name}
                className="w-full h-full object-cover object-center transition-all duration-300"
              />

              {/* Navigation Arrows for Multiple Images */}
              {selectedProduct.images.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 hover:bg-white text-stone-700 shadow-md flex items-center justify-center transition-all opacity-80 group-hover:opacity-100"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 hover:bg-white text-stone-700 shadow-md flex items-center justify-center transition-all opacity-80 group-hover:opacity-100"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}

              {/* Image Counter Badge */}
              <div className="absolute bottom-3 right-3 bg-stone-900/70 text-white text-[10px] font-medium px-2 py-1 rounded-full backdrop-blur-xs">
                {activeImageIndex + 1} / {selectedProduct.images.length}
              </div>
            </div>

            {/* Thumbnail Strip */}
            {selectedProduct.images.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {selectedProduct.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-all ${
                      activeImageIndex === idx 
                        ? 'border-pink-500 shadow-sm scale-102' 
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info Block */}
          <div className="space-y-3">
            <h1 className="font-display text-xl sm:text-2xl font-bold text-stone-900 leading-snug">
              {selectedProduct.name}
            </h1>

            {selectedProduct.tagline && (
              <p className="text-sm text-stone-500 font-light">
                {selectedProduct.tagline}
              </p>
            )}

            {/* Rating & Reviews Bar */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 bg-amber-50 border border-amber-200/80 px-2.5 py-1 rounded-lg">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span className="text-xs font-bold text-stone-800">
                  {selectedProduct.rating.toFixed(1)}
                </span>
                <span className="text-stone-400 text-xs">/ 5.0</span>
              </div>
              <span className="text-xs text-stone-500 underline cursor-pointer" onClick={() => setActiveTab('reviews')}>
                {localReviews.length || selectedProduct.reviewsCount} customer reviews
              </span>
              <span className="text-stone-300">•</span>
              <span className="text-xs text-pink-600 font-medium flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> 100% Authentic Glimmer Cart
              </span>
            </div>

            {/* Price Box */}
            <div className="flex items-baseline gap-3 p-3.5 rounded-2xl bg-gradient-to-r from-pink-50/60 via-purple-50/40 to-transparent border border-pink-100">
              <span className="text-2xl sm:text-3xl font-bold text-stone-900">
                ₹{selectedProduct.price}
              </span>
              {selectedProduct.originalPrice && selectedProduct.originalPrice > selectedProduct.price && (
                <>
                  <span className="text-base text-stone-400 line-through">
                    ₹{selectedProduct.originalPrice}
                  </span>
                  <span className="text-xs font-bold text-pink-600 bg-pink-100 px-2 py-0.5 rounded-md">
                    Save {selectedProduct.discountPercent || Math.round((1 - selectedProduct.price / selectedProduct.originalPrice) * 100)}%
                  </span>
                </>
              )}
              <span className="text-[11px] text-stone-500 ml-auto font-medium">
                Inclusive of all taxes
              </span>
            </div>
          </div>

          {/* Variants Selection */}
          {selectedProduct.variants && selectedProduct.variants.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-stone-100">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-700 uppercase tracking-wider">
                  Color / Finish:
                </span>
                <span className="text-xs font-bold text-pink-700">
                  {selectedVariant?.name || selectedProduct.variants[0].name}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {selectedProduct.variants.map((v) => {
                  const isSelected = (selectedVariant?.id || selectedProduct.variants?.[0].id) === v.id;
                  return (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVariant(v)}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium border transition-all ${
                        isSelected
                          ? 'border-pink-500 bg-pink-50/80 text-pink-900 shadow-xs'
                          : 'border-stone-200 bg-white text-stone-700 hover:border-pink-300'
                      }`}
                    >
                      {v.colorHex && (
                        <span 
                          className="w-3.5 h-3.5 rounded-full border border-stone-300 shadow-inner" 
                          style={{ backgroundColor: v.colorHex }} 
                        />
                      )}
                      <span>{v.name}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-pink-600 ml-0.5" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quantity selector */}
          <div className="flex items-center justify-between pt-2 border-t border-stone-100">
            <span className="text-xs font-semibold text-stone-700 uppercase tracking-wider">
              Quantity
            </span>
            <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50">
              <button
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="w-8 h-8 flex items-center justify-center text-stone-600 hover:bg-stone-200 font-bold transition-colors"
              >
                -
              </button>
              <span className="w-10 text-center text-xs font-bold text-stone-800">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity(q => Math.min(selectedProduct.stockCount, q + 1))}
                className="w-8 h-8 flex items-center justify-center text-stone-600 hover:bg-stone-200 font-bold transition-colors"
              >
                +
              </button>
            </div>
          </div>

          {/* Pincode Check & Delivery Information */}
          <div className="p-3.5 rounded-2xl bg-stone-50/80 border border-stone-200/80 space-y-2.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-stone-800">
              <Truck className="w-4 h-4 text-pink-600" />
              <span>Check Delivery &amp; Services</span>
            </div>
            <form onSubmit={handlePincodeCheck} className="flex gap-2">
              <input
                type="text"
                placeholder="Enter 6-digit PIN code"
                value={pincode}
                maxLength={6}
                onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                className="flex-1 px-3 py-2 text-xs rounded-xl border border-stone-200 focus:outline-none focus:border-pink-500 bg-white"
              />
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-stone-900 hover:bg-stone-800 text-white transition-colors"
              >
                Check
              </button>
            </form>
            {pincodeStatus && (
              <p className="text-[11px] text-stone-600 leading-tight">
                {pincodeStatus}
              </p>
            )}
            <div className="grid grid-cols-2 gap-2 pt-1 text-[11px] text-stone-600">
              <div className="flex items-center gap-1.5">
                <RotateCcw className="w-3.5 h-3.5 text-purple-600" />
                <span>7 Days Easy Return</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Anti-Tarnish Guaranteed</span>
              </div>
            </div>
          </div>

          {/* Tabs: Description, Specs, Reviews */}
          <div className="pt-2">
            <div className="flex border-b border-stone-200 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('desc')}
                className={`pb-2.5 px-3 border-b-2 transition-all ${
                  activeTab === 'desc' 
                    ? 'border-pink-500 text-pink-600' 
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                Description
              </button>
              <button
                onClick={() => setActiveTab('specs')}
                className={`pb-2.5 px-3 border-b-2 transition-all ${
                  activeTab === 'specs' 
                    ? 'border-pink-500 text-pink-600' 
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                Details &amp; Material
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`pb-2.5 px-3 border-b-2 transition-all ${
                  activeTab === 'reviews' 
                    ? 'border-pink-500 text-pink-600' 
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                Reviews ({localReviews.length})
              </button>
            </div>

            <div className="pt-4 text-xs text-stone-600 leading-relaxed">
              {activeTab === 'desc' && (
                <div className="space-y-3">
                  <p>{selectedProduct.description}</p>
                  <div className="p-3 bg-pink-50/50 rounded-xl border border-pink-100 flex items-start gap-2 text-[11px] text-pink-900">
                    <Sparkles className="w-4 h-4 text-pink-500 flex-shrink-0 mt-0.5" />
                    <span>Every Glimmer Cart jewel comes packaged in our signature keepsake box with a velvety pouch and complimentary cat sticker pack!</span>
                  </div>
                </div>
              )}

              {activeTab === 'specs' && (
                <div className="space-y-2.5">
                  <div className="flex justify-between py-1.5 border-b border-stone-100">
                    <span className="font-semibold text-stone-500">Material</span>
                    <span className="text-stone-800 font-medium text-right">{selectedProduct.material}</span>
                  </div>
                  {selectedProduct.dimensions && (
                    <div className="flex justify-between py-1.5 border-b border-stone-100">
                      <span className="font-semibold text-stone-500">Dimensions</span>
                      <span className="text-stone-800 font-medium text-right">{selectedProduct.dimensions}</span>
                    </div>
                  )}
                  <div className="flex justify-between py-1.5 border-b border-stone-100">
                    <span className="font-semibold text-stone-500">Skin Friendly</span>
                    <span className="text-emerald-700 font-medium">Lead &amp; Nickel Free, Hypoallergenic</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-stone-100">
                    <span className="font-semibold text-stone-500">Care Instructions</span>
                    <span className="text-stone-700 text-right">Keep away from perfumes; wipe with dry soft cloth</span>
                  </div>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-4">
                  {/* Reviews list */}
                  <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                    {localReviews.length > 0 ? (
                      localReviews.map(r => (
                        <div key={r.id} className="p-3 rounded-xl bg-stone-50 border border-stone-100 space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-stone-800 text-xs">{r.userName}</span>
                            <span className="text-[10px] text-stone-400">{r.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < r.rating ? 'fill-amber-400 text-amber-400' : 'text-stone-300'
                                }`}
                              />
                            ))}
                            {r.verified && (
                              <span className="text-[10px] text-emerald-700 font-medium ml-1">
                                ✓ Verified Buyer
                              </span>
                            )}
                          </div>
                          <p className="text-stone-600 text-xs">{r.comment}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-stone-400 italic">No reviews yet. Be the first to share your thoughts!</p>
                    )}
                  </div>

                  {/* Add review form */}
                  <form onSubmit={handleAddReview} className="p-3 rounded-2xl bg-pink-50/60 border border-pink-100 space-y-2">
                    <span className="font-semibold text-stone-800 block text-xs">
                      Share Your Experience ✨
                    </span>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Your Name"
                        value={newReviewAuthor}
                        onChange={(e) => setNewReviewAuthor(e.target.value)}
                        className="w-1/2 px-2.5 py-1.5 text-xs rounded-lg border border-stone-200 bg-white"
                        required
                      />
                      <div className="flex items-center gap-1 ml-auto">
                        <span className="text-[11px] text-stone-500">Rating:</span>
                        {[1, 2, 3, 4, 5].map((s) => (
                          <button
                            type="button"
                            key={s}
                            onClick={() => setNewReviewRating(s)}
                            className="text-amber-400"
                          >
                            <Star className={`w-3.5 h-3.5 ${s <= newReviewRating ? 'fill-amber-400' : 'text-stone-300'}`} />
                          </button>
                        ))}
                      </div>
                    </div>
                    <textarea
                      placeholder="How did this piece look and feel? Would you recommend it to fellow cat lovers?"
                      rows={2}
                      value={newReviewText}
                      onChange={(e) => setNewReviewText(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-200 bg-white"
                      required
                    />
                    <button
                      type="submit"
                      className="w-full py-1.5 text-xs font-semibold rounded-lg bg-pink-600 hover:bg-pink-700 text-white flex items-center justify-center gap-1 shadow-xs"
                    >
                      <Send className="w-3 h-3" /> Post Review
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom CTA Sticky Bar */}
        <div className="sticky bottom-0 z-20 bg-white/95 backdrop-blur-md p-3 sm:p-4 border-t border-stone-200 flex items-center gap-2.5 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
          <button
            onClick={() => toggleWishlist(selectedProduct.id)}
            aria-label="Wishlist"
            className={`p-3 rounded-2xl border transition-all ${
              isFavorited
                ? 'bg-pink-50 border-pink-300 text-pink-600'
                : 'border-stone-200 text-stone-600 hover:bg-stone-50'
            }`}
          >
            <Heart className={`w-5 h-5 ${isFavorited ? 'fill-pink-600' : ''}`} />
          </button>

          <button
            onClick={handleAddToCart}
            className="flex-1 py-3 px-4 rounded-2xl bg-white border-2 border-pink-500 text-pink-600 hover:bg-pink-50 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-98 shadow-xs"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Add to Cart</span>
          </button>

          <button
            onClick={handleBuyNow}
            className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-pink-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all hover:opacity-95 active:scale-98 shadow-md"
          >
            <Zap className="w-4 h-4 fill-white" />
            <span>Buy Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};

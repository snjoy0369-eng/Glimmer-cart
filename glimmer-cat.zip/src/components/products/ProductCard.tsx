import React, { useState } from 'react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { Heart, Star, ShoppingBag, Sparkles } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  badgeText?: string;
  badgeType?: 'bestseller' | 'new' | 'limited' | 'discount';
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  badgeText,
  badgeType
}) => {
  const { toggleWishlist, isInWishlist, addToCart, setSelectedProduct } = useApp();
  const [isHovered, setIsHovered] = useState(false);
  const [heartPulsing, setHeartPulsing] = useState(false);
  const [cartAdding, setCartAdding] = useState(false);

  const isFavorited = isInWishlist(product.id);

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setHeartPulsing(true);
    toggleWishlist(product.id);
    setTimeout(() => setHeartPulsing(false), 500);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCartAdding(true);
    addToCart(product, 1, product.variants?.[0]);
    setTimeout(() => setCartAdding(false), 600);
  };

  // Determine badge
  let badgeLabel = badgeText;
  let badgeClasses = 'bg-stone-900 text-white';
  if (!badgeLabel) {
    if (product.isLimitedCollection) {
      badgeLabel = 'Limited Collection';
      badgeClasses = 'bg-purple-600 text-white';
    } else if (product.isBestSeller) {
      badgeLabel = 'Best Seller';
      badgeClasses = 'bg-pink-600 text-white';
    } else if (product.isNewArrival) {
      badgeLabel = 'New Arrival';
      badgeClasses = 'bg-amber-600 text-white';
    } else if (product.discountPercent && product.discountPercent >= 30) {
      badgeLabel = `${product.discountPercent}% OFF`;
      badgeClasses = 'bg-rose-500 text-white';
    }
  }

  // Active image on hover if multiple available
  const displayImage = isHovered && product.images.length > 1 ? product.images[1] : product.images[0];

  return (
    <div
      onClick={() => setSelectedProduct(product)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative flex flex-col bg-white rounded-2xl border border-pink-100/70 overflow-hidden shadow-[0_4px_16px_rgba(0,0,0,0.03)] hover:shadow-[0_12px_32px_rgba(244,114,182,0.12)] transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
    >
      {/* Product Image Area */}
      <div className="relative aspect-square w-full overflow-hidden bg-stone-50">
        <img
          src={displayImage}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {badgeLabel && (
            <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md shadow-xs ${badgeClasses}`}>
              {badgeLabel}
            </span>
          )}
          {product.categoryName === 'Kan Fuli' && (
            <span className="text-[9px] font-semibold bg-pink-100 text-pink-700 px-1.5 py-0.5 rounded shadow-xs flex items-center gap-0.5">
              <Sparkles className="w-2.5 h-2.5" /> Kan Fuli
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={handleHeartClick}
          aria-label={isFavorited ? 'Remove from wishlist' : 'Add to wishlist'}
          className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-all duration-200 z-10 ${
            isFavorited
              ? 'bg-pink-50 text-pink-500 shadow-sm scale-105'
              : 'bg-white/80 text-stone-500 hover:text-pink-500 hover:bg-white shadow-xs'
          } ${heartPulsing ? 'scale-125 animate-ping' : ''}`}
        >
          <Heart
            className={`w-4 h-4 transition-transform ${
              isFavorited ? 'fill-pink-500 text-pink-500' : 'text-stone-600'
            }`}
          />
        </button>

        {/* Quick Add to Cart (Desktop slide-up or subtle button) */}
        <div className="absolute bottom-2.5 left-2.5 right-2.5 z-10 sm:translate-y-12 sm:opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-200">
          <button
            onClick={handleAddToCart}
            className={`w-full py-2 px-3 rounded-xl backdrop-blur-md text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-md ${
              cartAdding
                ? 'bg-emerald-600 text-white scale-98'
                : 'bg-white/95 text-stone-900 hover:bg-pink-500 hover:text-white border border-pink-100'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{cartAdding ? 'Added! ✨' : 'Quick Add'}</span>
          </button>
        </div>
      </div>

      {/* Product Content Details */}
      <div className="flex flex-col flex-1 p-3 sm:p-3.5">
        {/* Category & Rating */}
        <div className="flex items-center justify-between gap-1 text-[11px] text-stone-400 mb-1">
          <span className="uppercase tracking-wider font-medium text-pink-600/90 truncate">
            {product.categoryName}
          </span>
          <div className="flex items-center gap-0.5 font-medium text-stone-700 bg-amber-50 px-1.5 py-0.5 rounded">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>{product.rating.toFixed(1)}</span>
            <span className="text-stone-400 text-[10px]">({product.reviewsCount})</span>
          </div>
        </div>

        {/* Product Title */}
        <h3 className="text-xs sm:text-sm font-semibold text-stone-900 line-clamp-1 group-hover:text-pink-600 transition-colors">
          {product.name}
        </h3>

        {/* Tagline snippet */}
        {product.tagline && (
          <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5 font-light">
            {product.tagline}
          </p>
        )}

        {/* Price & Discount */}
        <div className="mt-auto pt-2.5 flex items-baseline gap-2">
          <span className="text-sm sm:text-base font-bold text-stone-900">
            ₹{product.price}
          </span>
          {product.originalPrice && product.originalPrice > product.price && (
            <span className="text-xs text-stone-400 line-through">
              ₹{product.originalPrice}
            </span>
          )}
          {product.discountPercent && product.discountPercent > 0 && (
            <span className="text-[10px] font-bold text-pink-600 bg-pink-50 px-1 py-0.5 rounded ml-auto">
              {product.discountPercent}% OFF
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

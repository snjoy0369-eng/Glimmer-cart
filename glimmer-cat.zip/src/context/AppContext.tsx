import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Product, 
  CartItem, 
  Order, 
  OrderStatus, 
  UserProfile, 
  CategoryId, 
  Coupon, 
  PromoBanner, 
  AppNotification, 
  ShippingAddress,
  ProductVariant 
} from '../types';
import { 
  INITIAL_PRODUCTS, 
  INITIAL_BANNERS, 
  INITIAL_COUPONS, 
  INITIAL_NOTIFICATIONS, 
  DEMO_USER 
} from '../data/initialData';
import {
  getProductsFromDB,
  saveProductToDB,
  saveAllProductsToDB,
  deleteProductFromDB
} from '../services/db';
import {
  getActiveUser,
  saveUser,
  setActiveUserId,
  createOrLoadUserProfile
} from '../services/userService';

export type AppTab = 
  | 'home' 
  | 'categories' 
  | 'wishlist' 
  | 'cart' 
  | 'profile' 
  | 'search' 
  | 'notifications' 
  | 'orders' 
  | 'admin';

export interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'sparkle' | 'error';
  icon?: string;
}

interface AppContextType {
  // Navigation
  currentTab: AppTab;
  setCurrentTab: (tab: AppTab) => void;
  selectedCategory: CategoryId | null;
  setSelectedCategory: (cat: CategoryId | null) => void;
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  
  // Splash
  isSplashVisible: boolean;
  dismissSplash: () => void;
  triggerSplashAgain: () => void;

  // Products
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => Promise<Product>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  toggleProductStock: (id: string) => Promise<void>;
  resetToDefaultProducts: () => void;

  // Wishlist
  wishlist: string[]; // product IDs
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, variant?: ProductVariant) => void;
  updateCartQuantity: (productId: string, delta: number, variantId?: string) => void;
  removeFromCart: (productId: string, variantId?: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  deliveryCharge: number;
  discountAmount: number;
  cartTotal: number;

  // Coupons
  coupons: Coupon[];
  appliedCoupon: Coupon | null;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  addCoupon: (coupon: Coupon) => void;
  deleteCoupon: (code: string) => void;

  // Orders
  orders: Order[];
  placeOrder: (
    shippingAddress: ShippingAddress, 
    paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery'
  ) => Order;
  updateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  lastPlacedOrder: Order | null;
  setLastPlacedOrder: (order: Order | null) => void;

  // User & Auth
  user: UserProfile | null;
  isLoggedIn: boolean;
  loginWithGoogle: (details?: { fullName?: string; email?: string }) => void;
  loginWithMobileOtp: (
    params: { fullName: string; mobile: string; email?: string } | string,
    fullName?: string,
    email?: string
  ) => void;
  loginWithEmail: (
    emailOrParams: string | { fullName: string; email: string; mobile?: string },
    fullName?: string,
    mobile?: string
  ) => void;
  logout: () => void;
  updateUserProfile: (updates: Partial<UserProfile>) => void;
  addSavedAddress: (address: ShippingAddress) => void;
  updateSavedAddress: (index: number, address: ShippingAddress) => void;
  deleteSavedAddress: (index: number) => void;

  // Modals
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'signup' | 'otp' | 'forgot';
  openAuthModal: (mode?: 'login' | 'signup' | 'otp' | 'forgot') => void;
  closeAuthModal: () => void;
  isCheckoutOpen: boolean;
  openCheckout: () => void;
  closeCheckout: () => void;

  // Banners & Admin
  banners: PromoBanner[];
  addBanner: (b: PromoBanner) => void;
  deleteBanner: (id: string) => void;
  isAdminMode: boolean;
  setIsAdminMode: (admin: boolean) => void;
  verifyAdminPasscode: (code: string) => boolean;

  // Notifications
  notifications: AppNotification[];
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  unreadNotificationsCount: number;

  // Toasts
  toasts: ToastMessage[];
  addToast: (message: string, type?: 'success' | 'info' | 'sparkle' | 'error', icon?: string) => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PRODUCTS: 'glimmer_cart_products_v1',
  CART: 'glimmer_cart_cart_v1',
  WISHLIST: 'glimmer_cart_wishlist_v1',
  ORDERS: 'glimmer_cart_orders_v1',
  USER: 'glimmer_cart_user_v1',
  COUPONS: 'glimmer_cart_coupons_v1',
  BANNERS: 'glimmer_cart_banners_v1',
  NOTIFICATIONS: 'glimmer_cart_notifications_v1',
  SPLASH_SHOWN: 'glimmer_cart_splash_shown'
};

const getStorageItem = (key: keyof typeof STORAGE_KEYS) => {
  return localStorage.getItem(STORAGE_KEYS[key]);
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Splash Screen: Show on first load, can be triggered again anytime
  const [isSplashVisible, setIsSplashVisible] = useState<boolean>(() => {
    // Show splash on fresh session load
    return true;
  });

  const [currentTab, setCurrentTab] = useState<AppTab>('home');
  const [selectedCategory, setSelectedCategory] = useState<CategoryId | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Products: initialized from persistent IndexedDB with graceful fallback
  const [products, setProducts] = useState<Product[]>([]);

  // Load products persistently from IndexedDB on startup
  useEffect(() => {
    let isMounted = true;
    async function loadStoredProducts() {
      try {
        const dbProducts = await getProductsFromDB();
        if (isMounted && dbProducts && dbProducts.length > 0) {
          // Filter out any stale demo product placeholders (gc-01 to gc-12)
          const nonDemo = dbProducts.filter(p => !p.id.startsWith('gc-0') && !['gc-10', 'gc-11', 'gc-12'].includes(p.id));
          if (nonDemo.length > 0) {
            setProducts(nonDemo);
            return;
          }
        }

        // Check legacy localStorage if migrated
        const saved = getStorageItem('PRODUCTS');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const nonDemo = parsed.filter((p: any) => p && !p.id?.startsWith('gc-0') && !['gc-10', 'gc-11', 'gc-12'].includes(p.id));
            if (nonDemo.length > 0) {
              setProducts(nonDemo);
              saveAllProductsToDB(nonDemo).catch(console.error);
              return;
            }
          }
        }

        // Clean slate ready for owner's real products
        setProducts([]);
        saveAllProductsToDB([]).catch(console.error);
        localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
      } catch (err) {
        console.warn('Error loading products from IndexedDB:', err);
      }
    }

    loadStoredProducts();
    return () => { isMounted = false; };
  }, []);

  // Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = getStorageItem('WISHLIST');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Clean out old demo IDs
        return parsed.filter((id: string) => !id.startsWith('gc-0') && !['gc-10', 'gc-11', 'gc-12'].includes(id));
      }
      return [];
    } catch {
      return [];
    }
  });

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = getStorageItem('CART');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // User: load active authenticated user profile from persistent multi-user storage
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const active = getActiveUser();
      if (active) return active;

      // Check legacy single-user storage if valid named user exists
      const saved = getStorageItem('USER');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.name && parsed.name !== 'Aarohi Sen') {
          saveUser(parsed);
          setActiveUserId(parsed.id);
          return parsed;
        }
      }
      return null;
    } catch {
      return null;
    }
  });

  // Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = getStorageItem('ORDERS');
      if (saved) return JSON.parse(saved);
      return [];
    } catch {
      return [];
    }
  });

  // Coupons
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    try {
      const saved = getStorageItem('COUPONS');
      return saved ? JSON.parse(saved) : INITIAL_COUPONS;
    } catch {
      return INITIAL_COUPONS;
    }
  });
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  // Banners
  const [banners, setBanners] = useState<PromoBanner[]>(() => {
    try {
      const saved = getStorageItem('BANNERS');
      return saved ? JSON.parse(saved) : INITIAL_BANNERS;
    } catch {
      return INITIAL_BANNERS;
    }
  });

  // Notifications
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    try {
      const saved = getStorageItem('NOTIFICATIONS');
      return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  });

  // Modals & UI States
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | 'otp' | 'forgot'>('login');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COUPONS, JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
  }, [banners]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  // Toast management
  const addToast = (message: string, type: 'success' | 'info' | 'sparkle' | 'error' = 'success', icon?: string) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts(prev => [...prev, { id, message, type, icon }]);
    setTimeout(() => {
      removeToast(id);
    }, 3200);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Splash
  const dismissSplash = () => setIsSplashVisible(false);
  const triggerSplashAgain = () => setIsSplashVisible(true);

  // Wishlist
  const toggleWishlist = (productId: string) => {
    setWishlist(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        addToast('Removed from your Wishlist 🤍', 'info');
        return prev.filter(id => id !== productId);
      } else {
        addToast('Saved to your Wishlist ✨', 'sparkle');
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Cart computations
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  
  // Free delivery above ₹499
  const deliveryCharge = cartSubtotal === 0 || cartSubtotal >= 499 ? 0 : 49;

  let discountAmount = 0;
  if (appliedCoupon) {
    const couponVal = appliedCoupon.value ?? appliedCoupon.discountPercent ?? 0;
    if (appliedCoupon.discountType === 'percentage' || (!appliedCoupon.discountType && appliedCoupon.discountPercent)) {
      discountAmount = Math.round((cartSubtotal * couponVal) / 100);
    } else {
      discountAmount = Math.min(couponVal, cartSubtotal);
    }
  }

  const cartTotal = Math.max(0, cartSubtotal - discountAmount + deliveryCharge);

  const addToCart = (product: Product, quantity = 1, variant?: ProductVariant) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(item => 
        item.product.id === product.id && 
        item.selectedVariant?.id === (variant?.id || product.variants?.[0]?.id)
      );

      const effectiveVariant = variant || (product.variants && product.variants.length > 0 ? product.variants[0] : undefined);

      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity
        };
        return next;
      } else {
        return [...prev, { product, quantity, selectedVariant: effectiveVariant }];
      }
    });
    addToast(`Added "${product.name}" to cart ✨`, 'sparkle');
  };

  const updateCartQuantity = (productId: string, delta: number, variantId?: string) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId && (!variantId || item.selectedVariant?.id === variantId)) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      }).filter(Boolean) as CartItem[];
    });
  };

  const removeFromCart = (productId: string, variantId?: string) => {
    setCart(prev => prev.filter(item => !(item.product.id === productId && (!variantId || item.selectedVariant?.id === variantId))));
    addToast('Item removed from cart', 'info');
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  // Coupons
  const applyCoupon = (code: string) => {
    const trimmed = code.trim().toUpperCase();
    const found = coupons.find(c => c.code.toUpperCase() === trimmed);
    if (!found) {
      addToast('Invalid coupon code. Try GLIMMER15 or CATLOVE20', 'error');
      return { success: false, message: 'Invalid coupon code' };
    }
    const minReq = found.minOrderAmount ?? found.minSpend ?? 0;
    if (cartSubtotal < minReq) {
      addToast(`Minimum cart value of ₹${minReq} required for ${found.code}`, 'error');
      return { success: false, message: `Minimum cart value of ₹${minReq} required` };
    }
    setAppliedCoupon(found);
    addToast(`Coupon "${found.code}" applied successfully! 🐾`, 'sparkle');
    return { success: true, message: 'Coupon applied!' };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    addToast('Coupon removed', 'info');
  };

  const addCoupon = (coupon: Coupon) => {
    setCoupons(prev => [...prev.filter(c => c.code !== coupon.code), coupon]);
    addToast(`Coupon ${coupon.code} created`, 'success');
  };

  const deleteCoupon = (code: string) => {
    setCoupons(prev => prev.filter(c => c.code !== code));
    if (appliedCoupon?.code === code) setAppliedCoupon(null);
    addToast(`Coupon ${code} deleted`, 'info');
  };

  // Orders
  const placeOrder = (
    shippingAddress: ShippingAddress, 
    paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery'
  ): Order => {
    const orderId = 'GC-' + new Date().getFullYear() + '-' + Math.floor(10000 + Math.random() * 90000);
    const estimated = new Date(Date.now() + 86400000 * 3).toLocaleDateString('en-IN', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });

    const newOrder: Order = {
      id: orderId,
      createdAt: new Date().toISOString(),
      items: [...cart],
      subtotal: cartSubtotal,
      deliveryCharge,
      discount: discountAmount,
      couponApplied: appliedCoupon?.code,
      total: cartTotal,
      shippingAddress,
      paymentMethod,
      paymentStatus: paymentMethod === 'Cash on Delivery' ? 'Pending' : 'Paid',
      orderStatus: 'Order Placed',
      estimatedDelivery: `Arriving by ${estimated}`,
      trackingNumber: `GL-${Math.floor(100000 + Math.random() * 900000)}-IN`
    };

    setOrders(prev => [newOrder, ...prev]);
    setLastPlacedOrder(newOrder);
    clearCart();

    // Add order confirmation notification
    const orderNotif: AppNotification = {
      id: 'notif-' + Date.now(),
      title: '💖 Order Placed Successfully!',
      message: `Your order #${orderId} for ₹${newOrder.total} is confirmed and will arrive by ${estimated}.`,
      type: 'order',
      date: 'Just now',
      read: false
    };
    setNotifications(prev => [orderNotif, ...prev]);

    return newOrder;
  };

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, orderStatus: newStatus } : o));
    addToast(`Order ${orderId} updated to ${newStatus}`, 'success');
  };

  // Product management (Admin & Store Owner)
  const addProduct = async (p: Omit<Product, 'id'>) => {
    const id = 'prod-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 6);
    const newProduct: Product = { ...p, id };
    
    // Immediate optimistic state update
    setProducts(prev => [newProduct, ...prev]);

    // Durable persistence in IndexedDB
    try {
      await saveProductToDB(newProduct);
    } catch (e) {
      console.warn('Could not save product to IndexedDB:', e);
    }

    addToast(`"${p.name}" added to catalog! ✨`, 'success');
    return newProduct;
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    setProducts(prev => {
      const updatedList = prev.map(p => {
        if (p.id === id) {
          const updated = { ...p, ...updates };
          saveProductToDB(updated).catch(console.error);
          return updated;
        }
        return p;
      });
      return updatedList;
    });

    if (selectedProduct?.id === id) {
      setSelectedProduct(prev => prev ? { ...prev, ...updates } : null);
    }
    addToast('Product updated successfully ✨', 'success');
  };

  const deleteProduct = async (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    if (selectedProduct?.id === id) setSelectedProduct(null);

    try {
      await deleteProductFromDB(id);
    } catch (e) {
      console.warn('Could not delete product from IndexedDB:', e);
    }

    addToast('Product removed from catalog', 'info');
  };

  const toggleProductStock = async (id: string) => {
    const prod = products.find(p => p.id === id);
    if (!prod) return;
    const newOutOfStock = !prod.isOutOfStock;
    await updateProduct(id, { 
      isOutOfStock: newOutOfStock,
      stockCount: newOutOfStock ? 0 : (prod.stockCount > 0 ? prod.stockCount : 10)
    });
    addToast(
      newOutOfStock ? `Marked "${prod.name}" as Out of Stock` : `Marked "${prod.name}" as Available In Stock ✨`,
      'info'
    );
  };

  const resetToDefaultProducts = () => {
    setProducts([]);
    saveAllProductsToDB([]).catch(console.error);
    addToast('Product catalog cleared ready for your items', 'info');
  };

  // Banners
  const addBanner = (b: PromoBanner) => {
    setBanners(prev => [b, ...prev]);
    addToast('Promotional banner added', 'success');
  };

  const deleteBanner = (id: string) => {
    setBanners(prev => prev.filter(b => b.id !== id));
    addToast('Banner removed', 'info');
  };

  // User Auth
  const loginWithGoogle = (details?: { fullName?: string; email?: string }) => {
    const enteredName = details?.fullName?.trim() || 'Glimmer Member';
    const enteredEmail = details?.email?.trim().toLowerCase() || 'member@gmail.com';

    const { user: authedUser, isNew } = createOrLoadUserProfile({
      fullName: enteredName,
      email: enteredEmail,
      avatarUrl: ''
    });

    setUser(authedUser);
    setIsAuthModalOpen(false);
    setCurrentTab('home');

    const firstName = authedUser.name.split(' ')[0] || authedUser.name;
    addToast(
      isNew
        ? `Welcome to Glimmer Cart, ${firstName}! ✨ Your profile has been created.`
        : `Welcome back, ${firstName}! ✨`,
      'sparkle'
    );
  };

  const loginWithMobileOtp = (
    params: { fullName: string; mobile: string; email?: string } | string,
    legacyName?: string,
    legacyEmail?: string
  ) => {
    let fullName = '';
    let mobile = '';
    let email = '';

    if (typeof params === 'object') {
      fullName = params.fullName || '';
      mobile = params.mobile || '';
      email = params.email || '';
    } else {
      mobile = params;
      fullName = legacyName || '';
      email = legacyEmail || '';
    }

    const { user: authedUser, isNew } = createOrLoadUserProfile({
      fullName: fullName || (mobile ? `User ${mobile.slice(-4)}` : 'Customer'),
      mobile,
      email
    });

    setUser(authedUser);
    setIsAuthModalOpen(false);
    setCurrentTab('home');

    const firstName = authedUser.name.split(' ')[0] || authedUser.name;
    addToast(
      isNew
        ? `Welcome to Glimmer Cart, ${firstName}! ✨ Profile created automatically.`
        : `Welcome back, ${firstName}! ✨ Profile loaded.`,
      'sparkle'
    );
  };

  const loginWithEmail = (
    emailOrParams: string | { fullName: string; email: string; mobile?: string },
    legacyName?: string,
    legacyMobile?: string
  ) => {
    let fullName = '';
    let email = '';
    let mobile = '';

    if (typeof emailOrParams === 'object') {
      fullName = emailOrParams.fullName || '';
      email = emailOrParams.email || '';
      mobile = emailOrParams.mobile || '';
    } else {
      email = emailOrParams;
      fullName = legacyName || '';
      mobile = legacyMobile || '';
    }

    const { user: authedUser, isNew } = createOrLoadUserProfile({
      fullName: fullName || (email ? email.split('@')[0] : 'Customer'),
      email,
      mobile
    });

    setUser(authedUser);
    setIsAuthModalOpen(false);
    setCurrentTab('home');

    const firstName = authedUser.name.split(' ')[0] || authedUser.name;
    addToast(
      isNew
        ? `Welcome to Glimmer Cart, ${firstName}! ✨ Profile created automatically.`
        : `Welcome back, ${firstName}! ✨ Profile loaded.`,
      'sparkle'
    );
  };

  const logout = () => {
    setUser(null);
    setActiveUserId(null);
    setIsAdminMode(false);
    addToast('Logged out successfully', 'info');
  };

  const updateUserProfile = (updates: Partial<UserProfile>) => {
    setUser(prev => {
      if (!prev) return null;
      const updated = { ...prev, ...updates };
      saveUser(updated);
      return updated;
    });
    addToast('Profile updated ✨', 'success');
  };

  const addSavedAddress = (address: ShippingAddress) => {
    if (!user) return;
    const updatedUser: UserProfile = {
      ...user,
      savedAddresses: [address, ...user.savedAddresses]
    };
    setUser(updatedUser);
    saveUser(updatedUser);
    addToast('New delivery address saved 📍', 'success');
  };

  const updateSavedAddress = (index: number, address: ShippingAddress) => {
    if (!user) return;
    const nextAddresses = [...user.savedAddresses];
    if (index >= 0 && index < nextAddresses.length) {
      nextAddresses[index] = address;
      const updatedUser: UserProfile = {
        ...user,
        savedAddresses: nextAddresses
      };
      setUser(updatedUser);
      saveUser(updatedUser);
      addToast('Address updated 📍', 'success');
    }
  };

  const deleteSavedAddress = (index: number) => {
    if (!user) return;
    const next = [...user.savedAddresses];
    next.splice(index, 1);
    const updatedUser: UserProfile = {
      ...user,
      savedAddresses: next
    };
    setUser(updatedUser);
    saveUser(updatedUser);
    addToast('Address removed', 'info');
  };

  // Modals
  const openAuthModal = (mode: 'login' | 'signup' | 'otp' | 'forgot' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => setIsAuthModalOpen(false);
  const openCheckout = () => setIsCheckoutOpen(true);
  const closeCheckout = () => setIsCheckoutOpen(false);

  // Admin Passcode check
  const verifyAdminPasscode = (code: string) => {
    if (code.trim().toLowerCase() === 'glimmer2026' || code.trim() === 'admin' || code.trim() === 'cat123') {
      setIsAdminMode(true);
      addToast('Admin mode unlocked! Welcome Store Owner 🐾', 'sparkle');
      return true;
    }
    addToast('Incorrect passcode. Try "glimmer2026"', 'error');
    return false;
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    addToast('All notifications marked as read', 'info');
  };

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  return (
    <AppContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        selectedCategory,
        setSelectedCategory,
        selectedProduct,
        setSelectedProduct,
        searchQuery,
        setSearchQuery,

        isSplashVisible,
        dismissSplash,
        triggerSplashAgain,

        products,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleProductStock,
        resetToDefaultProducts,

        wishlist,
        toggleWishlist,
        isInWishlist,

        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartCount,
        cartSubtotal,
        deliveryCharge,
        discountAmount,
        cartTotal,

        coupons,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        addCoupon,
        deleteCoupon,

        orders,
        placeOrder,
        updateOrderStatus,
        lastPlacedOrder,
        setLastPlacedOrder,

        user,
        isLoggedIn: !!user,
        loginWithGoogle,
        loginWithMobileOtp,
        loginWithEmail,
        logout,
        updateUserProfile,
        addSavedAddress,
        updateSavedAddress,
        deleteSavedAddress,

        isAuthModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
        isCheckoutOpen,
        openCheckout,
        closeCheckout,

        banners,
        addBanner,
        deleteBanner,
        isAdminMode,
        setIsAdminMode,
        verifyAdminPasscode,

        notifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        unreadNotificationsCount,

        toasts,
        addToast,
        removeToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

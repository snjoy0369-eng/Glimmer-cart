/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { SplashScreen } from './components/splash/SplashScreen';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { Footer } from './components/common/Footer';
import { ToastContainer } from './components/common/Toast';
import { ProductDetailModal } from './components/products/ProductDetailModal';
import { CheckoutView } from './components/checkout/CheckoutView';
import { AuthModal } from './components/auth/AuthModal';

// Views
import { HomeView } from './components/home/HomeView';
import { SearchView } from './components/search/SearchView';
import { CategoriesView } from './components/categories/CategoriesView';
import { WishlistView } from './components/wishlist/WishlistView';
import { CartView } from './components/cart/CartView';
import { OrdersView } from './components/orders/OrdersView';
import { ProfileView } from './components/profile/ProfileView';
import { NotificationsView } from './components/notifications/NotificationsView';
import { AdminDashboard } from './components/admin/AdminDashboard';

const MainLayout: React.FC = () => {
  const { currentTab, isAdminMode } = useApp();
  const [showSplash, setShowSplash] = useState(() => {
    // Show splash on first load of session
    return !sessionStorage.getItem('glimmer_cart_splash_shown');
  });

  const handleSplashComplete = () => {
    setShowSplash(false);
    sessionStorage.setItem('glimmer_cart_splash_shown', 'true');
  };

  // Scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentTab]);

  return (
    <div className="min-h-screen bg-[#FDFBF9] text-stone-800 flex flex-col font-sans selection:bg-pink-200 selection:text-pink-900">
      {/* Animated Opening Splash Screen */}
      {showSplash && <SplashScreen onComplete={handleSplashComplete} />}

      {/* Top Header Bar */}
      <Header />

      {/* Main Screen View Content */}
      <main className="flex-1 w-full max-w-7xl mx-auto">
        {currentTab === 'home' && <HomeView />}
        {currentTab === 'search' && <SearchView />}
        {currentTab === 'categories' && <CategoriesView />}
        {currentTab === 'wishlist' && <WishlistView />}
        {currentTab === 'cart' && <CartView />}
        {currentTab === 'orders' && <OrdersView />}
        {currentTab === 'profile' && <ProfileView />}
        {currentTab === 'notifications' && <NotificationsView />}
        {currentTab === 'admin' && <AdminDashboard />}
      </main>

      {/* Footer Branding & Links */}
      <Footer />

      {/* Mobile-First Sticky Bottom Navigation */}
      <BottomNav />

      {/* Global Modals & Overlays */}
      <ProductDetailModal />
      <CheckoutView />
      <AuthModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
